import { useEffect, useState } from "react";

export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState<boolean>(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia(query);
    const updateMatches = () => setMatches(mediaQuery.matches);
    
    // التحقق الأولي
    updateMatches();
    
    // إضافة مستمع الحدث
    mediaQuery.addEventListener("change", updateMatches);
    
    // إزالة مستمع الحدث عند تفكيك المكون
    return () => {
      mediaQuery.removeEventListener("change", updateMatches);
    };
  }, [query]);

  return matches;
}
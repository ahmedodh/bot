export interface BotStatus {
  status: 'online' | 'offline';
  stats: Stats;
}

export interface Stats {
  id: number;
  uptime: number;
  commandsUsed: number;
  serverCount: number;
  memoryUsage: number;
  latency: number;
  apiCalls: number;
  lastUpdated: string;
}

export interface Command {
  id: number;
  name: string;
  description: string;
  enabled: boolean;
}

export interface Log {
  id: number;
  type: string;
  message: string;
  timestamp: string;
}

export interface Activity {
  time: string;
  message: string;
}

import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  const res = await fetch(url, {
    method,
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});

// أدوات للتعامل مع نظام المستويات والاقتصاد
export const levelingSystem = {
  // وظائف المستويات الأساسية
  getUsers: async () => {
    const res = await fetch('/api/leveling/users', {
      credentials: 'include',
    });
    await throwIfResNotOk(res);
    return res.json();
  },
  
  updateUser: async (userId: string, data: { 
    xp?: number, 
    level?: number, 
    coins?: number, 
    is_vip?: boolean,
    rank?: string,
    color?: string
  }) => {
    const res = await fetch(`/api/leveling/users/${userId}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
      credentials: 'include',
    });
    await throwIfResNotOk(res);
    return res.json();
  },
  
  // وظائف التحكم بالبوت
  startBot: async () => {
    const res = await fetch('/api/leveling/start', {
      method: 'POST',
      credentials: 'include',
    });
    await throwIfResNotOk(res);
    return res.json();
  },
  
  stopBot: async () => {
    const res = await fetch('/api/leveling/stop', {
      method: 'POST',
      credentials: 'include',
    });
    await throwIfResNotOk(res);
    return res.json();
  },
  
  // وظائف نظام الاقتصاد والمتجر
  getShopItems: async () => {
    const res = await fetch('/api/leveling/shop', {
      credentials: 'include',
    });
    await throwIfResNotOk(res);
    return res.json();
  },
  
  getUserInventory: async (userId: string) => {
    const res = await fetch(`/api/leveling/users/${userId}/inventory`, {
      credentials: 'include',
    });
    await throwIfResNotOk(res);
    return res.json();
  },
  
  purchaseItem: async (userId: string, itemId: number) => {
    const res = await fetch(`/api/leveling/shop/purchase`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, itemId }),
      credentials: 'include',
    });
    await throwIfResNotOk(res);
    return res.json();
  },
  
  transferCoins: async (fromUserId: string, toUserId: string, amount: number) => {
    const res = await fetch(`/api/leveling/transfer`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fromUserId, toUserId, amount }),
      credentials: 'include',
    });
    await throwIfResNotOk(res);
    return res.json();
  },
  
  // وظائف نظام الاقتباسات
  getQuotes: async (userId?: string) => {
    const url = userId 
      ? `/api/leveling/users/${userId}/quotes`
      : '/api/leveling/quotes';
      
    const res = await fetch(url, {
      credentials: 'include',
    });
    await throwIfResNotOk(res);
    return res.json();
  },
  
  addQuote: async (userId: string, content: string) => {
    const res = await fetch(`/api/leveling/quotes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, content }),
      credentials: 'include',
    });
    await throwIfResNotOk(res);
    return res.json();
  }
};

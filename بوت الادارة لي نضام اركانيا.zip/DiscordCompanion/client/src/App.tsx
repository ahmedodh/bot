import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import Dashboard from "@/pages/Dashboard";
import Commands from "@/pages/Commands";
import EventHandlers from "@/pages/EventHandlers";
import Logs from "@/pages/Logs";
import Settings from "@/pages/Settings";
import Deployment from "@/pages/Deployment";
import Leveling from "@/pages/Leveling";
import Shop from "./pages/Shop";
import Economy from "./pages/Economy";
import Quotes from "./pages/Quotes";
import Clans from "./pages/Clans";
import ClanWars from "./pages/ClanWars";
import AiAssistant from "./pages/AiAssistant";
import NotFound from "@/pages/not-found";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";

function Router() {
  const [location] = useLocation();
  
  return (
    <div className="flex h-screen bg-[#36393F] text-white">
      <Sidebar currentPath={location} />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Header pageTitle={getPageTitle(location)} />
        <div className="flex-1 overflow-y-auto p-6">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/commands" component={Commands} />
            <Route path="/events" component={EventHandlers} />
            <Route path="/logs" component={Logs} />
            <Route path="/settings" component={Settings} />
            <Route path="/deployment" component={Deployment} />
            <Route path="/leveling" component={Leveling} />
            <Route path="/shop" component={Shop} />
            <Route path="/economy" component={Economy} />
            <Route path="/quotes" component={Quotes} />
            <Route path="/clans" component={Clans} />
            <Route path="/clan-wars" component={ClanWars} />
            <Route path="/ai-assistant" component={AiAssistant} />
            <Route component={NotFound} />
          </Switch>
        </div>
      </div>
    </div>
  );
}

function getPageTitle(path: string): string {
  switch (path) {
    case "/":
      return "الرئيسية";
    case "/commands":
      return "الأوامر";
    case "/events":
      return "مراقبة الأحداث";
    case "/logs":
      return "السجلات";
    case "/settings":
      return "إعدادات البوت";
    case "/deployment":
      return "النشر والتفعيل";
    case "/leveling":
      return "نظام المستويات والترقيات";
    case "/shop":
      return "متجر العناصر";
    case "/economy":
      return "نظام الاقتصاد";
    case "/quotes":
      return "نظام الاقتباسات";
    case "/clans":
      return "نظام العشائر";
    case "/clan-wars":
      return "حرب العشائر";
    case "/ai-assistant":
      return "المساعد الذكي";
    default:
      return "الصفحة غير موجودة";
  }
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
    </QueryClientProvider>
  );
}

export default App;

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";

export default function EventHandlers() {
  const events = [
    {
      name: "ready",
      description: "Emitted when the client becomes ready to start working",
      implementation: "client.once('ready', () => {\n  console.log(`Logged in as ${client.user.tag}`);\n});"
    },
    {
      name: "messageCreate",
      description: "Emitted when a message is created",
      implementation: "client.on('messageCreate', async (message) => {\n  if (message.author.bot) return;\n  \n  if (message.content.startsWith('!ping')) {\n    await message.reply('Pong!');\n  }\n});"
    },
    {
      name: "guildCreate",
      description: "Emitted when the client joins a guild",
      implementation: "client.on('guildCreate', (guild) => {\n  console.log(`Joined a new guild: ${guild.name}`);\n});"
    },
    {
      name: "guildMemberAdd",
      description: "Emitted when a user joins a guild",
      implementation: "client.on('guildMemberAdd', async (member) => {\n  const channel = member.guild.systemChannel;\n  if (channel) {\n    await channel.send(`Welcome to the server, ${member}!`);\n  }\n});"
    },
    {
      name: "interactionCreate",
      description: "Emitted when an interaction is created",
      implementation: "client.on('interactionCreate', async (interaction) => {\n  if (!interaction.isCommand()) return;\n  \n  if (interaction.commandName === 'ping') {\n    await interaction.reply('Pong!');\n  }\n});"
    }
  ];
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white mb-2">Event Handlers</h1>
        <p className="text-[#B9BBBE]">
          Discord.js provides various events that you can listen to in your bot. 
          Here are some common event handlers implemented in this bot.
        </p>
      </div>
      
      <Card className="bg-[#292B2F] border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">What are Events?</CardTitle>
          <CardDescription className="text-[#B9BBBE]">
            Events are actions or occurrences that happen in your Discord bot that you can react to. 
            The Discord.js library emits events when certain actions occur, allowing your bot to respond accordingly.
          </CardDescription>
        </CardHeader>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {events.map((event, index) => (
          <Card key={index} className="bg-[#292B2F] border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-white">{event.name}</CardTitle>
              <CardDescription className="text-[#B9BBBE]">
                {event.description}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="bg-[#2F3136] p-4 text-[#B9BBBE] font-mono text-sm rounded-md overflow-x-auto">
                {event.implementation}
              </pre>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <Card className="bg-[#292B2F] border-gray-700">
        <CardHeader className="pb-2">
          <CardTitle className="text-white flex items-center">
            <AlertTriangle className="text-[#FAA61A] mr-2 h-5 w-5" />
            Best Practices
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-[#B9BBBE]">
            <li>• Always handle errors in event handlers to prevent your bot from crashing</li>
            <li>• Use client.once() for one-time events like 'ready'</li>
            <li>• Use client.on() for recurring events</li>
            <li>• Keep your event handlers modular and organized</li>
            <li>• Consider using a command handler pattern for better organization</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Log } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Trash2, AlertTriangle, AlertCircle, Info, Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

export default function Logs() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Get logs
  const { 
    data: logs, 
    isLoading, 
    error 
  } = useQuery<Log[]>({
    queryKey: ['/api/logs'],
  });
  
  // Clear logs mutation
  const clearLogsMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("DELETE", "/api/logs", null);
    },
    onSuccess: () => {
      toast({
        title: "Logs cleared",
        description: "All logs have been cleared successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/logs'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to clear logs: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const handleClearLogs = () => {
    if (window.confirm("Are you sure you want to clear all logs?")) {
      clearLogsMutation.mutate();
    }
  };
  
  // Filter logs by type
  const errorLogs = logs?.filter(log => log.type === 'error') || [];
  const warningLogs = logs?.filter(log => log.type === 'warning') || [];
  const infoLogs = logs?.filter(log => log.type === 'info') || [];
  const commandLogs = logs?.filter(log => log.type === 'command') || [];
  
  const formatLogDate = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, 'MMM dd, yyyy HH:mm:ss');
  };
  
  const getLogIcon = (type: string) => {
    switch (type) {
      case 'error':
        return <AlertCircle className="text-[#ED4245] h-5 w-5 mr-2" />;
      case 'warning':
        return <AlertTriangle className="text-[#FAA61A] h-5 w-5 mr-2" />;
      case 'info':
        return <Info className="text-[#5865F2] h-5 w-5 mr-2" />;
      case 'command':
        return <Clock className="text-[#43B581] h-5 w-5 mr-2" />;
      default:
        return <Info className="text-[#5865F2] h-5 w-5 mr-2" />;
    }
  };
  
  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-white">Logs</h1>
          <Skeleton className="h-10 w-24" />
        </div>
        
        <Card className="bg-[#292B2F] border-gray-700">
          <CardHeader>
            <Skeleton className="h-8 w-32" />
          </CardHeader>
          <CardContent>
            {[...Array(5)].map((_, i) => (
              <div key={i} className="mb-4">
                <div className="flex justify-between mb-2">
                  <Skeleton className="h-5 w-32" />
                  <Skeleton className="h-4 w-40" />
                </div>
                <Skeleton className="h-4 w-full" />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Logs</h1>
        <Button 
          variant="destructive"
          onClick={handleClearLogs}
          disabled={clearLogsMutation.isPending || (logs?.length || 0) === 0}
        >
          <Trash2 className="mr-2 h-4 w-4" />
          {clearLogsMutation.isPending ? "Clearing..." : "Clear All Logs"}
        </Button>
      </div>
      
      <Tabs defaultValue="all">
        <TabsList className="bg-[#36393F] border-gray-700">
          <TabsTrigger value="all">All ({logs?.length || 0})</TabsTrigger>
          <TabsTrigger value="errors">Errors ({errorLogs.length})</TabsTrigger>
          <TabsTrigger value="warnings">Warnings ({warningLogs.length})</TabsTrigger>
          <TabsTrigger value="info">Info ({infoLogs.length})</TabsTrigger>
          <TabsTrigger value="commands">Commands ({commandLogs.length})</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          <LogsPanel logs={logs || []} formatLogDate={formatLogDate} getLogIcon={getLogIcon} />
        </TabsContent>
        
        <TabsContent value="errors">
          <LogsPanel logs={errorLogs} formatLogDate={formatLogDate} getLogIcon={getLogIcon} />
        </TabsContent>
        
        <TabsContent value="warnings">
          <LogsPanel logs={warningLogs} formatLogDate={formatLogDate} getLogIcon={getLogIcon} />
        </TabsContent>
        
        <TabsContent value="info">
          <LogsPanel logs={infoLogs} formatLogDate={formatLogDate} getLogIcon={getLogIcon} />
        </TabsContent>
        
        <TabsContent value="commands">
          <LogsPanel logs={commandLogs} formatLogDate={formatLogDate} getLogIcon={getLogIcon} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

interface LogsPanelProps {
  logs: Log[];
  formatLogDate: (dateString: string) => string;
  getLogIcon: (type: string) => React.ReactNode;
}

function LogsPanel({ logs, formatLogDate, getLogIcon }: LogsPanelProps) {
  if (logs.length === 0) {
    return (
      <Card className="bg-[#292B2F] border-gray-700 mt-2">
        <CardContent className="text-center p-6">
          <p className="text-[#B9BBBE]">No logs available.</p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="bg-[#292B2F] border-gray-700 mt-2">
      <CardContent className="p-0">
        <div className="divide-y divide-gray-700">
          {logs.map(log => (
            <div key={log.id} className="p-4 hover:bg-[#36393F]">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center">
                  {getLogIcon(log.type)}
                  <span className="font-medium">
                    {log.type.charAt(0).toUpperCase() + log.type.slice(1)}
                  </span>
                </div>
                <div className="text-[#B9BBBE] text-sm">
                  {formatLogDate(log.timestamp)}
                </div>
              </div>
              <p className="text-[#B9BBBE] ml-7">{log.message}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

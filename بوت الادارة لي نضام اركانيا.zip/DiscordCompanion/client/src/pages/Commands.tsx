import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Command } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Pencil, Trash2, Save, Plus } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { z } from "zod";
import { insertCommandSchema } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export default function Commands() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // State for editing mode
  const [editMode, setEditMode] = useState<number | null>(null);
  const [newCommand, setNewCommand] = useState<boolean>(false);
  
  // Form state
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [enabled, setEnabled] = useState(true);
  
  // Get commands
  const { 
    data: commands, 
    isLoading, 
    error 
  } = useQuery<Command[]>({
    queryKey: ['/api/commands'],
  });
  
  // Create command mutation
  const createCommandMutation = useMutation({
    mutationFn: async (command: { name: string; description: string; enabled: boolean }) => {
      return apiRequest("POST", "/api/commands", command);
    },
    onSuccess: () => {
      toast({
        title: "Command created",
        description: "The command has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/commands'] });
      cancelEdit();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create command: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Update command mutation
  const updateCommandMutation = useMutation({
    mutationFn: async ({ id, command }: { id: number; command: Partial<{ name: string; description: string; enabled: boolean }> }) => {
      return apiRequest("PATCH", `/api/commands/${id}`, command);
    },
    onSuccess: () => {
      toast({
        title: "Command updated",
        description: "The command has been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/commands'] });
      cancelEdit();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update command: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Delete command mutation
  const deleteCommandMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/commands/${id}`, null);
    },
    onSuccess: () => {
      toast({
        title: "Command deleted",
        description: "The command has been deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/commands'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete command: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Start editing a command
  const startEdit = (command: Command) => {
    setEditMode(command.id);
    setName(command.name);
    setDescription(command.description);
    setEnabled(command.enabled);
    setNewCommand(false);
  };
  
  // Start creating a new command
  const startNewCommand = () => {
    setNewCommand(true);
    setEditMode(null);
    setName("");
    setDescription("");
    setEnabled(true);
  };
  
  // Cancel editing
  const cancelEdit = () => {
    setEditMode(null);
    setNewCommand(false);
  };
  
  // Save command changes
  const saveChanges = () => {
    try {
      // Validate form data
      const commandSchema = z.object({
        name: z.string().min(1, "Name is required"),
        description: z.string().min(1, "Description is required"),
        enabled: z.boolean()
      });
      
      const formData = {
        name,
        description,
        enabled
      };
      
      const result = commandSchema.safeParse(formData);
      
      if (!result.success) {
        toast({
          title: "Validation Error",
          description: result.error.errors[0].message,
          variant: "destructive",
        });
        return;
      }
      
      if (newCommand) {
        createCommandMutation.mutate(formData);
      } else if (editMode !== null) {
        updateCommandMutation.mutate({ id: editMode, command: formData });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    }
  };
  
  // Delete a command
  const deleteCommand = (id: number, name: string) => {
    if (window.confirm(`Are you sure you want to delete the command ${name}?`)) {
      deleteCommandMutation.mutate(id);
    }
  };
  
  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-white">Commands</h1>
          <Skeleton className="h-10 w-32" />
        </div>
        
        {[...Array(5)].map((_, i) => (
          <Card key={i} className="bg-[#292B2F] border-gray-700">
            <CardHeader className="pb-2">
              <Skeleton className="h-6 w-40" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-4 w-full mb-4" />
              <div className="flex justify-between">
                <Skeleton className="h-8 w-24" />
                <div className="space-x-2">
                  <Skeleton className="h-9 w-9 inline-block" />
                  <Skeleton className="h-9 w-9 inline-block" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Commands</h1>
        <Button 
          onClick={startNewCommand}
          className="bg-[#5865F2] hover:bg-opacity-80 text-white"
          disabled={newCommand || editMode !== null}
        >
          <Plus className="mr-2 h-4 w-4" />
          Add New Command
        </Button>
      </div>
      
      {newCommand && (
        <Card className="bg-[#292B2F] border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-white">New Command</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Command Name</Label>
                <Input 
                  id="name"
                  placeholder="!commandname"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="bg-[#36393F] border-gray-700 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea 
                  id="description"
                  placeholder="What does this command do?"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="bg-[#36393F] border-gray-700 text-white min-h-[80px]"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch 
                  id="enabled" 
                  checked={enabled} 
                  onCheckedChange={setEnabled} 
                />
                <Label htmlFor="enabled">Enabled</Label>
              </div>
              <div className="flex justify-end space-x-2 pt-2">
                <Button variant="outline" onClick={cancelEdit}>
                  Cancel
                </Button>
                <Button 
                  onClick={saveChanges}
                  className="bg-[#5865F2] hover:bg-opacity-80 text-white"
                  disabled={createCommandMutation.isPending}
                >
                  <Save className="mr-2 h-4 w-4" />
                  {createCommandMutation.isPending ? "Saving..." : "Save Command"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {commands?.map(command => (
        <Card key={command.id} className="bg-[#292B2F] border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-white">{command.name}</CardTitle>
          </CardHeader>
          <CardContent>
            {editMode === command.id ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor={`name-${command.id}`}>Command Name</Label>
                  <Input 
                    id={`name-${command.id}`}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="bg-[#36393F] border-gray-700 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor={`description-${command.id}`}>Description</Label>
                  <Textarea 
                    id={`description-${command.id}`}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="bg-[#36393F] border-gray-700 text-white min-h-[80px]"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch 
                    id={`enabled-${command.id}`} 
                    checked={enabled} 
                    onCheckedChange={setEnabled} 
                  />
                  <Label htmlFor={`enabled-${command.id}`}>Enabled</Label>
                </div>
                <div className="flex justify-end space-x-2 pt-2">
                  <Button variant="outline" onClick={cancelEdit}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={saveChanges}
                    className="bg-[#5865F2] hover:bg-opacity-80 text-white"
                    disabled={updateCommandMutation.isPending}
                  >
                    <Save className="mr-2 h-4 w-4" />
                    {updateCommandMutation.isPending ? "Saving..." : "Save Changes"}
                  </Button>
                </div>
              </div>
            ) : (
              <>
                <p className="text-[#B9BBBE] mb-4">{command.description}</p>
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id={`enabled-view-${command.id}`} 
                      checked={command.enabled} 
                      disabled
                    />
                    <Label htmlFor={`enabled-view-${command.id}`} className="text-[#B9BBBE]">
                      {command.enabled ? "Enabled" : "Disabled"}
                    </Label>
                  </div>
                  <div className="flex space-x-2">
                    <Button 
                      size="icon"
                      variant="outline" 
                      onClick={() => startEdit(command)}
                      disabled={editMode !== null || newCommand}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="icon"
                      variant="destructive" 
                      onClick={() => deleteCommand(command.id, command.name)}
                      disabled={deleteCommandMutation.isPending}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      ))}
      
      {commands?.length === 0 && !newCommand && (
        <Card className="bg-[#292B2F] border-gray-700">
          <CardContent className="text-center p-6">
            <p className="text-[#B9BBBE]">No commands available. Add your first command using the button above.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

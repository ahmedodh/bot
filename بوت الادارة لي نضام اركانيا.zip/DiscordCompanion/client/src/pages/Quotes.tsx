import { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Quote, 
  Plus, 
  RefreshCw, 
  Loader2, 
  AlertCircle,
  User,
  CalendarDays
} from "lucide-react";
import { levelingSystem } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";

interface QuoteData {
  content: string;
  author: string;
  date: string;
  userId: string;
}

export default function Quotes() {
  const [quotes, setQuotes] = useState<QuoteData[]>([]);
  const [users, setUsers] = useState<{ userId: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [newQuote, setNewQuote] = useState('');
  const [selectedUser, setSelectedUser] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);

  // جلب الاقتباسات
  const fetchQuotes = async () => {
    try {
      setLoading(true);
      const data = await levelingSystem.getQuotes();
      setQuotes(data);
    } catch (error) {
      console.error("Error fetching quotes:", error);
      toast({
        title: "خطأ",
        description: "فشل في جلب الاقتباسات",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // جلب المستخدمين
  const fetchUsers = async () => {
    try {
      const data = await levelingSystem.getUsers();
      setUsers(data);
      if (data.length > 0 && !selectedUser) {
        setSelectedUser(data[0].userId);
      }
    } catch (error) {
      console.error("Error fetching users:", error);
      toast({
        title: "خطأ",
        description: "فشل في جلب بيانات المستخدمين",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    fetchQuotes();
    fetchUsers();
  }, []);

  // إضافة اقتباس جديد
  const addNewQuote = async () => {
    if (!newQuote.trim() || !selectedUser) {
      toast({
        title: "خطأ",
        description: "الرجاء إدخال نص الاقتباس واختيار المستخدم",
        variant: "destructive",
      });
      return;
    }

    try {
      setAdding(true);
      await levelingSystem.addQuote(selectedUser, newQuote);
      
      // تحديث قائمة الاقتباسات
      await fetchQuotes();
      
      // إعادة تعيين النموذج
      setNewQuote('');
      setDialogOpen(false);
      
      toast({
        title: "تمت الإضافة",
        description: "تم إضافة الاقتباس بنجاح",
      });
    } catch (error: any) {
      console.error("Error adding quote:", error);
      
      // رسالة خطأ مخصصة إذا كان المستخدم لا يملك عناصر "اقتباس"
      if (error.message?.includes("User does not have a quote slot")) {
        toast({
          title: "خطأ",
          description: "المستخدم لا يملك عناصر اقتباس. يرجى شراؤها من المتجر أولاً.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "خطأ",
          description: "فشل في إضافة الاقتباس",
          variant: "destructive",
        });
      }
    } finally {
      setAdding(false);
    }
  };

  // تنسيق التاريخ
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">نظام الاقتباسات</h1>
          <p className="text-muted-foreground">إدارة ومشاركة الاقتباسات المميزة من المستخدمين</p>
        </div>
        <div className="flex items-center gap-2">
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="mr-2">
                <Plus className="h-4 w-4 mr-2" />
                إضافة اقتباس
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[525px]">
              <DialogHeader>
                <DialogTitle>إضافة اقتباس جديد</DialogTitle>
                <DialogDescription>
                  أضف اقتباسًا جديدًا يمكن استخدامه في القناة
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium mb-1 block">المستخدم</label>
                  <Select 
                    value={selectedUser} 
                    onValueChange={setSelectedUser}
                    disabled={users.length === 0}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="اختر المستخدم" />
                    </SelectTrigger>
                    <SelectContent>
                      {users.map(user => (
                        <SelectItem key={user.userId} value={user.userId}>
                          {user.userId}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium mb-1 block">نص الاقتباس</label>
                  <Textarea
                    placeholder="أدخل الاقتباس هنا..."
                    value={newQuote}
                    onChange={(e) => setNewQuote(e.target.value)}
                    rows={5}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button onClick={addNewQuote} disabled={adding}>
                  {adding ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Quote className="h-4 w-4 mr-2" />
                  )}
                  إضافة الاقتباس
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          <Button 
            variant="outline"
            size="icon" 
            onClick={fetchQuotes}
            disabled={loading}
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : quotes.length === 0 ? (
        <Card>
          <CardContent className="p-8 flex flex-col items-center justify-center">
            <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium text-center">لا توجد اقتباسات متاحة</p>
            <p className="text-muted-foreground text-center mt-2">أضف أول اقتباس باستخدام زر "إضافة اقتباس"</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {quotes.map((quote, index) => (
            <Card key={index} className="overflow-hidden">
              <CardHeader className="pb-3 bg-gradient-to-r from-[#3F4679] to-[#282A36]">
                <CardTitle className="flex items-center text-xl">
                  <Quote className="h-5 w-5 mr-2 text-[#5865F2]" />
                  اقتباس {index + 1}
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6 pb-0">
                <blockquote className="border-r-4 border-[#5865F2] pr-4 italic">
                  {quote.content}
                </blockquote>
              </CardContent>
              <CardFooter className="flex-col items-start pt-6">
                <div className="flex items-center text-sm text-muted-foreground mb-1">
                  <User className="h-3.5 w-3.5 mr-1" />
                  <span>{quote.userId || quote.author}</span>
                </div>
                <div className="flex items-center text-sm text-muted-foreground">
                  <CalendarDays className="h-3.5 w-3.5 mr-1" />
                  <span>{formatDate(quote.date)}</span>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
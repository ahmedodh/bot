import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Label } from "@/components/ui/label";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { 
  PlusCircle, 
  CheckCircle2, 
  Trophy, 
  Timer, 
  Calendar, 
  Users, 
  Award, 
  BookText, 
  Clock, 
  Target,
  Sparkles,
  Flame,
  ArrowUp,
  ArrowDown,
  BarChart4,
  AlertTriangle,
  Loader2
} from "lucide-react";

// مخطط إنشاء مهمة جديدة
const createTaskSchema = z.object({
  description: z.string().min(3, { message: "يجب أن يحتوي وصف المهمة على 3 أحرف على الأقل" }).max(200, { message: "الوصف طويل جدًا" }),
  type: z.enum(["daily", "group", "skill"], {
    required_error: "يرجى اختيار نوع المهمة",
  }),
  expectedTime: z.number().min(5, { message: "يجب أن يكون الوقت المتوقع 5 دقائق على الأقل" }).max(480, { message: "الوقت المتوقع لا يمكن أن يتجاوز 8 ساعات" }),
  deadline: z.date().optional(),
});

// مخطط إكمال مهمة
const completeTaskSchema = z.object({
  taskId: z.number(),
  timeSpent: z.number().min(1, { message: "يجب إدخال الوقت المستغرق" }),
});

// واجهة المهمة
interface Task {
  id: number;
  userId: number;
  serverId: string;
  description: string;
  type: "daily" | "group" | "skill";
  points: number;
  expectedTime: number;
  completed: boolean;
  timeSpent: number | null;
  deadline: string | null;
  createdAt: string;
  completedAt: string | null;
}

// واجهة إحصائيات الإنتاجية
interface ProductivityStats {
  id: number;
  userId: number;
  dailyTasksCompleted: number;
  groupTasksCompleted: number;
  skillTasksCompleted: number;
  totalPointsEarned: number;
  averageCompletionTime: number;
  streak: number;
  lastActiveDate: string;
  updatedAt: string;
}

// واجهة الإنجازات
interface Achievement {
  id: number;
  name: string;
  description: string;
  iconUrl: string;
  requiredPoints: number;
  type: string;
  rarity: "common" | "rare" | "epic" | "legendary";
  createdAt: string;
  earned?: boolean;
  earnedAt?: string;
}

// واجهة تحدي العشيرة
interface ClanChallenge {
  id: number;
  clanId: number;
  title: string;
  description: string;
  points: number;
  requiredMembers: number;
  currentMembers: number;
  deadline: string;
  completed: boolean;
  createdAt: string;
  completedAt: string | null;
}

// واجهة الترتيب
interface LeaderboardEntry {
  userId: number;
  username?: string;
  totalPoints: number;
  streak: number;
  tasksCompleted: number;
  rank?: number;
}

export default function Productivity() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("tasks");
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isCompleteDialogOpen, setIsCompleteDialogOpen] = useState(false);
  
  // استعلام للحصول على المهام الحالية
  const { data: tasks = [], isLoading: isLoadingTasks } = useQuery({
    queryKey: ["/api/tasks"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/tasks");
      const data = await response.json();
      return data;
    }
  });
  
  // استعلام للحصول على المهام المكتملة
  const { data: completedTasks = [], isLoading: isLoadingCompletedTasks } = useQuery({
    queryKey: ["/api/tasks/completed"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/tasks/completed");
      const data = await response.json();
      return data;
    }
  });
  
  // استعلام للحصول على إحصائيات الإنتاجية
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/productivity/stats"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/productivity/stats");
      const data = await response.json();
      return data;
    }
  });
  
  // استعلام للحصول على الإنجازات
  const { data: achievements = [], isLoading: isLoadingAchievements } = useQuery({
    queryKey: ["/api/achievements"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/achievements");
      const data = await response.json();
      return data;
    }
  });
  
  // استعلام للحصول على تحديات العشيرة
  const { data: clanChallenges = [], isLoading: isLoadingClanChallenges } = useQuery({
    queryKey: ["/api/clan-challenges"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/clan-challenges");
      const data = await response.json();
      return data;
    }
  });
  
  // استعلام للحصول على الترتيب
  const { data: leaderboard = [], isLoading: isLoadingLeaderboard } = useQuery({
    queryKey: ["/api/productivity/leaderboard"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/productivity/leaderboard");
      const data = await response.json();
      return data.map((entry, index) => ({
        ...entry,
        rank: index + 1
      }));
    }
  });
  
  // استعلام للحصول على المهام المقترحة
  const { data: suggestedTask, isLoading: isLoadingSuggestedTask } = useQuery({
    queryKey: ["/api/tasks/suggested"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/tasks/suggested");
      const data = await response.json();
      return data;
    },
    enabled: tasks.length < 5 // تمكين فقط إذا كان عدد المهام أقل من 5
  });
  
  // إنشاء نموذج إنشاء مهمة
  const createTaskForm = useForm<z.infer<typeof createTaskSchema>>({
    resolver: zodResolver(createTaskSchema),
    defaultValues: {
      description: "",
      type: "daily",
      expectedTime: 30,
    },
  });
  
  // إنشاء نموذج إكمال مهمة
  const completeTaskForm = useForm<z.infer<typeof completeTaskSchema>>({
    resolver: zodResolver(completeTaskSchema),
    defaultValues: {
      taskId: 0,
      timeSpent: 0,
    },
  });
  
  // طلب إنشاء مهمة جديدة
  const createTaskMutation = useMutation({
    mutationFn: async (data: z.infer<typeof createTaskSchema>) => {
      const response = await apiRequest("POST", "/api/tasks", data);
      const result = await response.json();
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      createTaskForm.reset();
      
      toast({
        title: "تم إنشاء المهمة بنجاح",
        description: "تمت إضافة المهمة الجديدة إلى قائمة المهام الخاصة بك",
      });
    },
    onError: (error) => {
      console.error("خطأ في إنشاء المهمة:", error);
      
      toast({
        title: "فشل في إنشاء المهمة",
        description: "حدث خطأ أثناء إنشاء المهمة. يرجى المحاولة مرة أخرى.",
        variant: "destructive"
      });
    }
  });
  
  // طلب إكمال مهمة
  const completeTaskMutation = useMutation({
    mutationFn: async (data: z.infer<typeof completeTaskSchema>) => {
      const response = await apiRequest("POST", `/api/tasks/${data.taskId}/complete`, { timeSpent: data.timeSpent });
      const result = await response.json();
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/completed"] });
      queryClient.invalidateQueries({ queryKey: ["/api/productivity/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/achievements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/productivity/leaderboard"] });
      
      setIsCompleteDialogOpen(false);
      completeTaskForm.reset();
      setSelectedTask(null);
      
      toast({
        title: "تم إكمال المهمة بنجاح",
        description: "أحسنت! تم إكمال المهمة وإضافة النقاط إلى رصيدك",
      });
    },
    onError: (error) => {
      console.error("خطأ في إكمال المهمة:", error);
      
      toast({
        title: "فشل في إكمال المهمة",
        description: "حدث خطأ أثناء إكمال المهمة. يرجى المحاولة مرة أخرى.",
        variant: "destructive"
      });
    }
  });
  
  // طلب استخدام المهمة المقترحة
  const useSuggestedTaskMutation = useMutation({
    mutationFn: async () => {
      if (!suggestedTask) return null;
      
      const response = await apiRequest("POST", "/api/tasks", suggestedTask);
      const result = await response.json();
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/suggested"] });
      
      toast({
        title: "تم إضافة المهمة المقترحة",
        description: "تمت إضافة المهمة المقترحة إلى قائمة المهام الخاصة بك",
      });
    },
    onError: (error) => {
      console.error("خطأ في إضافة المهمة المقترحة:", error);
      
      toast({
        title: "فشل في إضافة المهمة المقترحة",
        description: "حدث خطأ أثناء إضافة المهمة المقترحة. يرجى المحاولة مرة أخرى.",
        variant: "destructive"
      });
    }
  });
  
  // تحضير المهمة للإكمال
  const prepareTaskForCompletion = (task: Task) => {
    setSelectedTask(task);
    completeTaskForm.setValue("taskId", task.id);
    completeTaskForm.setValue("timeSpent", task.expectedTime);
    setIsCompleteDialogOpen(true);
  };
  
  // استخدام المهمة المقترحة
  const handleUseSuggestedTask = () => {
    useSuggestedTaskMutation.mutate();
  };
  
  // الحصول على لون بطاقة المهمة بناءً على نوعها
  const getTaskCardColor = (type: string) => {
    switch (type) {
      case "daily":
        return "bg-gradient-to-br from-blue-800/20 to-blue-900/40 border-blue-500/30";
      case "group":
        return "bg-gradient-to-br from-purple-800/20 to-purple-900/40 border-purple-500/30";
      case "skill":
        return "bg-gradient-to-br from-green-800/20 to-green-900/40 border-green-500/30";
      default:
        return "bg-gradient-to-br from-gray-800/20 to-gray-900/40 border-gray-500/30";
    }
  };
  
  // الحصول على لون شارة نوع المهمة
  const getTaskTypeBadgeColor = (type: string) => {
    switch (type) {
      case "daily":
        return "bg-blue-500/50 hover:bg-blue-500/70";
      case "group":
        return "bg-purple-500/50 hover:bg-purple-500/70";
      case "skill":
        return "bg-green-500/50 hover:bg-green-500/70";
      default:
        return "bg-gray-500/50 hover:bg-gray-500/70";
    }
  };
  
  // الحصول على نص نوع المهمة بالعربية
  const getTaskTypeText = (type: string) => {
    switch (type) {
      case "daily":
        return "مهمة يومية";
      case "group":
        return "مهمة جماعية";
      case "skill":
        return "مهمة مهارات";
      default:
        return "مهمة";
    }
  };
  
  // الحصول على أيقونة نوع المهمة
  const getTaskTypeIcon = (type: string) => {
    switch (type) {
      case "daily":
        return <Calendar className="h-4 w-4" />;
      case "group":
        return <Users className="h-4 w-4" />;
      case "skill":
        return <BookText className="h-4 w-4" />;
      default:
        return <Target className="h-4 w-4" />;
    }
  };
  
  // الحصول على لون شارة نادرة الإنجاز
  const getAchievementRarityColor = (rarity: string) => {
    switch (rarity) {
      case "common":
        return "bg-gray-600 hover:bg-gray-500";
      case "rare":
        return "bg-blue-600 hover:bg-blue-500";
      case "epic":
        return "bg-purple-600 hover:bg-purple-500";
      case "legendary":
        return "bg-amber-600 hover:bg-amber-500";
      default:
        return "bg-gray-600 hover:bg-gray-500";
    }
  };
  
  // تنسيق الوقت
  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    
    if (hours === 0) {
      return `${mins} دقيقة`;
    } else if (mins === 0) {
      return `${hours} ساعة`;
    } else {
      return `${hours} ساعة و ${mins} دقيقة`;
    }
  };
  
  // تنسيق التاريخ
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric'
    }).format(date);
  };
  
  return (
    <div className="flex flex-col space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">
          نظام المهام والإنتاجية
        </h1>
      </div>
      
      {/* الإحصائيات */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-blue-800/20 to-blue-900/40 border-blue-500/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center">
                <Trophy className="h-4 w-4 ml-2 text-yellow-500" />
                إجمالي النقاط
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {stats.totalPointsEarned}
                <span className="text-sm font-normal text-blue-400 mr-1">نقطة</span>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-amber-800/20 to-amber-900/40 border-amber-500/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center">
                <Flame className="h-4 w-4 ml-2 text-amber-500" />
                سلسلة النشاط
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {stats.streak}
                <span className="text-sm font-normal text-amber-400 mr-1">يوم متتالي</span>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-green-800/20 to-green-900/40 border-green-500/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center">
                <CheckCircle2 className="h-4 w-4 ml-2 text-green-500" />
                المهام المكتملة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {stats.dailyTasksCompleted + stats.groupTasksCompleted + stats.skillTasksCompleted}
                <span className="text-sm font-normal text-green-400 mr-1">مهمة</span>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-800/20 to-purple-900/40 border-purple-500/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center">
                <Clock className="h-4 w-4 ml-2 text-purple-500" />
                متوسط وقت الإنجاز
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {formatTime(stats.averageCompletionTime)}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      
      {/* التبويبات */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full space-y-4">
        <TabsList className="grid w-full grid-cols-1 md:grid-cols-4">
          <TabsTrigger value="tasks" className="flex items-center">
            <Target className="h-4 w-4 ml-2" />
            <span>المهام الحالية</span>
          </TabsTrigger>
          <TabsTrigger value="achievements" className="flex items-center">
            <Award className="h-4 w-4 ml-2" />
            <span>الإنجازات</span>
          </TabsTrigger>
          <TabsTrigger value="challenges" className="flex items-center">
            <Users className="h-4 w-4 ml-2" />
            <span>تحديات العشيرة</span>
          </TabsTrigger>
          <TabsTrigger value="leaderboard" className="flex items-center">
            <BarChart4 className="h-4 w-4 ml-2" />
            <span>الترتيب</span>
          </TabsTrigger>
        </TabsList>
        
        {/* قسم المهام */}
        <TabsContent value="tasks" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle>المهام الحالية</CardTitle>
                  <CardDescription>قائمة المهام التي يمكنك العمل عليها</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingTasks ? (
                    <div className="flex justify-center items-center h-40">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : tasks.length === 0 ? (
                    <div className="text-center py-8 px-4">
                      <Target className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                      <h3 className="text-lg font-medium mb-1">ليس لديك أي مهام حاليًا</h3>
                      <p className="text-gray-500 text-sm mb-4">أضف مهمة جديدة وابدأ في تحسين إنتاجيتك</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-3">
                      {tasks.map((task) => (
                        <div 
                          key={task.id} 
                          className={`p-4 rounded-lg border ${getTaskCardColor(task.type)} transition-all hover:translate-y-[-2px]`}
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <div className="flex items-center gap-2 mb-2">
                                <Badge variant="outline" className={getTaskTypeBadgeColor(task.type)}>
                                  <div className="flex items-center">
                                    {getTaskTypeIcon(task.type)}
                                    <span className="mr-1">{getTaskTypeText(task.type)}</span>
                                  </div>
                                </Badge>
                                <Badge variant="outline" className="bg-yellow-500/20 hover:bg-yellow-500/30">
                                  <Trophy className="h-3 w-3 ml-1" />
                                  {task.points} نقطة
                                </Badge>
                              </div>
                              <h3 className="font-medium text-gray-100 mb-1">{task.description}</h3>
                              <div className="text-sm text-gray-400">
                                <div className="flex items-center mt-1">
                                  <Timer className="h-3 w-3 ml-1" />
                                  الوقت المتوقع: {formatTime(task.expectedTime)}
                                </div>
                                {task.deadline && (
                                  <div className="flex items-center mt-1">
                                    <Calendar className="h-3 w-3 ml-1" />
                                    الموعد النهائي: {formatDate(task.deadline)}
                                  </div>
                                )}
                              </div>
                            </div>
                            <Button
                              size="sm"
                              className="bg-green-600 hover:bg-green-500 text-white"
                              onClick={() => prepareTaskForCompletion(task)}
                            >
                              <CheckCircle2 className="h-4 w-4 ml-1" />
                              إكمال
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
              
              {completedTasks.length > 0 && (
                <Card className="mt-4">
                  <CardHeader className="pb-3">
                    <CardTitle>المهام المكتملة</CardTitle>
                    <CardDescription>المهام التي تم إنجازها مؤخرًا</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Accordion type="single" collapsible>
                      {completedTasks.slice(0, 5).map((task) => (
                        <AccordionItem key={task.id} value={`task-${task.id}`}>
                          <AccordionTrigger className="hover:no-underline">
                            <div className="flex flex-1 items-center">
                              <div className={`p-1 rounded-full ${task.type === 'daily' ? 'bg-blue-500/20' : task.type === 'group' ? 'bg-purple-500/20' : 'bg-green-500/20'} mr-2`}>
                                {getTaskTypeIcon(task.type)}
                              </div>
                              <span className="mr-2 text-left flex-1">{task.description}</span>
                              <Badge variant="outline" className="bg-yellow-500/20 mr-2">
                                <Trophy className="h-3 w-3 ml-1" />
                                {task.points} نقطة
                              </Badge>
                            </div>
                          </AccordionTrigger>
                          <AccordionContent>
                            <div className="pt-2 pb-1 px-1">
                              <div className="grid grid-cols-2 gap-2 text-sm">
                                <div>
                                  <div className="text-gray-400 mb-1">نوع المهمة:</div>
                                  <div>{getTaskTypeText(task.type)}</div>
                                </div>
                                <div>
                                  <div className="text-gray-400 mb-1">النقاط المكتسبة:</div>
                                  <div>{task.points} نقطة</div>
                                </div>
                                <div>
                                  <div className="text-gray-400 mb-1">الوقت المتوقع:</div>
                                  <div>{formatTime(task.expectedTime)}</div>
                                </div>
                                <div>
                                  <div className="text-gray-400 mb-1">الوقت المستغرق:</div>
                                  <div>{task.timeSpent ? formatTime(task.timeSpent) : 'غير متوفر'}</div>
                                </div>
                                <div>
                                  <div className="text-gray-400 mb-1">تاريخ الإنشاء:</div>
                                  <div>{formatDate(task.createdAt)}</div>
                                </div>
                                <div>
                                  <div className="text-gray-400 mb-1">تاريخ الإكمال:</div>
                                  <div>{task.completedAt ? formatDate(task.completedAt) : 'غير متوفر'}</div>
                                </div>
                              </div>
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>
                  </CardContent>
                </Card>
              )}
            </div>
            
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>إضافة مهمة جديدة</CardTitle>
                  <CardDescription>أنشئ مهمة جديدة وابدأ في تنفيذها</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...createTaskForm}>
                    <form onSubmit={createTaskForm.handleSubmit((data) => createTaskMutation.mutate(data))} className="space-y-4">
                      <FormField
                        control={createTaskForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>وصف المهمة</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="مثال: قراءة فصل من كتاب تطوير الذات" 
                                {...field} 
                                className="resize-none"
                              />
                            </FormControl>
                            <FormDescription>
                              اكتب وصفًا واضحًا للمهمة التي تريد إنجازها
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={createTaskForm.control}
                        name="type"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>نوع المهمة</FormLabel>
                            <FormControl>
                              <Select 
                                onValueChange={field.onChange} 
                                defaultValue={field.value}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر نوع المهمة" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="daily">
                                    <div className="flex items-center">
                                      <Calendar className="h-4 w-4 ml-2" />
                                      مهمة يومية
                                    </div>
                                  </SelectItem>
                                  <SelectItem value="group">
                                    <div className="flex items-center">
                                      <Users className="h-4 w-4 ml-2" />
                                      مهمة جماعية
                                    </div>
                                  </SelectItem>
                                  <SelectItem value="skill">
                                    <div className="flex items-center">
                                      <BookText className="h-4 w-4 ml-2" />
                                      مهمة مهارات
                                    </div>
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                            </FormControl>
                            <FormDescription>
                              يومية (10 نقاط) - جماعية (50 نقطة) - مهارات (30 نقطة)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={createTaskForm.control}
                        name="expectedTime"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>الوقت المتوقع (بالدقائق)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min={5}
                                max={480}
                                placeholder="30" 
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormDescription>
                              حدد الوقت المتوقع لإنجاز المهمة (5 دقائق - 8 ساعات)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full"
                        disabled={createTaskMutation.isPending}
                      >
                        {createTaskMutation.isPending ? (
                          <>
                            <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                            جاري الإنشاء...
                          </>
                        ) : (
                          <>
                            <PlusCircle className="ml-2 h-4 w-4" />
                            إنشاء المهمة
                          </>
                        )}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
              
              {/* المهمة المقترحة */}
              {suggestedTask && (
                <Card className="mt-4 bg-gradient-to-br from-indigo-800/30 to-indigo-900/50 border-indigo-500/30">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Sparkles className="h-5 w-5 ml-2 text-indigo-400" />
                      مهمة مقترحة لك
                    </CardTitle>
                    <CardDescription>
                      بناءً على نمط إنتاجيتك، نقترح عليك هذه المهمة
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4">
                      <div className="text-gray-200 mb-2 font-medium">{suggestedTask.description}</div>
                      <div className="flex items-center gap-4 text-sm text-gray-400">
                        <div className="flex items-center">
                          {getTaskTypeIcon(suggestedTask.type)}
                          <span className="mr-1">{getTaskTypeText(suggestedTask.type)}</span>
                        </div>
                        <div className="flex items-center">
                          <Timer className="h-4 w-4 ml-1" />
                          {formatTime(suggestedTask.expectedTime)}
                        </div>
                      </div>
                    </div>
                    <Button 
                      onClick={handleUseSuggestedTask} 
                      className="w-full bg-indigo-600 hover:bg-indigo-500"
                      disabled={useSuggestedTaskMutation.isPending}
                    >
                      {useSuggestedTaskMutation.isPending ? (
                        <>
                          <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                          جاري الإضافة...
                        </>
                      ) : (
                        <>
                          <PlusCircle className="ml-2 h-4 w-4" />
                          إضافة المهمة المقترحة
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              )}
              
              {/* تقدم اليوم */}
              {stats && (
                <Card className="mt-4 bg-gradient-to-br from-gray-800/20 to-gray-900/40 border-gray-500/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">تقدم اليوم</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <Label>المهام اليومية</Label>
                          <span className="text-sm text-gray-400">{stats.dailyTasksCompleted} مهمة</span>
                        </div>
                        <Progress value={Math.min(stats.dailyTasksCompleted * 20, 100)} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <Label>المهام الجماعية</Label>
                          <span className="text-sm text-gray-400">{stats.groupTasksCompleted} مهمة</span>
                        </div>
                        <Progress value={Math.min(stats.groupTasksCompleted * 33, 100)} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <Label>مهام المهارات</Label>
                          <span className="text-sm text-gray-400">{stats.skillTasksCompleted} مهمة</span>
                        </div>
                        <Progress value={Math.min(stats.skillTasksCompleted * 25, 100)} className="h-2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </TabsContent>
        
        {/* قسم الإنجازات */}
        <TabsContent value="achievements" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>الإنجازات والشارات</CardTitle>
              <CardDescription>
                الإنجازات والشارات التي حصلت عليها أثناء رحلتك نحو الإنتاجية
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingAchievements ? (
                <div className="flex justify-center items-center h-40">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : achievements.length === 0 ? (
                <div className="text-center py-8 px-4">
                  <Award className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                  <h3 className="text-lg font-medium mb-1">لا توجد إنجازات متاحة حاليًا</h3>
                  <p className="text-gray-500 text-sm mb-4">أكمل المزيد من المهام للحصول على إنجازات</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {achievements.map((achievement) => (
                    <div
                      key={achievement.id}
                      className={`border rounded-lg p-4 transition-all ${
                        achievement.earned 
                          ? "bg-gradient-to-br from-indigo-800/20 to-indigo-900/40 border-indigo-500/30" 
                          : "bg-gradient-to-br from-gray-800/10 to-gray-900/30 border-gray-600/20 opacity-70"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start">
                          <div className="mr-3">
                            <div className="w-12 h-12 rounded-full bg-indigo-900/50 border border-indigo-500/30 flex items-center justify-center">
                              <img
                                src={achievement.iconUrl}
                                alt={achievement.name}
                                className="w-8 h-8"
                                onError={(e) => {
                                  // إذا فشل تحميل الصورة، استخدم أيقونة افتراضية
                                  e.currentTarget.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%238B5CF6' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M12 2 L15.09 8.09 L22 9.4 L17 14.39 L18.18 21.6 L12 18.23 L5.82 21.6 L7 14.39 L2 9.4 L8.91 8.09 Z'%3E%3C/path%3E%3C/svg%3E";
                                }}
                              />
                            </div>
                          </div>
                          <div>
                            <h3 className="font-medium text-gray-100 mb-1">{achievement.name}</h3>
                            <p className="text-sm text-gray-400 mb-2">{achievement.description}</p>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className={getAchievementRarityColor(achievement.rarity)}>
                                {achievement.rarity === "common" ? "عادي" : 
                                  achievement.rarity === "rare" ? "نادر" : 
                                  achievement.rarity === "epic" ? "أسطوري" : "خارق"}
                              </Badge>
                              <Badge variant="outline" className="bg-yellow-500/20">
                                <Trophy className="h-3 w-3 ml-1" />
                                {achievement.requiredPoints} نقطة
                              </Badge>
                            </div>
                          </div>
                        </div>
                        {achievement.earned && (
                          <div className="flex-shrink-0">
                            <Badge className="bg-green-600">
                              <CheckCircle2 className="h-3 w-3 ml-1" />
                              مكتمل
                            </Badge>
                          </div>
                        )}
                      </div>
                      {achievement.earned && (
                        <div className="mt-3 text-xs text-gray-400 flex justify-end">
                          تم الحصول عليه: {formatDate(achievement.earnedAt!)}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* قسم تحديات العشيرة */}
        <TabsContent value="challenges" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>تحديات العشيرة</CardTitle>
              <CardDescription>
                التحديات الجماعية التي يمكنك المشاركة فيها مع أعضاء عشيرتك
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingClanChallenges ? (
                <div className="flex justify-center items-center h-40">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : clanChallenges.length === 0 ? (
                <div className="text-center py-8 px-4">
                  <Users className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                  <h3 className="text-lg font-medium mb-1">لا توجد تحديات متاحة حاليًا</h3>
                  <p className="text-gray-500 text-sm">انضم إلى عشيرة أو أنشئ تحديًا جديدًا</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  {clanChallenges.map((challenge) => (
                    <div 
                      key={challenge.id} 
                      className={`border rounded-lg p-4 ${
                        challenge.completed 
                          ? "bg-gradient-to-br from-green-800/20 to-green-900/40 border-green-500/30" 
                          : "bg-gradient-to-br from-purple-800/20 to-purple-900/40 border-purple-500/30"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline" className="bg-purple-500/50">
                              <Users className="h-3 w-3 ml-1" />
                              تحدي جماعي
                            </Badge>
                            <Badge variant="outline" className="bg-yellow-500/20">
                              <Trophy className="h-3 w-3 ml-1" />
                              {challenge.points} نقطة
                            </Badge>
                          </div>
                          <h3 className="font-medium text-gray-100 mb-1">{challenge.title}</h3>
                          <p className="text-sm text-gray-400 mb-3">{challenge.description}</p>
                          <div className="flex flex-col space-y-2">
                            <div>
                              <div className="flex justify-between text-xs text-gray-400 mb-1">
                                <span>المشاركون ({challenge.currentMembers}/{challenge.requiredMembers})</span>
                                <span>{Math.round((challenge.currentMembers / challenge.requiredMembers) * 100)}%</span>
                              </div>
                              <Progress value={(challenge.currentMembers / challenge.requiredMembers) * 100} className="h-2" />
                            </div>
                            <div className="flex items-center text-xs text-gray-400">
                              <Calendar className="h-3 w-3 ml-1" />
                              الموعد النهائي: {formatDate(challenge.deadline)}
                            </div>
                          </div>
                        </div>
                        <div>
                          {challenge.completed ? (
                            <Badge className="bg-green-600">
                              <CheckCircle2 className="h-3 w-3 ml-1" />
                              مكتمل
                            </Badge>
                          ) : (
                            <Button size="sm" className="bg-purple-600 hover:bg-purple-500">
                              الانضمام للتحدي
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* قسم الترتيب */}
        <TabsContent value="leaderboard" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>ترتيب الإنتاجية</CardTitle>
              <CardDescription>
                ترتيب الأعضاء حسب النقاط المكتسبة والمهام المنجزة
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingLeaderboard ? (
                <div className="flex justify-center items-center h-40">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : leaderboard.length === 0 ? (
                <div className="text-center py-8 px-4">
                  <BarChart4 className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                  <h3 className="text-lg font-medium mb-1">لا يوجد ترتيب متاح حاليًا</h3>
                  <p className="text-gray-500 text-sm">أكمل المزيد من المهام للظهور في الترتيب</p>
                </div>
              ) : (
                <div className="overflow-hidden rounded-md border border-gray-700">
                  <table className="w-full text-left">
                    <thead className="bg-gray-800/50">
                      <tr>
                        <th className="py-3 px-4 text-sm font-medium">المركز</th>
                        <th className="py-3 px-4 text-sm font-medium">المستخدم</th>
                        <th className="py-3 px-4 text-sm font-medium text-right">النقاط</th>
                        <th className="py-3 px-4 text-sm font-medium text-right">التتابع</th>
                        <th className="py-3 px-4 text-sm font-medium text-right">المهام المكتملة</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-700">
                      {leaderboard.map((entry) => (
                        <tr key={entry.userId} className="hover:bg-gray-800/30">
                          <td className="py-3 px-4">
                            <Badge 
                              className={
                                entry.rank === 1 ? "bg-yellow-500" : 
                                entry.rank === 2 ? "bg-gray-400" : 
                                entry.rank === 3 ? "bg-amber-700" : 
                                "bg-gray-600"
                              }
                            >
                              {entry.rank}
                            </Badge>
                          </td>
                          <td className="py-3 px-4 font-medium">
                            {entry.username || `مستخدم #${entry.userId}`}
                          </td>
                          <td className="py-3 px-4 text-right">{entry.totalPoints}</td>
                          <td className="py-3 px-4 text-right flex items-center justify-end">
                            <Flame className="h-4 w-4 text-amber-500 ml-1" />
                            {entry.streak}
                          </td>
                          <td className="py-3 px-4 text-right">{entry.tasksCompleted}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* نافذة إكمال المهمة */}
      <Dialog open={isCompleteDialogOpen} onOpenChange={setIsCompleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>إكمال المهمة</DialogTitle>
            <DialogDescription>
              قم بإدخال الوقت الذي استغرقته لإكمال هذه المهمة
            </DialogDescription>
          </DialogHeader>
          {selectedTask && (
            <Form {...completeTaskForm}>
              <form onSubmit={completeTaskForm.handleSubmit((data) => completeTaskMutation.mutate(data))} className="space-y-4">
                <div className="mb-4">
                  <h3 className="font-medium mb-2">{selectedTask.description}</h3>
                  <div className="text-sm text-gray-400">
                    الوقت المتوقع: {formatTime(selectedTask.expectedTime)}
                  </div>
                </div>
                
                <FormField
                  control={completeTaskForm.control}
                  name="timeSpent"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الوقت المستغرق (بالدقائق)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min={1}
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormDescription>
                        أدخل الوقت الفعلي الذي استغرقته في إنجاز المهمة
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <input type="hidden" {...completeTaskForm.register("taskId")} />
                
                <Alert className={`${
                  completeTaskForm.watch("timeSpent") > selectedTask.expectedTime * 1.2
                    ? "border-amber-500/50 bg-amber-500/10"
                    : completeTaskForm.watch("timeSpent") <= selectedTask.expectedTime
                      ? "border-green-500/50 bg-green-500/10"
                      : "border-gray-500/50 bg-gray-500/10"
                }`}>
                  <AlertTriangle className={`h-4 w-4 ${
                    completeTaskForm.watch("timeSpent") > selectedTask.expectedTime * 1.2
                      ? "text-amber-500"
                      : completeTaskForm.watch("timeSpent") <= selectedTask.expectedTime
                        ? "text-green-500"
                        : "text-gray-500"
                  }`} />
                  <AlertTitle className="ml-2">
                    {completeTaskForm.watch("timeSpent") > selectedTask.expectedTime * 1.2
                      ? "تجاوزت الوقت المتوقع بشكل كبير"
                      : completeTaskForm.watch("timeSpent") <= selectedTask.expectedTime
                        ? "أكملت المهمة ضمن الوقت المتوقع"
                        : "تجاوزت الوقت المتوقع قليلاً"
                    }
                  </AlertTitle>
                  <AlertDescription className="ml-2">
                    {completeTaskForm.watch("timeSpent") > selectedTask.expectedTime * 1.2
                      ? "سيتم خصم بعض النقاط بسبب تجاوز الوقت المتوقع بشكل كبير."
                      : completeTaskForm.watch("timeSpent") <= selectedTask.expectedTime
                        ? "ستحصل على كامل النقاط المخصصة لهذه المهمة."
                        : "سيتم خصم نقاط قليلة بسبب تجاوز الوقت المتوقع."
                    }
                  </AlertDescription>
                </Alert>
                
                <DialogFooter>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsCompleteDialogOpen(false)}
                    disabled={completeTaskMutation.isPending}
                  >
                    إلغاء
                  </Button>
                  <Button 
                    type="submit"
                    disabled={completeTaskMutation.isPending} 
                    className="bg-green-600 hover:bg-green-500"
                  >
                    {completeTaskMutation.isPending ? (
                      <>
                        <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                        جاري الإكمال...
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="ml-2 h-4 w-4" />
                        إكمال المهمة
                      </>
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
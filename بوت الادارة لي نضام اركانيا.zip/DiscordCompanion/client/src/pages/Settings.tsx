import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { AlertTriangle, Save } from "lucide-react";

// Token form schema
const tokenSchema = z.object({
  token: z.string().min(1, "Bot token is required")
});

type TokenFormValues = z.infer<typeof tokenSchema>;

export default function Settings() {
  const { toast } = useToast();
  
  // Form setup
  const form = useForm<TokenFormValues>({
    resolver: zodResolver(tokenSchema),
    defaultValues: {
      token: ""
    }
  });
  
  // Set bot token mutation
  const setTokenMutation = useMutation({
    mutationFn: async (data: TokenFormValues) => {
      await apiRequest("POST", "/api/bot/token", data);
    },
    onSuccess: () => {
      toast({
        title: "Token set successfully",
        description: "The bot has been started with the new token",
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to set token: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // Submit handler
  const onSubmit = (data: TokenFormValues) => {
    setTokenMutation.mutate(data);
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white mb-2">Settings</h1>
        <p className="text-[#B9BBBE]">
          Configure your Discord bot settings. Be careful with sensitive information.
        </p>
      </div>
      
      <Card className="bg-[#292B2F] border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Bot Token</CardTitle>
          <CardDescription className="text-[#B9BBBE]">
            Enter your Discord bot token to authenticate your bot with Discord.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="token"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Bot Token</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter your Discord bot token" 
                        type="password"
                        className="bg-[#36393F] border-gray-700 text-white"
                        {...field} 
                      />
                    </FormControl>
                    <FormDescription className="text-[#B9BBBE]">
                      This is your Discord bot token from the Discord Developer Portal.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button 
                type="submit" 
                disabled={setTokenMutation.isPending}
                className="bg-[#5865F2] hover:bg-opacity-80 text-white"
              >
                <Save className="mr-2 h-4 w-4" />
                {setTokenMutation.isPending ? "Saving..." : "Save Token"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
      
      <Card className="bg-[#292B2F] border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <AlertTriangle className="text-[#FAA61A] mr-2 h-5 w-5" />
            Security Notice
          </CardTitle>
        </CardHeader>
        <CardContent className="text-[#B9BBBE]">
          <p>
            Your bot token is like a password. Keep it secure and never share it publicly.
            If you believe your token has been compromised, regenerate it immediately
            in the Discord Developer Portal.
          </p>
        </CardContent>
      </Card>
      
      <Card className="bg-[#292B2F] border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">How to Create a Discord Bot</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-[#B9BBBE]">
          <div>
            <h3 className="font-medium text-white mb-1">1. Go to Discord Developer Portal</h3>
            <p>Visit <a href="https://discord.com/developers/applications" target="_blank" rel="noopener noreferrer" className="text-[#5865F2] hover:underline">https://discord.com/developers/applications</a></p>
          </div>
          <div>
            <h3 className="font-medium text-white mb-1">2. Create New Application</h3>
            <p>Click the "New Application" button and give your application a name.</p>
          </div>
          <div>
            <h3 className="font-medium text-white mb-1">3. Create a Bot</h3>
            <p>Navigate to the "Bot" tab and click "Add Bot".</p>
          </div>
          <div>
            <h3 className="font-medium text-white mb-1">4. Get Your Token</h3>
            <p>Click "Reset Token" to generate a new token. Copy this token and paste it in the field above.</p>
          </div>
          <div>
            <h3 className="font-medium text-white mb-1">5. Set Required Permissions</h3>
            <p>In the "Bot" tab, enable necessary "Privileged Gateway Intents" (like Message Content Intent).</p>
          </div>
          <div>
            <h3 className="font-medium text-white mb-1">6. Invite Your Bot to Servers</h3>
            <p>Go to the "OAuth2" tab, select "URL Generator", choose "bot" scope and relevant permissions, then use the generated URL to invite your bot to servers.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

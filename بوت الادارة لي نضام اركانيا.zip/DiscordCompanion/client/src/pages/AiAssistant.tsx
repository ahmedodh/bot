import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { toast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { ThumbsUp, ThumbsDown, Send, Image, Code, Brain, RefreshCw, Bot, Sparkles, Loader2 } from "lucide-react";
import MarkdownPreview from '@uiw/react-markdown-preview';

interface AiResponse {
  id: string;
  question: string;
  answer: string;
  timestamp: Date;
  feedback?: 'positive' | 'negative';
}

interface GeneratedImage {
  id: string;
  prompt: string;
  imageUrl: string;
  timestamp: Date;
}

interface ImprovedCodeResponse {
  id: string;
  originalCode: string;
  improvedCode: string;
  explanation: string;
  timestamp: Date;
}

export default function AiAssistant() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("chat");
  const [question, setQuestion] = useState("");
  const [imagePrompt, setImagePrompt] = useState("");
  const [selectedModel, setSelectedModel] = useState("gpt-4o");
  const [codeToImprove, setCodeToImprove] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const imageContainerRef = useRef<HTMLDivElement>(null);
  const codeContainerRef = useRef<HTMLDivElement>(null);

  // انتقال تلقائي إلى أسفل عند إضافة رسائل جديدة
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
    if (imageContainerRef.current) {
      imageContainerRef.current.scrollTop = imageContainerRef.current.scrollHeight;
    }
    if (codeContainerRef.current) {
      codeContainerRef.current.scrollTop = codeContainerRef.current.scrollHeight;
    }
  }, [activeTab]);

  // استعلام للحصول على المحادثات السابقة
  const { data: conversations = [], isLoading: isLoadingConversations } = useQuery({
    queryKey: ["/api/ai/conversations"],
    queryFn: async () => {
      try {
        const res = await apiRequest<AiResponse[]>("/api/ai/conversations");
        return res.data || [];
      } catch (error) {
        console.error("Error fetching conversations:", error);
        return [];
      }
    }
  });

  // استعلام للحصول على الصور المنشأة
  const { data: images = [], isLoading: isLoadingImages } = useQuery({
    queryKey: ["/api/ai/images"],
    queryFn: async () => {
      try {
        const res = await apiRequest<GeneratedImage[]>("/api/ai/images");
        return res.data || [];
      } catch (error) {
        console.error("Error fetching images:", error);
        return [];
      }
    }
  });

  // استعلام للحصول على أكواد محسنة
  const { data: improvedCodes = [], isLoading: isLoadingCodes } = useQuery({
    queryKey: ["/api/ai/improved-code"],
    queryFn: async () => {
      try {
        const res = await apiRequest<ImprovedCodeResponse[]>("/api/ai/improved-code");
        return res.data || [];
      } catch (error) {
        console.error("Error fetching improved codes:", error);
        return [];
      }
    }
  });

  // استعلام للحصول على اقتراحات أسئلة
  const { data: suggestions = [] } = useQuery({
    queryKey: ["/api/ai/suggestions"],
    queryFn: async () => {
      try {
        const res = await apiRequest<string[]>("/api/ai/suggestions");
        return res.data || [];
      } catch (error) {
        console.error("Error fetching suggestions:", error);
        return [];
      }
    }
  });

  // طلب إرسال سؤال جديد
  const askMutation = useMutation({
    mutationFn: async (prompt: string) => {
      setIsTyping(true);
      const res = await apiRequest("/api/ai/ask", {
        method: "POST",
        data: { prompt, model: selectedModel }
      });
      return res.data;
    },
    onSuccess: () => {
      setQuestion("");
      queryClient.invalidateQueries({ queryKey: ["/api/ai/conversations"] });
      setTimeout(() => {
        if (chatContainerRef.current) {
          chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
        }
      }, 100);
    },
    onError: (error) => {
      console.error("Error asking question:", error);
      toast({
        title: "فشل في إرسال السؤال",
        description: "حدث خطأ أثناء محاولة الحصول على إجابة. يرجى المحاولة مرة أخرى.",
        variant: "destructive"
      });
    },
    onSettled: () => {
      setIsTyping(false);
    }
  });

  // طلب إنشاء صورة جديدة
  const generateImageMutation = useMutation({
    mutationFn: async (prompt: string) => {
      const res = await apiRequest("/api/ai/generate-image", {
        method: "POST",
        data: { prompt }
      });
      return res.data;
    },
    onSuccess: () => {
      setImagePrompt("");
      queryClient.invalidateQueries({ queryKey: ["/api/ai/images"] });
      setTimeout(() => {
        if (imageContainerRef.current) {
          imageContainerRef.current.scrollTop = imageContainerRef.current.scrollHeight;
        }
      }, 100);
    },
    onError: (error) => {
      console.error("Error generating image:", error);
      toast({
        title: "فشل في إنشاء الصورة",
        description: "حدث خطأ أثناء محاولة إنشاء الصورة. يرجى المحاولة مرة أخرى.",
        variant: "destructive"
      });
    }
  });

  // طلب تحسين الكود
  const improveCodeMutation = useMutation({
    mutationFn: async (code: string) => {
      const res = await apiRequest("/api/ai/improve-code", {
        method: "POST",
        data: { code }
      });
      return res.data;
    },
    onSuccess: () => {
      setCodeToImprove("");
      queryClient.invalidateQueries({ queryKey: ["/api/ai/improved-code"] });
      setTimeout(() => {
        if (codeContainerRef.current) {
          codeContainerRef.current.scrollTop = codeContainerRef.current.scrollHeight;
        }
      }, 100);
    },
    onError: (error) => {
      console.error("Error improving code:", error);
      toast({
        title: "فشل في تحسين الكود",
        description: "حدث خطأ أثناء محاولة تحسين الكود. يرجى المحاولة مرة أخرى.",
        variant: "destructive"
      });
    }
  });

  // طلب تقديم تغذية راجعة عن الإجابة
  const feedbackMutation = useMutation({
    mutationFn: async ({ id, feedback }: { id: string; feedback: 'positive' | 'negative' }) => {
      const res = await apiRequest(`/api/ai/feedback/${id}`, {
        method: "POST",
        data: { feedback }
      });
      return res.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai/conversations"] });
    },
    onError: (error) => {
      console.error("Error submitting feedback:", error);
      toast({
        title: "فشل تقديم التغذية الراجعة",
        description: "حدث خطأ أثناء محاولة إرسال التغذية الراجعة. يرجى المحاولة مرة أخرى.",
        variant: "destructive"
      });
    }
  });

  // التعامل مع إرسال السؤال
  const handleAskQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (question.trim()) {
      askMutation.mutate(question);
    }
  };

  // التعامل مع إنشاء صورة
  const handleGenerateImage = (e: React.FormEvent) => {
    e.preventDefault();
    if (imagePrompt.trim()) {
      generateImageMutation.mutate(imagePrompt);
    }
  };

  // التعامل مع تحسين الكود
  const handleImproveCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (codeToImprove.trim()) {
      improveCodeMutation.mutate(codeToImprove);
    }
  };

  // تنسيق التاريخ
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric'
    }).format(new Date(date));
  };

  return (
    <div className="flex flex-col space-y-4 h-full pb-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">المساعد الذكي</h1>
        <div className="flex space-x-2">
          <Select value={selectedModel} onValueChange={setSelectedModel}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="اختر النموذج" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="gpt-4o">GPT-4o (أحدث نموذج)</SelectItem>
              <SelectItem value="gpt-4-turbo">GPT-4 Turbo</SelectItem>
              <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo (أسرع)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="chat" className="flex items-center">
            <Bot className="w-4 h-4 ml-2" />
            <span>المحادثة</span>
          </TabsTrigger>
          <TabsTrigger value="images" className="flex items-center">
            <Image className="w-4 h-4 ml-2" />
            <span>إنشاء الصور</span>
          </TabsTrigger>
          <TabsTrigger value="code" className="flex items-center">
            <Code className="w-4 h-4 ml-2" />
            <span>تحسين الكود</span>
          </TabsTrigger>
        </TabsList>

        {/* قسم المحادثة */}
        <TabsContent value="chat" className="space-y-4 mt-2">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="col-span-1 md:col-span-3">
              <Card className="h-[calc(100vh-250px)]">
                <CardHeader className="p-4">
                  <CardTitle className="text-lg">المحادثة مع المساعد الذكي</CardTitle>
                  <CardDescription>
                    اطرح أسئلتك وسيقوم نموذج GPT بالإجابة عليها بأفضل طريقة ممكنة
                  </CardDescription>
                </CardHeader>
                <Separator />
                <CardContent className="p-0">
                  <div ref={chatContainerRef} className="h-[calc(100vh-400px)] overflow-y-auto p-4">
                    {isLoadingConversations ? (
                      <div className="flex items-center justify-center h-full">
                        <Loader2 className="animate-spin h-8 w-8 text-primary" />
                      </div>
                    ) : conversations.length === 0 ? (
                      <div className="text-center py-10">
                        <Bot className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                        <h3 className="text-lg font-medium mb-2">لم تبدأ أي محادثة بعد</h3>
                        <p className="text-gray-500 text-sm">ابدأ بطرح سؤال واحصل على إجابة فورية</p>
                      </div>
                    ) : (
                      <>
                        {conversations.map((conversation, index) => (
                          <div key={conversation.id || index} className="mb-6">
                            {/* السؤال */}
                            <div className="flex items-start mb-4">
                              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#5865F2] to-[#4752C4] flex items-center justify-center text-white font-medium shadow-md">أ</div>
                              <div className="mr-3 bg-[#36393F] border border-gray-700 rounded-lg p-3 flex-1">
                                <p className="text-gray-200">{conversation.question}</p>
                                <p className="text-xs text-gray-400 mt-2 text-left">{formatDate(new Date(conversation.timestamp))}</p>
                              </div>
                            </div>
                            
                            {/* الإجابة */}
                            <div className="flex items-start mb-2 pr-10">
                              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#43B581] to-[#308559] flex items-center justify-center text-white font-medium shadow-md">
                                <Bot className="w-4 h-4" />
                              </div>
                              <div className="mr-3 bg-[#2F3136] border border-gray-700 rounded-lg p-3 flex-1">
                                <MarkdownPreview 
                                  source={conversation.answer} 
                                  className="text-gray-200"
                                  style={{ backgroundColor: 'transparent', color: '#e4e4e4' }}
                                />
                                <div className="flex justify-between items-center mt-3">
                                  <div className="flex space-x-2">
                                    <Button
                                      variant={conversation.feedback === 'positive' ? "default" : "outline"}
                                      size="sm"
                                      onClick={() => feedbackMutation.mutate({ id: conversation.id, feedback: 'positive' })}
                                      disabled={feedbackMutation.isPending}
                                      className="ml-2"
                                    >
                                      <ThumbsUp className="h-4 w-4 ml-1" />
                                      <span>مفيد</span>
                                    </Button>
                                    <Button
                                      variant={conversation.feedback === 'negative' ? "destructive" : "outline"}
                                      size="sm"
                                      onClick={() => feedbackMutation.mutate({ id: conversation.id, feedback: 'negative' })}
                                      disabled={feedbackMutation.isPending}
                                    >
                                      <ThumbsDown className="h-4 w-4 ml-1" />
                                      <span>غير مفيد</span>
                                    </Button>
                                  </div>
                                  <p className="text-xs text-gray-400">{formatDate(new Date(conversation.timestamp))}</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                        
                        {isTyping && (
                          <div className="flex items-start mb-2 pr-10">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#43B581] to-[#308559] flex items-center justify-center text-white font-medium shadow-md">
                              <Bot className="w-4 h-4" />
                            </div>
                            <div className="mr-3 bg-[#2F3136] border border-gray-700 rounded-lg p-3 flex-1">
                              <div className="flex items-center">
                                <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                                <div className="w-2 h-2 bg-gray-400 rounded-full mx-1 animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                                <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                                <span className="mr-2 text-gray-400 text-sm">جاري الكتابة...</span>
                              </div>
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </CardContent>
                <Separator />
                <CardFooter className="p-4">
                  <form onSubmit={handleAskQuestion} className="flex w-full space-x-2">
                    <Input
                      value={question}
                      onChange={(e) => setQuestion(e.target.value)}
                      placeholder="اكتب سؤالك هنا..."
                      className="flex-1 ml-2"
                      disabled={askMutation.isPending || isTyping}
                    />
                    <Button 
                      type="submit" 
                      disabled={!question.trim() || askMutation.isPending || isTyping}
                    >
                      {askMutation.isPending ? (
                        <Loader2 className="w-4 h-4 animate-spin ml-2" />
                      ) : (
                        <Send className="w-4 h-4 ml-2" />
                      )}
                      إرسال
                    </Button>
                  </form>
                </CardFooter>
              </Card>
            </div>
            
            <div className="col-span-1">
              <Card className="h-[calc(100vh-250px)]">
                <CardHeader className="p-4">
                  <CardTitle className="text-lg">اقتراحات أسئلة</CardTitle>
                  <CardDescription>
                    بعض الأسئلة المقترحة التي يمكنك طرحها
                  </CardDescription>
                </CardHeader>
                <Separator />
                <CardContent className="p-4">
                  <div className="space-y-2">
                    {suggestions.map((suggestion, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        className="w-full justify-start text-right hover:bg-blue-900/20 hover:border-blue-500/50 transition-all"
                        onClick={() => setQuestion(suggestion)}
                      >
                        <Sparkles className="h-4 w-4 ml-2 text-blue-400" />
                        {suggestion}
                      </Button>
                    ))}
                    
                    {suggestions.length === 0 && (
                      <div className="text-center py-4">
                        <p className="text-gray-500 text-sm">لا توجد اقتراحات متاحة حاليًا</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* قسم إنشاء الصور */}
        <TabsContent value="images" className="space-y-4 mt-2">
          <Card className="h-[calc(100vh-250px)]">
            <CardHeader className="p-4">
              <CardTitle className="text-lg">إنشاء صور باستخدام الذكاء الاصطناعي</CardTitle>
              <CardDescription>
                اكتب وصفًا وسيقوم نموذج DALL-E بإنشاء صورة بناءً على وصفك
              </CardDescription>
            </CardHeader>
            <Separator />
            <CardContent className="p-0">
              <div ref={imageContainerRef} className="h-[calc(100vh-400px)] overflow-y-auto p-4">
                {isLoadingImages ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="animate-spin h-8 w-8 text-primary" />
                  </div>
                ) : images.length === 0 ? (
                  <div className="text-center py-10">
                    <Image className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                    <h3 className="text-lg font-medium mb-2">لم تنشئ أي صورة بعد</h3>
                    <p className="text-gray-500 text-sm">اكتب وصفًا مفصلاً وسيتم إنشاء صورة جديدة</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {images.map((image) => (
                      <Card key={image.id} className="overflow-hidden">
                        <CardHeader className="p-3">
                          <CardTitle className="text-sm">
                            {image.prompt.length > 60 ? image.prompt.slice(0, 60) + '...' : image.prompt}
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-0">
                          <div className="relative aspect-square bg-gray-800">
                            <img
                              src={image.imageUrl}
                              alt={image.prompt}
                              className="w-full h-full object-cover"
                              loading="lazy"
                            />
                          </div>
                        </CardContent>
                        <CardFooter className="p-3 flex justify-between items-center">
                          <p className="text-xs text-gray-400">{formatDate(new Date(image.timestamp))}</p>
                          <Button variant="outline" size="sm" onClick={() => window.open(image.imageUrl, '_blank')}>
                            فتح في نافذة جديدة
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
            <Separator />
            <CardFooter className="p-4">
              <form onSubmit={handleGenerateImage} className="flex w-full flex-col space-y-2">
                <Textarea
                  value={imagePrompt}
                  onChange={(e) => setImagePrompt(e.target.value)}
                  placeholder="اكتب وصفًا مفصلاً للصورة التي تريد إنشاءها..."
                  className="flex-1 resize-none"
                  rows={3}
                  disabled={generateImageMutation.isPending}
                />
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={!imagePrompt.trim() || generateImageMutation.isPending}
                >
                  {generateImageMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin ml-2" />
                      جاري إنشاء الصورة...
                    </>
                  ) : (
                    <>
                      <Image className="w-4 h-4 ml-2" />
                      إنشاء صورة جديدة
                    </>
                  )}
                </Button>
              </form>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* قسم تحسين الكود */}
        <TabsContent value="code" className="space-y-4 mt-2">
          <Card className="h-[calc(100vh-250px)]">
            <CardHeader className="p-4">
              <CardTitle className="text-lg">تحسين وتنظيف الكود</CardTitle>
              <CardDescription>
                ضع الكود الخاص بك وسيقوم المساعد الذكي بتحسينه وشرح التغييرات
              </CardDescription>
            </CardHeader>
            <Separator />
            <CardContent className="p-0">
              <div ref={codeContainerRef} className="h-[calc(100vh-400px)] overflow-y-auto p-4">
                {isLoadingCodes ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="animate-spin h-8 w-8 text-primary" />
                  </div>
                ) : improvedCodes.length === 0 ? (
                  <div className="text-center py-10">
                    <Code className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                    <h3 className="text-lg font-medium mb-2">لم تقم بتحسين أي كود بعد</h3>
                    <p className="text-gray-500 text-sm">ضع الكود الخاص بك وسيتم تحسينه مع شرح التحسينات</p>
                  </div>
                ) : (
                  <>
                    {improvedCodes.map((codeItem) => (
                      <div key={codeItem.id} className="mb-6 border border-gray-700 rounded-lg overflow-hidden">
                        <div className="bg-[#2D2D2D] p-3 border-b border-gray-700 flex justify-between items-center">
                          <h3 className="text-sm font-medium">تحسين كود بتاريخ {formatDate(new Date(codeItem.timestamp))}</h3>
                          <div className="flex items-center">
                            <span className="text-xs text-green-400 ml-2 flex items-center">
                              <Sparkles className="h-3 w-3 ml-1" />
                              تم التحسين
                            </span>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 divide-x divide-gray-700">
                          <div className="p-3 bg-[#1E1E1E]">
                            <h4 className="text-sm font-medium mb-2 text-gray-300">الكود الأصلي</h4>
                            <div className="bg-[#282C34] rounded p-3 text-sm font-mono overflow-x-auto">
                              <pre>{codeItem.originalCode}</pre>
                            </div>
                          </div>
                          
                          <div className="p-3 bg-[#1E1E1E]">
                            <h4 className="text-sm font-medium mb-2 text-gray-300">الكود المحسن</h4>
                            <div className="bg-[#282C34] rounded p-3 text-sm font-mono overflow-x-auto">
                              <pre>{codeItem.improvedCode}</pre>
                            </div>
                          </div>
                        </div>
                        
                        <div className="p-3 bg-[#2D2D2D] border-t border-gray-700">
                          <h4 className="text-sm font-medium mb-2 text-gray-300">شرح التحسينات</h4>
                          <MarkdownPreview 
                            source={codeItem.explanation} 
                            className="text-sm" 
                            style={{ backgroundColor: 'transparent', color: '#e4e4e4' }}
                          />
                        </div>
                      </div>
                    ))}
                  </>
                )}
              </div>
            </CardContent>
            <Separator />
            <CardFooter className="p-4">
              <form onSubmit={handleImproveCode} className="flex w-full flex-col space-y-2">
                <Textarea
                  value={codeToImprove}
                  onChange={(e) => setCodeToImprove(e.target.value)}
                  placeholder="ضع الكود الذي تريد تحسينه هنا..."
                  className="flex-1 resize-none font-mono"
                  rows={6}
                  disabled={improveCodeMutation.isPending}
                />
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={!codeToImprove.trim() || improveCodeMutation.isPending}
                >
                  {improveCodeMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin ml-2" />
                      جاري تحسين الكود...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-4 h-4 ml-2" />
                      تحسين الكود
                    </>
                  )}
                </Button>
              </form>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
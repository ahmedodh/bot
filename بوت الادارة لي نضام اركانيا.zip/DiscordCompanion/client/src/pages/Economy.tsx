import { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Coins, 
  TrendingUp, 
  ArrowLeftRight, 
  Users, 
  Loader2, 
  AlertCircle, 
  PlusCircle,
  MinusCircle
} from "lucide-react";
import { levelingSystem } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";

interface User {
  userId: string;
  xp: number;
  level: number;
  coins: number;
  is_vip: boolean;
}

export default function Economy() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [coinsToAdd, setCoinsToAdd] = useState<Record<string, string>>({});
  const [transferAmount, setTransferAmount] = useState("");
  const [fromUser, setFromUser] = useState("");
  const [toUser, setToUser] = useState("");
  const [processing, setProcessing] = useState(false);
  const [processingAction, setProcessingAction] = useState<Record<string, boolean>>({});

  // Load users
  const fetchUsers = async () => {
    try {
      setLoading(true);
      const data = await levelingSystem.getUsers();
      setUsers(data);
      if (data.length > 0 && !fromUser) {
        setFromUser(data[0].userId);
      }
    } catch (error) {
      console.error("Error fetching users:", error);
      toast({
        title: "خطأ",
        description: "فشل في جلب بيانات المستخدمين",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Add coins to user
  const addCoinsToUser = async (userId: string, isAddition = true) => {
    try {
      setProcessingAction({ ...processingAction, [userId]: true });
      const coinsAmount = parseInt(coinsToAdd[userId] || '0');
      
      if (isNaN(coinsAmount) || coinsAmount <= 0) {
        toast({
          title: "خطأ",
          description: "الرجاء إدخال رقم صحيح موجب",
          variant: "destructive",
        });
        return;
      }

      const user = users.find(u => u.userId === userId);
      if (!user) return;
      
      const newCoins = isAddition 
        ? user.coins + coinsAmount
        : Math.max(0, user.coins - coinsAmount);
      
      await levelingSystem.updateUser(userId, { coins: newCoins });
      
      // Update local state
      setUsers(users.map(u => 
        u.userId === userId 
        ? { ...u, coins: newCoins } 
        : u
      ));
      
      setCoinsToAdd({ ...coinsToAdd, [userId]: '' });
      
      toast({
        title: "تم التحديث",
        description: isAddition 
          ? `تم إضافة ${coinsAmount} عملات للمستخدم`
          : `تم خصم ${coinsAmount} عملات من المستخدم`,
      });
    } catch (error) {
      console.error("Error updating user coins:", error);
      toast({
        title: "خطأ",
        description: "فشل في تحديث عملات المستخدم",
        variant: "destructive",
      });
    } finally {
      setProcessingAction({ ...processingAction, [userId]: false });
    }
  };

  // Transfer coins between users
  const transferCoins = async () => {
    try {
      setProcessing(true);
      const amount = parseInt(transferAmount);
      
      if (isNaN(amount) || amount <= 0) {
        toast({
          title: "خطأ",
          description: "الرجاء إدخال مبلغ صحيح موجب",
          variant: "destructive",
        });
        return;
      }
      
      if (fromUser === toUser) {
        toast({
          title: "خطأ",
          description: "لا يمكن التحويل لنفس المستخدم",
          variant: "destructive",
        });
        return;
      }
      
      const sender = users.find(u => u.userId === fromUser);
      
      if (!sender) {
        toast({
          title: "خطأ",
          description: "المرسل غير موجود",
          variant: "destructive",
        });
        return;
      }
      
      if (sender.coins < amount) {
        toast({
          title: "رصيد غير كافي",
          description: "المرسل لا يملك عملات كافية للتحويل",
          variant: "destructive",
        });
        return;
      }
      
      await levelingSystem.transferCoins(fromUser, toUser, amount);
      
      // Update users list after transfer
      await fetchUsers();
      
      // Reset form
      setTransferAmount("");
      
      toast({
        title: "تم التحويل",
        description: `تم تحويل ${amount} عملات من ${fromUser} إلى ${toUser}`,
      });
    } catch (error) {
      console.error("Error transferring coins:", error);
      toast({
        title: "خطأ",
        description: "فشل في تحويل العملات",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  // Format timestamp to readable date
  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Calculate total coins in economy
  const totalCoins = users.reduce((total, user) => total + (user.coins || 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">نظام الاقتصاد</h1>
          <p className="text-muted-foreground">إدارة العملات والتحويلات بين المستخدمين</p>
        </div>
        <div className="flex items-center">
          <Button 
            variant="outline"
            size="sm" 
            onClick={fetchUsers}
            disabled={loading}
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "تحديث"}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center text-lg">
              <Coins className="h-5 w-5 mr-2 text-yellow-500" />
              إجمالي العملات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{totalCoins.toLocaleString()}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center text-lg">
              <Users className="h-5 w-5 mr-2 text-blue-500" />
              عدد المستخدمين
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{users.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center text-lg">
              <TrendingUp className="h-5 w-5 mr-2 text-green-500" />
              متوسط العملات
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {users.length > 0 
                ? Math.floor(totalCoins / users.length).toLocaleString() 
                : 0}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <ArrowLeftRight className="mr-2 h-5 w-5 text-[#5865F2]" />
            تحويل العملات
          </CardTitle>
          <CardDescription>
            تحويل العملات بين المستخدمين
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium mb-1 block">المرسل</label>
              <Select 
                value={fromUser} 
                onValueChange={setFromUser}
                disabled={users.length === 0}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر المرسل" />
                </SelectTrigger>
                <SelectContent>
                  {users.map(user => (
                    <SelectItem key={`from-${user.userId}`} value={user.userId}>
                      <div className="flex items-center justify-between w-full">
                        <span>{user.userId}</span>
                        <span className="text-muted-foreground text-xs">
                          {user.coins} عملة
                        </span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-1 block">المبلغ</label>
              <div className="relative">
                <Input
                  type="number"
                  placeholder="أدخل المبلغ"
                  value={transferAmount}
                  onChange={e => setTransferAmount(e.target.value)}
                  min="1"
                  className="pl-10"
                />
                <Coins className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
              </div>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-1 block">المستلم</label>
              <Select 
                value={toUser} 
                onValueChange={setToUser}
                disabled={users.length === 0}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر المستلم" />
                </SelectTrigger>
                <SelectContent>
                  {users.map(user => (
                    <SelectItem key={`to-${user.userId}`} value={user.userId}>
                      {user.userId}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button 
            className="w-full"
            onClick={transferCoins}
            disabled={processing || !fromUser || !toUser || !transferAmount}
          >
            {processing ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <ArrowLeftRight className="h-4 w-4 mr-2" />
            )}
            تحويل العملات
          </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Coins className="mr-2 h-5 w-5 text-yellow-500" />
            إدارة عملات المستخدمين
          </CardTitle>
          <CardDescription>
            إضافة أو خصم العملات من المستخدمين
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center items-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : users.length === 0 ? (
            <div className="text-center p-8 text-muted-foreground">
              <AlertCircle className="h-12 w-12 mx-auto mb-4" />
              <p>لا توجد بيانات متاحة. انتظر أول مستخدم للبوت.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">المستخدم</TableHead>
                    <TableHead className="text-right">المستوى</TableHead>
                    <TableHead className="text-right">العملات</TableHead>
                    <TableHead className="text-right">تعديل العملات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.sort((a, b) => b.coins - a.coins).map((user) => (
                    <TableRow key={user.userId}>
                      <TableCell className="font-medium">
                        {user.userId}
                      </TableCell>
                      <TableCell>{user.level}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Coins className="mr-1 h-4 w-4 text-yellow-500" />
                          {user.coins ? user.coins.toLocaleString() : "0"}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Input
                            className="w-24 text-center"
                            placeholder="القيمة"
                            value={coinsToAdd[user.userId] || ''}
                            onChange={(e) => setCoinsToAdd({...coinsToAdd, [user.userId]: e.target.value})}
                            dir="ltr"
                          />
                          <Button 
                            size="sm"
                            variant="outline"
                            className="text-green-500 hover:text-green-600"
                            onClick={() => addCoinsToUser(user.userId, true)}
                            disabled={processingAction[user.userId]}
                          >
                            {processingAction[user.userId] ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <PlusCircle className="h-4 w-4" />
                            )}
                          </Button>
                          <Button 
                            size="sm"
                            variant="outline"
                            className="text-red-500 hover:text-red-600"
                            onClick={() => addCoinsToUser(user.userId, false)}
                            disabled={processingAction[user.userId]}
                          >
                            {processingAction[user.userId] ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <MinusCircle className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
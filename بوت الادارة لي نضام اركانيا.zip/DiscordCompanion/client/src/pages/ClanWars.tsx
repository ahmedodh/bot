import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "@/components/ui/avatar";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  CalendarDays,
  Swords,
  Trophy,
  Shield,
  Users,
  Star,
  Plus,
  X,
  Edit,
  Trash2,
  Clock,
  Calendar,
  Flag,
  Activity,
  Award,
  AlertTriangle,
  CheckCircle,
  RefreshCw,
  Filter,
  Search,
  PlusSquare,
  MinusSquare,
} from "lucide-react";

interface ClanWar {
  id: number;
  name: string;
  description: string;
  status: string; // upcoming, active, completed
  startDate: string;
  endDate: string;
  seasonNumber: number;
  rules: Record<string, any>;
  rewards: Record<string, any>;
  minClanLevel: number;
  minMemberCount: number;
  maxParticipants: number | null;
}

interface Clan {
  id: number;
  name: string;
  tag: string;
  logo?: string;
  level: number;
  memberCount: number;
  ranking: number;
  status: string;
}

interface ClanWarParticipant {
  id: number;
  warId: number;
  clanId: number;
  clanName: string;
  clanTag: string;
  clanLogo?: string;
  points: number;
  rank: number;
  tasksCompleted: number;
  challengesWon: number;
  challengesLost: number;
  blacklisted: boolean;
}

interface ClanWarTask {
  id: number;
  warId: number;
  name: string;
  description: string;
  pointsValue: number;
  type: string;
  startDate: string;
  endDate: string;
  status: string;
  difficulty: string;
}

const createClanWarSchema = z.object({
  name: z.string().min(5, { message: "اسم الحرب يجب أن يكون 5 أحرف على الأقل" }),
  description: z.string().min(10, { message: "وصف الحرب يجب أن يكون 10 أحرف على الأقل" }),
  startDate: z.string().min(1, { message: "يجب تحديد تاريخ البدء" }),
  endDate: z.string().min(1, { message: "يجب تحديد تاريخ الانتهاء" }),
  seasonNumber: z.coerce.number().min(1, { message: "يجب أن يكون رقم الموسم 1 على الأقل" }),
  minClanLevel: z.coerce.number().min(1, { message: "يجب أن يكون الحد الأدنى لمستوى العشيرة 1 على الأقل" }),
  minMemberCount: z.coerce.number().min(5, { message: "يجب أن يكون الحد الأدنى لعدد الأعضاء 5 على الأقل" }),
  maxParticipants: z.coerce.number().min(0).nullable().optional()
});

const createTaskSchema = z.object({
  name: z.string().min(3, { message: "اسم المهمة يجب أن يكون 3 أحرف على الأقل" }),
  description: z.string().min(10, { message: "وصف المهمة يجب أن يكون 10 أحرف على الأقل" }),
  pointsValue: z.coerce.number().min(1, { message: "يجب أن تكون قيمة النقاط 1 على الأقل" }),
  type: z.string().min(1, { message: "يجب تحديد نوع المهمة" }),
  startDate: z.string().min(1, { message: "يجب تحديد تاريخ بدء المهمة" }),
  endDate: z.string().min(1, { message: "يجب تحديد تاريخ انتهاء المهمة" }),
  difficulty: z.string().min(1, { message: "يجب تحديد صعوبة المهمة" }),
});

export default function ClanWars() {
  const { toast } = useToast();
  const [activeClanWar, setActiveClanWar] = useState<ClanWar | null>(null);
  const [activeTab, setActiveTab] = useState("active");
  const [searchQuery, setSearchQuery] = useState("");
  
  // استعلام عن قائمة حروب العشائر
  const { data: clanWars = [], isLoading: isLoadingClanWars } = useQuery({
    queryKey: ["/api/clan-wars"],
    queryFn: async () => {
      try {
        const response = await fetch("/api/clan-wars");
        if (!response.ok) throw new Error("فشل في جلب بيانات حروب العشائر");
        const data = await response.json();
        return data;
      } catch (error) {
        console.error("خطأ في جلب بيانات حروب العشائر:", error);
        return [];
      }
    }
  });
  
  // استعلام عن المشاركين في حرب العشائر المحددة
  const { data: participants = [], isLoading: isLoadingParticipants } = useQuery({
    queryKey: ["/api/clan-wars/participants", activeClanWar?.id],
    queryFn: async () => {
      if (!activeClanWar) return [];
      
      try {
        const response = await fetch(`/api/clan-wars/${activeClanWar.id}/participants`);
        if (!response.ok) throw new Error("فشل في جلب بيانات المشاركين");
        const data = await response.json();
        return data;
      } catch (error) {
        console.error("خطأ في جلب بيانات المشاركين:", error);
        return [];
      }
    },
    enabled: !!activeClanWar
  });
  
  // استعلام عن المهام في حرب العشائر المحددة
  const { data: tasks = [], isLoading: isLoadingTasks } = useQuery({
    queryKey: ["/api/clan-wars/tasks", activeClanWar?.id],
    queryFn: async () => {
      if (!activeClanWar) return [];
      
      try {
        const response = await fetch(`/api/clan-wars/${activeClanWar.id}/tasks`);
        if (!response.ok) throw new Error("فشل في جلب بيانات المهام");
        const data = await response.json();
        return data;
      } catch (error) {
        console.error("خطأ في جلب بيانات المهام:", error);
        return [];
      }
    },
    enabled: !!activeClanWar
  });
  
  // استعلام عن العشائر المتاحة للمشاركة
  const { data: availableClans = [], isLoading: isLoadingClans } = useQuery({
    queryKey: ["/api/clans/available", activeClanWar?.id],
    queryFn: async () => {
      if (!activeClanWar) return [];
      
      try {
        const response = await fetch(`/api/clans/available?minLevel=${activeClanWar.minClanLevel}&minMemberCount=${activeClanWar.minMemberCount}`);
        if (!response.ok) throw new Error("فشل في جلب بيانات العشائر المتاحة");
        const data = await response.json();
        return data;
      } catch (error) {
        console.error("خطأ في جلب بيانات العشائر المتاحة:", error);
        return [];
      }
    },
    enabled: !!activeClanWar
  });
  
  // إنشاء حرب عشائر جديدة
  const createClanWarMutation = useMutation({
    mutationFn: async (clanWar: z.infer<typeof createClanWarSchema>) => {
      const response = await fetch("/api/clan-wars", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(clanWar)
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || "فشل في إنشاء حرب العشائر");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "تم إنشاء حرب العشائر بنجاح",
        description: "تم إضافة حرب العشائر الجديدة.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/clan-wars"] });
      setActiveClanWar(data);
      clanWarForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "فشل في إنشاء حرب العشائر",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // إضافة مهمة جديدة لحرب العشائر
  const addTaskMutation = useMutation({
    mutationFn: async (task: z.infer<typeof createTaskSchema>) => {
      if (!activeClanWar) throw new Error("لم يتم تحديد حرب العشائر");
      
      const response = await fetch(`/api/clan-wars/${activeClanWar.id}/tasks`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...task, warId: activeClanWar.id })
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || "فشل في إضافة المهمة");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم إضافة المهمة بنجاح",
        description: "تمت إضافة المهمة الجديدة إلى حرب العشائر.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/clan-wars/tasks", activeClanWar?.id] });
      taskForm.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "فشل في إضافة المهمة",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // إضافة عشيرة مشاركة في حرب العشائر
  const addParticipantMutation = useMutation({
    mutationFn: async (clanId: number) => {
      if (!activeClanWar) throw new Error("لم يتم تحديد حرب العشائر");
      
      const response = await fetch(`/api/clan-wars/${activeClanWar.id}/participants`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ clanId })
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || "فشل في إضافة العشيرة المشاركة");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم إضافة العشيرة بنجاح",
        description: "تمت إضافة العشيرة إلى المشاركين في حرب العشائر.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/clan-wars/participants", activeClanWar?.id] });
    },
    onError: (error: Error) => {
      toast({
        title: "فشل في إضافة العشيرة المشاركة",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // تحديث حالة حرب العشائر
  const updateClanWarStatusMutation = useMutation({
    mutationFn: async ({ warId, status }: { warId: number; status: string }) => {
      const response = await fetch(`/api/clan-wars/${warId}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status })
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || "فشل في تحديث حالة حرب العشائر");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "تم تحديث حالة حرب العشائر",
        description: `تم تغيير حالة حرب العشائر إلى "${data.status === 'active' ? 'نشط' : data.status === 'upcoming' ? 'قادم' : 'مكتمل'}"`,
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/clan-wars"] });
      if (activeClanWar) {
        setActiveClanWar({ ...activeClanWar, status: data.status });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "فشل في تحديث حالة حرب العشائر",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // نماذج React Hook Form
  const clanWarForm = useForm<z.infer<typeof createClanWarSchema>>({
    resolver: zodResolver(createClanWarSchema),
    defaultValues: {
      name: "",
      description: "",
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      seasonNumber: 1,
      minClanLevel: 1,
      minMemberCount: 5,
      maxParticipants: null
    }
  });
  
  const taskForm = useForm<z.infer<typeof createTaskSchema>>({
    resolver: zodResolver(createTaskSchema),
    defaultValues: {
      name: "",
      description: "",
      pointsValue: 100,
      type: "challenge",
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      difficulty: "medium"
    }
  });
  
  // معالجة إرسال النماذج
  function onCreateClanWar(values: z.infer<typeof createClanWarSchema>) {
    createClanWarMutation.mutate(values);
  }
  
  function onAddTask(values: z.infer<typeof createTaskSchema>) {
    addTaskMutation.mutate(values);
  }
  
  // تصفية الحروب حسب الحالة (نشط، قادم، مكتمل)
  const filteredWars = React.useMemo(() => {
    return (clanWars as ClanWar[]).filter((war) => {
      if (activeTab === "all") return true;
      return war.status === activeTab;
    });
  }, [clanWars, activeTab]);
  
  // ترتيب المشاركين حسب النقاط
  const sortedParticipants = React.useMemo(() => {
    return [...(participants as ClanWarParticipant[])].sort((a, b) => b.points - a.points);
  }, [participants]);
  
  // دالة مساعدة لتنسيق التاريخ
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  };
  
  return (
    <div className="container mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold mb-2">نظام حرب العشائر</h1>
          <p className="text-muted-foreground">إدارة منافسات حرب العشائر وتتبع نتائج المشاركين</p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-[#5865F2] to-[#4752C4]">
              <Plus className="h-4 w-4 mr-2" />
              إنشاء حرب عشائر جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>إنشاء حرب عشائر جديدة</DialogTitle>
              <DialogDescription>
                قم بإدخال تفاصيل حرب العشائر الجديدة. يمكنك إضافة المهام والمشاركين لاحقاً.
              </DialogDescription>
            </DialogHeader>
            <Form {...clanWarForm}>
              <form onSubmit={clanWarForm.handleSubmit(onCreateClanWar)} className="space-y-4">
                <FormField
                  control={clanWarForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>اسم الحرب</FormLabel>
                      <FormControl>
                        <Input placeholder="أدخل اسم حرب العشائر" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={clanWarForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>وصف الحرب</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="أدخل وصفاً لحرب العشائر" 
                          {...field} 
                          className="resize-none" 
                          rows={3}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={clanWarForm.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>تاريخ البدء</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={clanWarForm.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>تاريخ الانتهاء</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={clanWarForm.control}
                    name="seasonNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>رقم الموسم</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} min={1} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={clanWarForm.control}
                    name="maxParticipants"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>الحد الأقصى للمشاركين</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="غير محدود" 
                            value={field.value === null ? "" : field.value} 
                            onChange={(e) => {
                              const value = e.target.value === "" ? null : parseInt(e.target.value);
                              field.onChange(value);
                            }}
                            min={0}
                          />
                        </FormControl>
                        <FormDescription>
                          اتركه فارغاً لعدد غير محدود من المشاركين
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={clanWarForm.control}
                    name="minClanLevel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>الحد الأدنى لمستوى العشيرة</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} min={1} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={clanWarForm.control}
                    name="minMemberCount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>الحد الأدنى لعدد الأعضاء</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} min={1} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <DialogFooter className="gap-2 sm:gap-0">
                  <DialogClose asChild>
                    <Button type="button" variant="outline">إلغاء</Button>
                  </DialogClose>
                  <Button 
                    type="submit" 
                    className="bg-gradient-to-r from-[#5865F2] to-[#4752C4]"
                    disabled={createClanWarMutation.isPending}
                  >
                    {createClanWarMutation.isPending && (
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    )}
                    إنشاء حرب العشائر
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
      
      <Tabs value={activeClanWar ? "details" : "list"} onValueChange={(value) => {
        if (value === "list") setActiveClanWar(null);
      }}>
        <TabsList className="mb-4 bg-gray-800 p-1 rounded-xl">
          <TabsTrigger value="list" className="rounded-lg">
            قائمة حروب العشائر
          </TabsTrigger>
          <TabsTrigger value="details" className="rounded-lg" disabled={!activeClanWar}>
            تفاصيل الحرب
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="list" className="mt-0 space-y-6">
          <Card className="border-gray-700 bg-[#2F3136]">
            <CardHeader className="pb-2">
              <div className="flex flex-col sm:flex-row gap-4 justify-between">
                <div className="relative w-full max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="البحث عن حرب عشائر..."
                    className="pl-9 bg-gray-800"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4 text-gray-400" />
                  <Select
                    value={activeTab}
                    onValueChange={setActiveTab}
                  >
                    <SelectTrigger className="bg-gray-800 w-[140px]">
                      <SelectValue placeholder="الكل" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">كل الحروب</SelectItem>
                      <SelectItem value="active">الحروب النشطة</SelectItem>
                      <SelectItem value="upcoming">الحروب القادمة</SelectItem>
                      <SelectItem value="completed">الحروب المكتملة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoadingClanWars ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <RefreshCw className="h-8 w-8 animate-spin text-gray-400 mb-4" />
                  <p className="text-gray-400">جاري تحميل بيانات حروب العشائر...</p>
                </div>
              ) : filteredWars.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Swords className="h-12 w-12 text-gray-500 mb-4" />
                  <h3 className="text-xl font-semibold mb-2">لا توجد حروب عشائر</h3>
                  <p className="text-gray-400 max-w-md">
                    {activeTab !== "all" 
                      ? `لا توجد حروب عشائر ${activeTab === "active" ? "نشطة" : activeTab === "upcoming" ? "قادمة" : "مكتملة"} حالياً.`
                      : "لم يتم إنشاء أي حروب عشائر بعد. قم بإنشاء أول حرب باستخدام زر 'إنشاء حرب عشائر جديدة'."}
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {filteredWars.map((war: ClanWar) => (
                    <Card 
                      key={war.id} 
                      className={`
                        overflow-hidden border-t-4 cursor-pointer transition-all duration-200
                        hover:shadow-lg hover:translate-y-[-2px]
                        ${war.status === "active" ? "border-t-green-500" : 
                          war.status === "upcoming" ? "border-t-blue-500" : 
                          "border-t-purple-500"}
                      `}
                      onClick={() => setActiveClanWar(war)}
                    >
                      <CardContent className="p-0">
                        <div className="p-4 flex flex-col">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-bold text-lg flex items-center gap-2">
                                {war.name}
                                <Badge variant={
                                  war.status === "active" ? "default" : 
                                  war.status === "upcoming" ? "secondary" : 
                                  "outline"
                                }>
                                  {war.status === "active" ? "نشط" : 
                                   war.status === "upcoming" ? "قادم" : 
                                   "مكتمل"}
                                </Badge>
                              </h3>
                              <div className="flex items-center gap-2 text-sm text-gray-400 mt-1">
                                <CalendarDays className="h-3.5 w-3.5" />
                                <span>{formatDate(war.startDate)} - {formatDate(war.endDate)}</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-1 bg-gray-800 px-2 py-1 rounded-md">
                              <Trophy className="h-4 w-4 text-yellow-500" />
                              <span className="text-sm font-medium">الموسم {war.seasonNumber}</span>
                            </div>
                          </div>
                          
                          <p className="text-gray-300 text-sm my-3 line-clamp-2">{war.description}</p>
                          
                          <div className="flex justify-between mt-auto pt-2 border-t border-gray-700">
                            <div className="flex items-center gap-4">
                              <div className="flex items-center gap-1">
                                <Shield className="h-4 w-4 text-blue-400" />
                                <span className="text-sm">مستوى {war.minClanLevel}+</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Users className="h-4 w-4 text-gray-400" />
                                <span className="text-sm">{war.minMemberCount}+ عضو</span>
                              </div>
                            </div>
                            
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 px-2 text-xs"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setActiveClanWar(war);
                                }}
                              >
                                <Edit className="h-3 w-3 mr-1" />
                                تفاصيل
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="details" className="mt-0 space-y-6">
          {activeClanWar && (
            <>
              <Card className="border-gray-700 bg-[#2F3136]">
                <CardHeader className="pb-2 flex flex-row justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <span>{activeClanWar.name}</span>
                      <Badge variant={
                        activeClanWar.status === "active" ? "default" : 
                        activeClanWar.status === "upcoming" ? "secondary" : 
                        "outline"
                      }>
                        {activeClanWar.status === "active" ? "نشط" : 
                         activeClanWar.status === "upcoming" ? "قادم" : 
                         "مكتمل"}
                      </Badge>
                    </CardTitle>
                    <CardDescription>
                      <div className="flex items-center gap-2 mt-1">
                        <CalendarDays className="h-3.5 w-3.5" />
                        <span>{formatDate(activeClanWar.startDate)} - {formatDate(activeClanWar.endDate)}</span>
                        <span className="px-2">•</span>
                        <Trophy className="h-3.5 w-3.5 text-yellow-500" />
                        <span>الموسم {activeClanWar.seasonNumber}</span>
                      </div>
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <div className="flex">
                      {activeClanWar.status === "upcoming" && (
                        <Button 
                          variant="default" 
                          size="sm"
                          onClick={() => updateClanWarStatusMutation.mutate({ warId: activeClanWar.id, status: "active" })}
                        >
                          <Activity className="h-4 w-4 mr-1" />
                          بدء الحرب
                        </Button>
                      )}
                      {activeClanWar.status === "active" && (
                        <Button 
                          variant="destructive" 
                          size="sm"
                          onClick={() => updateClanWarStatusMutation.mutate({ warId: activeClanWar.id, status: "completed" })}
                        >
                          <Flag className="h-4 w-4 mr-1" />
                          إنهاء الحرب
                        </Button>
                      )}
                    </div>
                    <Button 
                      variant="outline" 
                      size="icon" 
                      className="h-8 w-8"
                      onClick={() => setActiveClanWar(null)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="font-semibold mb-2">وصف الحرب</h3>
                      <p className="text-gray-300 text-sm">{activeClanWar.description}</p>
                    </div>
                    
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                      <Card>
                        <CardHeader className="p-4 pb-2">
                          <CardTitle className="text-base flex items-center">
                            <Shield className="mr-2 h-4 w-4" />
                            شروط المشاركة
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-4 pt-2">
                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-gray-400 text-sm">الحد الأدنى لمستوى العشيرة</span>
                              <Badge variant="outline">{activeClanWar.minClanLevel}</Badge>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-gray-400 text-sm">الحد الأدنى لعدد الأعضاء</span>
                              <Badge variant="outline">{activeClanWar.minMemberCount}</Badge>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-gray-400 text-sm">الحد الأقصى للمشاركين</span>
                              <Badge variant="outline">
                                {activeClanWar.maxParticipants || "غير محدود"}
                              </Badge>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="p-4 pb-2">
                          <CardTitle className="text-base flex items-center">
                            <Award className="mr-2 h-4 w-4" />
                            الجوائز
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-4 pt-2">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <Badge className="bg-gradient-to-r from-yellow-500 to-amber-400">المركز الأول</Badge>
                              <span className="text-sm">5000 عملة + رتبة مميزة</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge className="bg-gradient-to-r from-gray-300 to-gray-400 text-gray-800">المركز الثاني</Badge>
                              <span className="text-sm">3000 عملة</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge className="bg-gradient-to-r from-amber-700 to-amber-600">المركز الثالث</Badge>
                              <span className="text-sm">1500 عملة</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card>
                        <CardHeader className="p-4 pb-2">
                          <CardTitle className="text-base flex items-center">
                            <Clock className="mr-2 h-4 w-4" />
                            حالة الحرب
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-4 pt-2">
                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-gray-400 text-sm">الحالة</span>
                              <Badge variant={
                                activeClanWar.status === "active" ? "default" : 
                                activeClanWar.status === "upcoming" ? "secondary" : 
                                "outline"
                              }>
                                {activeClanWar.status === "active" ? "نشطة" : 
                                 activeClanWar.status === "upcoming" ? "قادمة" : 
                                 "مكتملة"}
                              </Badge>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-gray-400 text-sm">عدد المشاركين</span>
                              <Badge variant="outline">
                                {participants.length}
                                {activeClanWar.maxParticipants && ` / ${activeClanWar.maxParticipants}`}
                              </Badge>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-gray-400 text-sm">عدد المهام</span>
                              <Badge variant="outline">{tasks.length}</Badge>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                    
                    <Tabs defaultValue="participants" className="w-full">
                      <TabsList className="bg-gray-800">
                        <TabsTrigger value="participants">المشاركون</TabsTrigger>
                        <TabsTrigger value="tasks">المهام</TabsTrigger>
                        <TabsTrigger value="add-participant">إضافة مشاركين</TabsTrigger>
                      </TabsList>
                      
                      <TabsContent value="participants" className="mt-4">
                        <Card>
                          <CardHeader className="pb-0">
                            <CardTitle className="text-lg">المشاركون في الحرب</CardTitle>
                            <CardDescription>قائمة العشائر المشاركة في حرب العشائر وترتيبها</CardDescription>
                          </CardHeader>
                          <CardContent>
                            {isLoadingParticipants ? (
                              <div className="flex justify-center py-8">
                                <RefreshCw className="h-8 w-8 animate-spin text-gray-400" />
                              </div>
                            ) : sortedParticipants.length === 0 ? (
                              <div className="text-center py-8">
                                <Users className="h-12 w-12 mx-auto text-gray-500 mb-2" />
                                <p className="text-gray-400">لا يوجد مشاركون في هذه الحرب حتى الآن</p>
                                <p className="text-sm text-gray-500 mt-1">
                                  قم بالانتقال إلى تبويب "إضافة مشاركين" لإضافة عشائر مشاركة
                                </p>
                              </div>
                            ) : (
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead className="w-12">#</TableHead>
                                    <TableHead>العشيرة</TableHead>
                                    <TableHead className="text-center">النقاط</TableHead>
                                    <TableHead className="text-center">المهام المكتملة</TableHead>
                                    <TableHead className="text-center">التحديات</TableHead>
                                    <TableHead className="text-left">الحالة</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {sortedParticipants.map((participant: ClanWarParticipant) => (
                                    <TableRow key={participant.id}>
                                      <TableCell className="font-medium">
                                        {participant.rank <= 3 ? (
                                          <div className={`
                                            w-6 h-6 rounded-full flex items-center justify-center
                                            ${participant.rank === 1 
                                              ? 'bg-gradient-to-r from-yellow-500 to-amber-400 text-black' 
                                              : participant.rank === 2 
                                                ? 'bg-gradient-to-r from-gray-300 to-gray-400 text-black' 
                                                : 'bg-gradient-to-r from-amber-700 to-amber-600'}
                                          `}>
                                            {participant.rank}
                                          </div>
                                        ) : participant.rank}
                                      </TableCell>
                                      <TableCell>
                                        <div className="flex items-center gap-2">
                                          <Avatar className="h-8 w-8">
                                            {participant.clanLogo ? 
                                              <AvatarImage src={participant.clanLogo} /> : null
                                            }
                                            <AvatarFallback className="bg-gray-700">
                                              {participant.clanTag}
                                            </AvatarFallback>
                                          </Avatar>
                                          <div>
                                            <div className="font-medium">{participant.clanName}</div>
                                            <div className="text-xs text-gray-400">{participant.clanTag}</div>
                                          </div>
                                        </div>
                                      </TableCell>
                                      <TableCell className="text-center font-bold">
                                        {participant.points}
                                      </TableCell>
                                      <TableCell className="text-center">
                                        {participant.tasksCompleted}
                                      </TableCell>
                                      <TableCell className="text-center">
                                        <div className="flex items-center justify-center gap-1 text-sm">
                                          <span className="text-green-500">{participant.challengesWon}</span>
                                          <span className="text-gray-400">/</span>
                                          <span className="text-red-500">{participant.challengesLost}</span>
                                        </div>
                                      </TableCell>
                                      <TableCell>
                                        {participant.blacklisted ? (
                                          <Badge variant="destructive" className="flex items-center gap-1">
                                            <AlertTriangle className="h-3 w-3" />
                                            محظور
                                          </Badge>
                                        ) : (
                                          <Badge variant="default" className="bg-green-500 flex items-center gap-1">
                                            <CheckCircle className="h-3 w-3" />
                                            نشط
                                          </Badge>
                                        )}
                                      </TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            )}
                          </CardContent>
                        </Card>
                      </TabsContent>
                      
                      <TabsContent value="tasks" className="mt-4 space-y-4">
                        <div className="flex justify-between items-center">
                          <h3 className="text-lg font-semibold">مهام الحرب</h3>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm">
                                <Plus className="h-4 w-4 mr-1" />
                                إضافة مهمة
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>إضافة مهمة جديدة</DialogTitle>
                                <DialogDescription>
                                  أضف مهمة جديدة إلى حرب العشائر. يمكن للعشائر المشاركة إكمال هذه المهمة للحصول على نقاط.
                                </DialogDescription>
                              </DialogHeader>
                              <Form {...taskForm}>
                                <form onSubmit={taskForm.handleSubmit(onAddTask)} className="space-y-4">
                                  <FormField
                                    control={taskForm.control}
                                    name="name"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>اسم المهمة</FormLabel>
                                        <FormControl>
                                          <Input placeholder="أدخل اسم المهمة" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                  
                                  <FormField
                                    control={taskForm.control}
                                    name="description"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>وصف المهمة</FormLabel>
                                        <FormControl>
                                          <Textarea 
                                            placeholder="أدخل وصفاً للمهمة" 
                                            {...field} 
                                            className="resize-none" 
                                            rows={3}
                                          />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                  
                                  <div className="grid grid-cols-2 gap-4">
                                    <FormField
                                      control={taskForm.control}
                                      name="type"
                                      render={({ field }) => (
                                        <FormItem>
                                          <FormLabel>نوع المهمة</FormLabel>
                                          <Select
                                            onValueChange={field.onChange}
                                            defaultValue={field.value}
                                          >
                                            <FormControl>
                                              <SelectTrigger>
                                                <SelectValue placeholder="اختر نوع المهمة" />
                                              </SelectTrigger>
                                            </FormControl>
                                            <SelectContent>
                                              <SelectItem value="challenge">تحدي عام</SelectItem>
                                              <SelectItem value="event">حدث خاص</SelectItem>
                                              <SelectItem value="daily">مهمة يومية</SelectItem>
                                              <SelectItem value="pvp">تحدي التنافس</SelectItem>
                                            </SelectContent>
                                          </Select>
                                          <FormMessage />
                                        </FormItem>
                                      )}
                                    />
                                    
                                    <FormField
                                      control={taskForm.control}
                                      name="difficulty"
                                      render={({ field }) => (
                                        <FormItem>
                                          <FormLabel>صعوبة المهمة</FormLabel>
                                          <Select
                                            onValueChange={field.onChange}
                                            defaultValue={field.value}
                                          >
                                            <FormControl>
                                              <SelectTrigger>
                                                <SelectValue placeholder="اختر صعوبة المهمة" />
                                              </SelectTrigger>
                                            </FormControl>
                                            <SelectContent>
                                              <SelectItem value="easy">سهلة</SelectItem>
                                              <SelectItem value="medium">متوسطة</SelectItem>
                                              <SelectItem value="hard">صعبة</SelectItem>
                                              <SelectItem value="extreme">قصوى</SelectItem>
                                            </SelectContent>
                                          </Select>
                                          <FormMessage />
                                        </FormItem>
                                      )}
                                    />
                                  </div>
                                  
                                  <FormField
                                    control={taskForm.control}
                                    name="pointsValue"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>قيمة النقاط</FormLabel>
                                        <FormControl>
                                          <Input type="number" {...field} min={1} />
                                        </FormControl>
                                        <FormDescription>
                                          عدد النقاط التي سيحصل عليها المشاركون عند إكمال هذه المهمة
                                        </FormDescription>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                  
                                  <div className="grid grid-cols-2 gap-4">
                                    <FormField
                                      control={taskForm.control}
                                      name="startDate"
                                      render={({ field }) => (
                                        <FormItem>
                                          <FormLabel>تاريخ البدء</FormLabel>
                                          <FormControl>
                                            <Input type="date" {...field} />
                                          </FormControl>
                                          <FormMessage />
                                        </FormItem>
                                      )}
                                    />
                                    
                                    <FormField
                                      control={taskForm.control}
                                      name="endDate"
                                      render={({ field }) => (
                                        <FormItem>
                                          <FormLabel>تاريخ الانتهاء</FormLabel>
                                          <FormControl>
                                            <Input type="date" {...field} />
                                          </FormControl>
                                          <FormMessage />
                                        </FormItem>
                                      )}
                                    />
                                  </div>
                                  
                                  <DialogFooter className="gap-2 sm:gap-0">
                                    <DialogClose asChild>
                                      <Button type="button" variant="outline">إلغاء</Button>
                                    </DialogClose>
                                    <Button 
                                      type="submit" 
                                      className="bg-gradient-to-r from-[#5865F2] to-[#4752C4]"
                                      disabled={addTaskMutation.isPending}
                                    >
                                      {addTaskMutation.isPending && (
                                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                                      )}
                                      إضافة المهمة
                                    </Button>
                                  </DialogFooter>
                                </form>
                              </Form>
                            </DialogContent>
                          </Dialog>
                        </div>
                        
                        <Card>
                          <CardContent className="p-0">
                            {isLoadingTasks ? (
                              <div className="flex justify-center py-8">
                                <RefreshCw className="h-8 w-8 animate-spin text-gray-400" />
                              </div>
                            ) : tasks.length === 0 ? (
                              <div className="text-center py-8">
                                <Flag className="h-12 w-12 mx-auto text-gray-500 mb-2" />
                                <p className="text-gray-400">لا توجد مهام في هذه الحرب حتى الآن</p>
                                <p className="text-sm text-gray-500 mt-1">
                                  استخدم زر "إضافة مهمة" لإنشاء مهام جديدة
                                </p>
                              </div>
                            ) : (
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead>المهمة</TableHead>
                                    <TableHead className="text-center">النقاط</TableHead>
                                    <TableHead className="text-center">النوع</TableHead>
                                    <TableHead className="text-center">الصعوبة</TableHead>
                                    <TableHead>التاريخ</TableHead>
                                    <TableHead className="text-left">الحالة</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {tasks.map((task: ClanWarTask) => (
                                    <TableRow key={task.id}>
                                      <TableCell>
                                        <div>
                                          <div className="font-medium">{task.name}</div>
                                          <div className="text-xs text-gray-400 line-clamp-1">{task.description}</div>
                                        </div>
                                      </TableCell>
                                      <TableCell className="text-center font-bold">
                                        {task.pointsValue}
                                      </TableCell>
                                      <TableCell className="text-center">
                                        <Badge variant="outline">
                                          {task.type === "challenge" ? "تحدي عام" :
                                           task.type === "event" ? "حدث خاص" :
                                           task.type === "daily" ? "يومية" :
                                           "تنافسية"}
                                        </Badge>
                                      </TableCell>
                                      <TableCell className="text-center">
                                        <Badge variant={
                                          task.difficulty === "easy" ? "secondary" :
                                          task.difficulty === "medium" ? "default" :
                                          task.difficulty === "hard" ? "destructive" :
                                          "outline"
                                        }>
                                          {task.difficulty === "easy" ? "سهلة" :
                                           task.difficulty === "medium" ? "متوسطة" :
                                           task.difficulty === "hard" ? "صعبة" :
                                           "قصوى"}
                                        </Badge>
                                      </TableCell>
                                      <TableCell>
                                        <div className="text-xs text-gray-400">
                                          <div>{formatDate(task.startDate)}</div>
                                          <div>إلى {formatDate(task.endDate)}</div>
                                        </div>
                                      </TableCell>
                                      <TableCell>
                                        <Badge variant={
                                          task.status === "active" ? "default" :
                                          task.status === "upcoming" ? "secondary" :
                                          task.status === "completed" ? "outline" :
                                          "destructive"
                                        } className="flex items-center gap-1">
                                          {task.status === "active" ? (
                                            <>
                                              <CheckCircle className="h-3 w-3" />
                                              نشطة
                                            </>
                                          ) : task.status === "upcoming" ? (
                                            <>
                                              <Clock className="h-3 w-3" />
                                              قادمة
                                            </>
                                          ) : task.status === "completed" ? (
                                            <>
                                              <Flag className="h-3 w-3" />
                                              مكتملة
                                            </>
                                          ) : (
                                            <>
                                              <AlertTriangle className="h-3 w-3" />
                                              ملغية
                                            </>
                                          )}
                                        </Badge>
                                      </TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            )}
                          </CardContent>
                        </Card>
                      </TabsContent>
                      
                      <TabsContent value="add-participant" className="mt-4 space-y-4">
                        <div className="flex justify-between items-center">
                          <h3 className="text-lg font-semibold">إضافة عشائر مشاركة</h3>
                          <div className="relative w-64">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                            <Input
                              placeholder="بحث عن عشيرة..."
                              className="pl-9 bg-gray-800"
                              value={searchQuery}
                              onChange={(e) => setSearchQuery(e.target.value)}
                            />
                          </div>
                        </div>
                        
                        <Card>
                          <CardContent className="p-0">
                            {isLoadingClans ? (
                              <div className="flex justify-center py-8">
                                <RefreshCw className="h-8 w-8 animate-spin text-gray-400" />
                              </div>
                            ) : availableClans.length === 0 ? (
                              <div className="text-center py-8">
                                <Shield className="h-12 w-12 mx-auto text-gray-500 mb-2" />
                                <p className="text-gray-400">لا توجد عشائر متاحة للمشاركة</p>
                                <p className="text-sm text-gray-500 mt-1">
                                  تأكد من وجود عشائر تلبي شروط المشاركة (مستوى العشيرة: {activeClanWar.minClanLevel}+، عدد الأعضاء: {activeClanWar.minMemberCount}+)
                                </p>
                              </div>
                            ) : (
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead>العشيرة</TableHead>
                                    <TableHead className="text-center">المستوى</TableHead>
                                    <TableHead className="text-center">عدد الأعضاء</TableHead>
                                    <TableHead className="text-left">إجراء</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {availableClans.map((clan: Clan) => (
                                    <TableRow key={clan.id}>
                                      <TableCell>
                                        <div className="flex items-center gap-2">
                                          <Avatar className="h-8 w-8">
                                            {clan.logo ? <AvatarImage src={clan.logo} /> : null}
                                            <AvatarFallback className="bg-gray-700">
                                              {clan.tag}
                                            </AvatarFallback>
                                          </Avatar>
                                          <div>
                                            <div className="font-medium">{clan.name}</div>
                                            <div className="text-xs text-gray-400">{clan.tag}</div>
                                          </div>
                                        </div>
                                      </TableCell>
                                      <TableCell className="text-center">
                                        <div className="flex items-center justify-center">
                                          <Star className="h-4 w-4 mr-1 text-yellow-500" />
                                          <span>{clan.level}</span>
                                        </div>
                                      </TableCell>
                                      <TableCell className="text-center">
                                        <div className="flex items-center justify-center">
                                          <Users className="h-4 w-4 mr-1 text-gray-400" />
                                          <span>{clan.memberCount}</span>
                                        </div>
                                      </TableCell>
                                      <TableCell>
                                        <Button 
                                          variant="outline" 
                                          size="sm"
                                          className="w-full"
                                          onClick={() => addParticipantMutation.mutate(clan.id)}
                                          disabled={addParticipantMutation.isPending}
                                        >
                                          <PlusSquare className="h-4 w-4 mr-1" />
                                          إضافة
                                        </Button>
                                      </TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            )}
                          </CardContent>
                        </Card>
                      </TabsContent>
                    </Tabs>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
import { useState, useEffect, useMemo } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ShoppingCart, 
  Crown, 
  Palette, 
  ScrollText, 
  Loader2, 
  AlertCircle, 
  Coins, 
  Sparkles,
  Package, 
  Tag, 
  Sword, 
  Shield, 
  Clock,
  Users, 
  Image,
  Search,
  Filter
} from "lucide-react";
import { 
  Select, 
  SelectContent, 
  SelectGroup, 
  SelectItem, 
  SelectLabel, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { levelingSystem } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { useMediaQuery } from "../hooks/use-media-query";
import { Progress } from "@/components/ui/progress";

interface ShopItem {
  id: number;
  name: string;
  description: string;
  price: number;
  type: string;
  duration?: number;
  discount?: number;
  rarity?: string;
  image?: string;
  available: boolean;
  createdAt?: string;
  createdBy?: string;
  limited?: boolean;
  stock?: number;
}

interface UserItem {
  id: number;
  userId: string;
  itemId: number;
  quantity: number;
  purchasedAt: string;
  expiresAt?: string;
  active: boolean;
  itemName: string;
  itemType: string;
}

interface User {
  userId: string;
  xp: number;
  level: number;
  coins: number;
  is_vip: boolean;
  inventory?: UserItem[];
}

interface Coupon {
  code: string;
  discount: number;
  type: 'percentage' | 'fixed';
  expiresAt: string;
  usageLimit: number;
  usageCount: number;
  minPurchase?: number;
  itemTypes?: string[];
}

interface MysteryBox {
  id: number;
  name: string;
  description: string;
  price: number;
  items: {
    itemId: number;
    chance: number; // 1-100
  }[];
}

export default function Shop() {
  const [shopItems, setShopItems] = useState<ShopItem[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [selectedUser, setSelectedUser] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState<Record<number, boolean>>({});
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState<string>("all");
  const [sortOrder, setSortOrder] = useState<"price_asc" | "price_desc" | "newest" | "oldest">("price_asc");
  const [showFilterDialog, setShowFilterDialog] = useState(false);
  const [inventory, setInventory] = useState<UserItem[]>([]);
  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [showInventory, setShowInventory] = useState(false);
  const [mysteryBoxes, setMysteryBoxes] = useState<MysteryBox[]>([]);
  const [isMobile, setIsMobile] = useState(false);
  
  // نستخدم hook للتحقق من حجم الشاشة
  const isMobileScreen = useMediaQuery("(max-width: 768px)");
  
  useEffect(() => {
    setIsMobile(isMobileScreen);
  }, [isMobileScreen]);

  // قائمة المستخدمين للاختيار
  const fetchUsers = async () => {
    try {
      const data = await levelingSystem.getUsers();
      setUsers(data);
      if (data.length > 0 && !selectedUser) {
        setSelectedUser(data[0].userId);
      }
    } catch (error) {
      console.error("Error fetching users:", error);
      toast({
        title: "خطأ",
        description: "فشل في جلب بيانات المستخدمين",
        variant: "destructive",
      });
    }
  };

  // جلب عناصر المتجر
  const fetchShopItems = async () => {
    try {
      setLoading(true);
      const data = await levelingSystem.getShopItems();
      setShopItems(data);
    } catch (error) {
      console.error("Error fetching shop items:", error);
      toast({
        title: "خطأ",
        description: "فشل في جلب عناصر المتجر",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchShopItems();
    fetchUsers();
  }, []);

  // شراء عنصر من المتجر
  const purchaseItem = async (itemId: number) => {
    if (!selectedUser) {
      toast({
        title: "خطأ",
        description: "الرجاء اختيار مستخدم أولاً",
        variant: "destructive",
      });
      return;
    }

    try {
      setPurchasing({ ...purchasing, [itemId]: true });
      
      const user = users.find(u => u.userId === selectedUser);
      const item = shopItems.find(i => i.id === itemId);
      
      if (!user || !item) return;
      
      if (user.coins < item.price) {
        toast({
          title: "رصيد غير كافي",
          description: `يحتاج المستخدم ${item.price - user.coins} عملات إضافية لشراء هذا العنصر`,
          variant: "destructive",
        });
        return;
      }
      
      await levelingSystem.purchaseItem(selectedUser, itemId);
      
      // تحديث بيانات المستخدمين بعد الشراء
      await fetchUsers();
      
      toast({
        title: "تم الشراء بنجاح",
        description: `تم شراء ${item.name} للمستخدم ${selectedUser}`,
      });
    } catch (error) {
      console.error("Error purchasing item:", error);
      toast({
        title: "خطأ",
        description: "فشل في شراء العنصر",
        variant: "destructive",
      });
    } finally {
      setPurchasing({ ...purchasing, [itemId]: false });
    }
  };

  // جلب عناصر المستخدم (المخزون)
  const fetchUserInventory = async () => {
    if (!selectedUser) return;
    
    try {
      // استدعاء API لجلب عناصر المستخدم
      const response = await fetch(`/api/leveling/users/${selectedUser}/inventory`);
      
      if (!response.ok) {
        throw new Error("فشل في جلب مخزون المستخدم");
      }
      
      const data = await response.json();
      setInventory(data);
    } catch (error) {
      console.error("Error fetching user inventory:", error);
      toast({
        title: "خطأ",
        description: "فشل في جلب مخزون المستخدم",
        variant: "destructive",
      });
    }
  };

  // جلب صناديق الحظ
  const fetchMysteryBoxes = async () => {
    try {
      // استدعاء API لجلب صناديق الحظ
      const response = await fetch('/api/leveling/mystery-boxes');
      
      if (!response.ok) {
        // تجاهل الخطأ إذا لم تكن الميزة متاحة بعد
        return;
      }
      
      const data = await response.json();
      setMysteryBoxes(data);
    } catch (error) {
      // تجاهل الخطأ إذا لم تكن الميزة متاحة بعد
      console.log("Mystery boxes not available yet");
    }
  };

  useEffect(() => {
    if (selectedUser) {
      fetchUserInventory();
    }
  }, [selectedUser]);

  // تحقق من كود الخصم
  const validateCoupon = async (code: string) => {
    try {
      // استدعاء API للتحقق من الكوبون
      const response = await fetch(`/api/leveling/coupons/validate?code=${code}`);
      
      if (!response.ok) {
        throw new Error("كود الخصم غير صالح");
      }
      
      const coupon = await response.json();
      setAppliedCoupon(coupon);
      
      toast({
        title: "تم تطبيق الخصم",
        description: coupon.type === 'percentage' 
          ? `خصم ${coupon.discount}% على مشترياتك القادمة` 
          : `خصم ${coupon.discount} عملة على مشترياتك القادمة`,
      });
    } catch (error) {
      setAppliedCoupon(null);
      toast({
        title: "خطأ",
        description: "كود الخصم غير صالح أو منتهي الصلاحية",
        variant: "destructive",
      });
    }
  };

  // فتح صندوق الحظ
  const openMysteryBox = async (boxId: number) => {
    if (!selectedUser) {
      toast({
        title: "خطأ",
        description: "الرجاء اختيار مستخدم أولاً",
        variant: "destructive",
      });
      return;
    }
    
    try {
      // استدعاء API لفتح صندوق الحظ
      const response = await fetch(`/api/leveling/mystery-boxes/${boxId}/open`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: selectedUser })
      });
      
      if (!response.ok) {
        throw new Error("فشل في فتح صندوق الحظ");
      }
      
      const result = await response.json();
      
      toast({
        title: "تهانينا!",
        description: `حصلت على ${result.itemName}!`,
      });
      
      await fetchUsers();
      await fetchUserInventory();
    } catch (error) {
      console.error("Error opening mystery box:", error);
      toast({
        title: "خطأ",
        description: "فشل في فتح صندوق الحظ",
        variant: "destructive",
      });
    }
  };

  // حساب السعر مع الخصم
  const calculateDiscountedPrice = (price: number): number => {
    if (!appliedCoupon) return price;
    
    if (appliedCoupon.type === 'percentage') {
      return Math.max(0, Math.floor(price * (1 - appliedCoupon.discount / 100)));
    } else {
      return Math.max(0, price - appliedCoupon.discount);
    }
  };

  // الحصول على أيقونة حسب نوع العنصر
  const getItemIcon = (type: string) => {
    switch (type) {
      case "VIP":
        return <Crown className="h-5 w-5 text-yellow-500" />;
      case "COLOR":
        return <Palette className="h-5 w-5 text-purple-500" />;
      case "QUOTE":
        return <ScrollText className="h-5 w-5 text-blue-500" />;
      case "MYSTERY_BOX":
        return <Package className="h-5 w-5 text-amber-500" />;
      case "WEAPON":
        return <Sword className="h-5 w-5 text-red-500" />;
      case "ARMOR":
        return <Shield className="h-5 w-5 text-blue-500" />;
      case "BACKGROUND":
        return <Image className="h-5 w-5 text-purple-400" />;
      default:
        return <ShoppingCart className="h-5 w-5" />;
    }
  };

  // تصنيف العناصر حسب النوع
  const vipItems = shopItems.filter(item => item.type === "VIP");
  const colorItems = shopItems.filter(item => item.type === "COLOR");
  const quoteItems = shopItems.filter(item => item.type === "QUOTE");
  const otherItems = shopItems.filter(item => !["VIP", "COLOR", "QUOTE"].includes(item.type));

  // الحصول على المستخدم المحدد
  const selectedUserData = users.find(u => u.userId === selectedUser);

  // فلترة وترتيب العناصر
  const filteredItems = useMemo(() => {
    let filtered = [...shopItems].filter(item => {
      // تصفية حسب النوع
      if (filterType !== "all" && item.type !== filterType.toUpperCase()) {
        return false;
      }
      
      // تصفية حسب البحث
      if (searchQuery && !item.name.toLowerCase().includes(searchQuery.toLowerCase()) && 
          !item.description.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      
      return true;
    });
    
    // ترتيب العناصر
    filtered.sort((a, b) => {
      switch (sortOrder) {
        case "price_asc":
          return a.price - b.price;
        case "price_desc":
          return b.price - a.price;
        case "newest":
          return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
        case "oldest":
          return new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime();
        default:
          return 0;
      }
    });
    
    return filtered;
  }, [shopItems, filterType, searchQuery, sortOrder]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold">متجر العناصر</h1>
          <p className="text-muted-foreground">شراء عناصر وميزات للمستخدمين</p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-end sm:items-center gap-2">
          {/* اختيار المستخدم */}
          <Select
            value={selectedUser}
            onValueChange={setSelectedUser}
          >
            <SelectTrigger className="w-full sm:w-[200px]">
              <SelectValue placeholder="اختر مستخدم" />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                <SelectLabel>المستخدمين</SelectLabel>
                {users.map(user => (
                  <SelectItem key={user.userId} value={user.userId}>
                    {user.userId} (المستوى {user.level})
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>
          
          {/* عرض مخزون المستخدم */}
          {selectedUser && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowInventory(!showInventory)}
            >
              {showInventory ? "إخفاء المخزون" : "عرض المخزون"}
            </Button>
          )}
          
          {/* حالة المستخدم المحدد */}
          {selectedUserData && (
            <Card className="bg-gradient-to-r from-[#3f4679] to-[#2B2D31] border-0 w-full sm:w-auto">
              <CardContent className="p-4 flex items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-blue-400" />
                  <div>
                    <p className="text-sm text-muted-foreground">المستخدم</p>
                    <p className="font-semibold">{selectedUserData.userId}</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Coins className="h-5 w-5 mr-1 text-yellow-500" />
                  <span className="font-bold">{selectedUserData.coins}</span>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* عرض مخزون المستخدم */}
      {showInventory && inventory.length > 0 && (
        <Card className="overflow-hidden border border-border/40">
          <CardHeader className="bg-muted/30 p-4">
            <CardTitle className="text-xl">مخزون المستخدم</CardTitle>
            <CardDescription>العناصر التي يمتلكها المستخدم {selectedUser}</CardDescription>
          </CardHeader>
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {inventory.map(item => (
                <Card key={item.id} className="overflow-hidden">
                  <CardHeader className="bg-muted p-3">
                    <div className="flex items-center gap-2">
                      {getItemIcon(item.itemType)}
                      <p className="font-medium">{item.itemName}</p>
                    </div>
                  </CardHeader>
                  <CardContent className="p-3">
                    <div className="flex justify-between items-center">
                      <p className="text-sm text-muted-foreground">الكمية: {item.quantity}</p>
                      {item.expiresAt && (
                        <p className="text-sm text-muted-foreground">
                          ينتهي في: {new Date(item.expiresAt).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* شريط البحث والفلترة والترتيب */}
      {!loading && shopItems.length > 0 && (
        <div className="flex flex-col sm:flex-row gap-3 mb-4 items-end sm:items-center">
          <div className="flex-1 relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="بحث عن عنصر..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8"
            />
          </div>
          
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowFilterDialog(true)}
              className="flex items-center gap-1"
            >
              <Filter className="h-4 w-4" />
              <span>فلترة</span>
            </Button>
            
            <Dialog open={showFilterDialog} onOpenChange={setShowFilterDialog}>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>خيارات الفلترة والترتيب</DialogTitle>
                  <DialogDescription>
                    تخصيص عرض عناصر المتجر حسب تفضيلاتك
                  </DialogDescription>
                </DialogHeader>
                
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="filter-type" className="text-right">
                      نوع العنصر
                    </Label>
                    <Select
                      value={filterType}
                      onValueChange={setFilterType}
                    >
                      <SelectTrigger className="col-span-3" id="filter-type">
                        <SelectValue placeholder="اختر نوع العنصر" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">الكل</SelectItem>
                        <SelectItem value="vip">عضويات VIP</SelectItem>
                        <SelectItem value="color">ألوان مخصصة</SelectItem>
                        <SelectItem value="quote">اقتباسات</SelectItem>
                        <SelectItem value="mystery_box">صناديق الحظ</SelectItem>
                        <SelectItem value="weapon">أسلحة</SelectItem>
                        <SelectItem value="armor">دروع</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="sort-order" className="text-right">
                      ترتيب حسب
                    </Label>
                    <Select
                      value={sortOrder}
                      onValueChange={(value) => setSortOrder(value as any)}
                    >
                      <SelectTrigger className="col-span-3" id="sort-order">
                        <SelectValue placeholder="اختر طريقة الترتيب" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="price_asc">السعر: من الأقل إلى الأعلى</SelectItem>
                        <SelectItem value="price_desc">السعر: من الأعلى إلى الأقل</SelectItem>
                        <SelectItem value="newest">الأحدث أولاً</SelectItem>
                        <SelectItem value="oldest">الأقدم أولاً</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <DialogFooter>
                  <Button onClick={() => setShowFilterDialog(false)}>تطبيق</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            
            {/* قسم الكوبونات */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="flex items-center gap-1">
                  <Tag className="h-4 w-4" />
                  <span>كوبون خصم</span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-72">
                <div className="space-y-4">
                  <h4 className="font-medium">تطبيق كوبون خصم</h4>
                  <div className="flex gap-2">
                    <Input
                      placeholder="أدخل كود الخصم"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                    />
                    <Button 
                      size="sm" 
                      onClick={() => validateCoupon(couponCode)}
                      disabled={!couponCode}
                    >
                      تطبيق
                    </Button>
                  </div>
                  
                  {appliedCoupon && (
                    <div className="p-2 bg-primary/10 rounded-md">
                      <div className="flex justify-between items-center">
                        <p className="text-sm font-medium">كوبون مفعل</p>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setAppliedCoupon(null)}
                          className="h-6 w-6 p-0"
                        >
                          &times;
                        </Button>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {appliedCoupon.type === 'percentage' 
                          ? `خصم ${appliedCoupon.discount}%` 
                          : `خصم ${appliedCoupon.discount} عملة`}
                      </div>
                    </div>
                  )}
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : shopItems.length === 0 ? (
        <Card>
          <CardContent className="p-8 flex flex-col items-center justify-center">
            <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium text-center">لا توجد عناصر متاحة في المتجر حالياً</p>
            <p className="text-muted-foreground text-center mt-2">ستتم إضافة عناصر جديدة قريباً</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {/* صناديق الحظ المميزة */}
          {mysteryBoxes.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-yellow-500" />
                صناديق الحظ المميزة
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {mysteryBoxes.map((box) => (
                  <Card key={box.id} className="overflow-hidden border-amber-500/20">
                    <CardHeader className="bg-gradient-to-r from-amber-700 to-yellow-600">
                      <div className="flex justify-between items-start">
                        <CardTitle className="flex items-center text-white">
                          <Package className="h-5 w-5 text-white" />
                          <span className="mr-2">{box.name}</span>
                        </CardTitle>
                        <Badge variant="outline" className="border-white/20 text-white">
                          {box.price} <Coins className="h-3.5 w-3.5 ml-1 inline" />
                        </Badge>
                      </div>
                      <CardDescription className="text-white/80">
                        {box.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="space-y-2">
                        <p className="text-sm">احتمالية الحصول على العناصر التالية:</p>
                        <div className="space-y-1">
                          {box.items.slice(0, 3).map((chance, idx) => (
                            <div key={idx} className="space-y-1">
                              <div className="flex justify-between text-sm">
                                <span>؟؟؟</span>
                                <span>{chance.chance}%</span>
                              </div>
                              <Progress value={chance.chance} className="h-2" />
                            </div>
                          ))}
                          {box.items.length > 3 && (
                            <p className="text-xs text-muted-foreground text-center mt-2">
                              +{box.items.length - 3} عناصر أخرى
                            </p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button 
                        className="w-full bg-gradient-to-r from-amber-600 to-yellow-500 hover:from-amber-700 hover:to-yellow-600"
                        onClick={() => openMysteryBox(box.id)}
                        disabled={selectedUserData ? selectedUserData.coins < box.price : true}
                      >
                        <Sparkles className="h-4 w-4 mr-2" />
                        فتح الصندوق
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* عناصر المتجر */}
          <div>
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="mb-4">
                <TabsTrigger value="all">الكل</TabsTrigger>
                <TabsTrigger value="vip">عضويات VIP</TabsTrigger>
                <TabsTrigger value="colors">ألوان مخصصة</TabsTrigger>
                <TabsTrigger value="quotes">اقتباسات</TabsTrigger>
                {otherItems.length > 0 && <TabsTrigger value="other">أخرى</TabsTrigger>}
              </TabsList>
              
              <TabsContent value="all" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredItems.map((item: ShopItem) => (
                    <ShopItemCard 
                      key={item.id} 
                      item={item} 
                      onPurchase={purchaseItem} 
                      isPurchasing={purchasing[item.id] || false}
                      getItemIcon={getItemIcon}
                      userCoins={selectedUserData?.coins || 0}
                      appliedCoupon={appliedCoupon}
                      calculateDiscountedPrice={calculateDiscountedPrice}
                    />
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="vip" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {vipItems.map((item: ShopItem) => (
                    <ShopItemCard 
                      key={item.id} 
                      item={item} 
                      onPurchase={purchaseItem} 
                      isPurchasing={purchasing[item.id] || false}
                      getItemIcon={getItemIcon}
                      userCoins={selectedUserData?.coins || 0}
                      appliedCoupon={appliedCoupon}
                      calculateDiscountedPrice={calculateDiscountedPrice}
                    />
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="colors" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {colorItems.map((item: ShopItem) => (
                    <ShopItemCard 
                      key={item.id} 
                      item={item} 
                      onPurchase={purchaseItem} 
                      isPurchasing={purchasing[item.id] || false}
                      getItemIcon={getItemIcon}
                      userCoins={selectedUserData?.coins || 0}
                      appliedCoupon={appliedCoupon}
                      calculateDiscountedPrice={calculateDiscountedPrice}
                    />
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="quotes" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {quoteItems.map((item: ShopItem) => (
                    <ShopItemCard 
                      key={item.id} 
                      item={item} 
                      onPurchase={purchaseItem} 
                      isPurchasing={purchasing[item.id] || false}
                      getItemIcon={getItemIcon}
                      userCoins={selectedUserData?.coins || 0}
                      appliedCoupon={appliedCoupon}
                      calculateDiscountedPrice={calculateDiscountedPrice}
                    />
                  ))}
                </div>
              </TabsContent>
              
              {otherItems.length > 0 && (
                <TabsContent value="other" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {otherItems.map((item: ShopItem) => (
                      <ShopItemCard 
                        key={item.id} 
                        item={item} 
                        onPurchase={purchaseItem} 
                        isPurchasing={purchasing[item.id] || false}
                        getItemIcon={getItemIcon}
                        userCoins={selectedUserData?.coins || 0}
                        appliedCoupon={appliedCoupon}
                        calculateDiscountedPrice={calculateDiscountedPrice}
                      />
                    ))}
                  </div>
                </TabsContent>
              )}
            </Tabs>
          </div>
        </div>
      )}
    </div>
  );
}

interface ShopItemCardProps {
  item: ShopItem;
  onPurchase: (itemId: number) => void;
  isPurchasing: boolean;
  getItemIcon: (type: string) => React.ReactNode;
  userCoins: number;
  appliedCoupon?: Coupon | null;
  calculateDiscountedPrice?: (price: number) => number;
}

function ShopItemCard({ 
  item, 
  onPurchase, 
  isPurchasing, 
  getItemIcon, 
  userCoins,
  appliedCoupon,
  calculateDiscountedPrice 
}: ShopItemCardProps) {
  const originalPrice = item.price;
  const discountedPrice = calculateDiscountedPrice ? calculateDiscountedPrice(item.price) : item.price;
  const hasDiscount = discountedPrice < originalPrice;
  const canAfford = userCoins >= discountedPrice;
  
  // تحديد لون الخلفية حسب النوع والندرة
  const getHeaderBackground = () => {
    if (item.rarity === "LEGENDARY") {
      return "bg-gradient-to-r from-orange-500 to-yellow-300";
    } else if (item.rarity === "EPIC") {
      return "bg-gradient-to-r from-purple-700 to-pink-500";
    } else if (item.rarity === "RARE") {
      return "bg-gradient-to-r from-blue-700 to-indigo-500";
    } else {
      switch (item.type) {
        case "VIP":
          return "bg-gradient-to-r from-amber-600 to-yellow-400";
        case "COLOR":
          return "bg-gradient-to-r from-purple-600 to-indigo-500";
        case "QUOTE":
          return "bg-gradient-to-r from-blue-600 to-cyan-500";
        case "MYSTERY_BOX":
          return "bg-gradient-to-r from-amber-700 to-yellow-600";
        case "WEAPON":
          return "bg-gradient-to-r from-red-700 to-orange-500";
        case "ARMOR":
          return "bg-gradient-to-r from-blue-700 to-teal-500";
        case "BACKGROUND":
          return "bg-gradient-to-r from-purple-700 to-pink-500";
        default:
          return "bg-gradient-to-r from-gray-700 to-gray-600";
      }
    }
  };
  
  return (
    <Card className={`overflow-hidden transition-all ${item.limited ? 'border-amber-500/50' : ''}`}>
      <CardHeader className={getHeaderBackground()}>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="flex items-center text-white">
              {getItemIcon(item.type)}
              <span className="mr-2">{item.name}</span>
            </CardTitle>
            <CardDescription className="text-white/80 mt-1">
              {item.description}
            </CardDescription>
          </div>
          
          <div className="flex flex-col items-end">
            {hasDiscount ? (
              <>
                <Badge variant="outline" className="border-white/20 text-white line-through mb-1 opacity-70">
                  {originalPrice} <Coins className="h-3 w-3 ml-1 inline" />
                </Badge>
                <Badge className="bg-green-600 text-white">
                  {discountedPrice} <Coins className="h-3.5 w-3.5 ml-1 inline" />
                </Badge>
              </>
            ) : (
              <Badge variant="outline" className="border-white/20 text-white">
                {originalPrice} <Coins className="h-3.5 w-3.5 ml-1 inline" />
              </Badge>
            )}
          </div>
        </div>
        
        {/* شارات العناصر المميزة */}
        <div className="flex gap-1 mt-2">
          {item.limited && (
            <Badge variant="secondary" className="bg-amber-600/90 text-white text-xs hover:bg-amber-700">
              <Clock className="h-3 w-3 mr-1" /> محدود
            </Badge>
          )}
          
          {item.rarity && (
            <Badge 
              variant="secondary" 
              className={`
                text-white text-xs
                ${item.rarity === "LEGENDARY" ? "bg-yellow-600/90 hover:bg-yellow-700" : ""}
                ${item.rarity === "EPIC" ? "bg-purple-600/90 hover:bg-purple-700" : ""}
                ${item.rarity === "RARE" ? "bg-blue-600/90 hover:bg-blue-700" : ""}
                ${item.rarity === "UNCOMMON" ? "bg-green-600/90 hover:bg-green-700" : ""}
                ${item.rarity === "COMMON" ? "bg-gray-600/90 hover:bg-gray-700" : ""}
              `}
            >
              <Sparkles className="h-3 w-3 mr-1" />
              {item.rarity === "LEGENDARY" ? "أسطوري" : ""}
              {item.rarity === "EPIC" ? "نادر جداً" : ""}
              {item.rarity === "RARE" ? "نادر" : ""}
              {item.rarity === "UNCOMMON" ? "غير شائع" : ""}
              {item.rarity === "COMMON" ? "شائع" : ""}
            </Badge>
          )}
          
          {item.discount && item.discount > 0 && (
            <Badge variant="secondary" className="bg-green-600/90 text-white text-xs hover:bg-green-700">
              خصم {item.discount}%
            </Badge>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="pt-4">
        <div className="flex flex-col gap-2">
          {item.duration && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" />
              <span>المدة: {item.duration} يوم</span>
            </div>
          )}
          
          {item.stock !== undefined && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Package className="h-4 w-4" />
              <span>المخزون المتبقي: {item.stock}</span>
            </div>
          )}
          
          {item.createdAt && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>تاريخ الإضافة: {new Date(item.createdAt).toLocaleDateString()}</span>
            </div>
          )}
        </div>
      </CardContent>
      
      <CardFooter>
        <Button 
          className={`w-full ${hasDiscount ? 'bg-green-600 hover:bg-green-700' : ''}`}
          onClick={() => onPurchase(item.id)}
          disabled={isPurchasing || !canAfford || (item.stock !== undefined && item.stock <= 0) || !item.available}
          variant={canAfford ? "default" : "outline"}
        >
          {isPurchasing ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <ShoppingCart className="h-4 w-4 mr-2" />
          )}
          
          {!item.available ? (
            "غير متاح حالياً"
          ) : item.stock !== undefined && item.stock <= 0 ? (
            "نفذت الكمية"
          ) : canAfford ? (
            "شراء العنصر"
          ) : (
            "العملات غير كافية"
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}
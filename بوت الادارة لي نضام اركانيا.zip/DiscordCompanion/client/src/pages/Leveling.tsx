import { useState, useEffect, useRef } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { levelingSystem } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import { 
  Loader2, Trophy, Star, ChevronUp, ChevronDown, Crown, Play, Pause, 
  Sparkles, Clock, RefreshCw, User, Users, Palette, Settings, Edit, 
  Undo, RotateCcw, Award, AlertTriangle, ArrowUpDown
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";

interface User {
  userId: string;
  xp: number;
  level: number;
  rank: string;
  coins?: number;
  color?: string;
  is_vip?: boolean;
  vip_expiry?: string;
  joined_at?: string;
}

// عجلة الألوان
function ColorWheel({ selectedColor, onColorChange }: { selectedColor: string, onColorChange: (color: string) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [hsv, setHsv] = useState({ h: 0, s: 1, v: 1 });

  // تحويل لون hex إلى hsv
  useEffect(() => {
    function hexToHsv(hex: string) {
      // تحويل hex إلى rgb
      const r = parseInt(hex.slice(1, 3), 16) / 255;
      const g = parseInt(hex.slice(3, 5), 16) / 255;
      const b = parseInt(hex.slice(5, 7), 16) / 255;
      
      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      const d = max - min;
      
      let h = 0;
      if (d === 0) h = 0;
      else if (max === r) h = ((g - b) / d) % 6;
      else if (max === g) h = (b - r) / d + 2;
      else if (max === b) h = (r - g) / d + 4;
      
      h = h * 60;
      if (h < 0) h += 360;
      
      const s = max === 0 ? 0 : d / max;
      const v = max;
      
      return { h, s, v };
    }
    
    setHsv(hexToHsv(selectedColor));
  }, [selectedColor]);

  // رسم عجلة الألوان
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 5;
    
    // رسم عجلة الألوان
    for (let angle = 0; angle < 360; angle++) {
      const startAngle = (angle - 1) * Math.PI / 180;
      const endAngle = (angle + 1) * Math.PI / 180;
      
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      ctx.closePath();
      
      // تحويل hsv إلى rgb للرسم
      const rgbColor = hsvToRgb(angle, 1, 1);
      ctx.fillStyle = `rgb(${rgbColor.r}, ${rgbColor.g}, ${rgbColor.b})`;
      ctx.fill();
    }
    
    // رسم دائرة بيضاء في المنتصف
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * 0.7, 0, Math.PI * 2);
    ctx.closePath();
    ctx.fillStyle = '#fff';
    ctx.fill();
    
    // رسم دائرة اللون الداخلية (مدرج التشبع والقيمة)
    for (let s = 0; s < 1; s += 0.01) {
      for (let v = 0; v < 1; v += 0.01) {
        const x = centerX + s * Math.cos(hsv.h * Math.PI / 180) * radius * 0.7;
        const y = centerY + s * Math.sin(hsv.h * Math.PI / 180) * radius * 0.7;
        
        ctx.beginPath();
        ctx.arc(x, y, 2, 0, Math.PI * 2);
        ctx.closePath();
        
        const rgbColor = hsvToRgb(hsv.h, s, v);
        ctx.fillStyle = `rgb(${rgbColor.r}, ${rgbColor.g}, ${rgbColor.b})`;
        ctx.fill();
      }
    }
    
    // رسم مؤشر اللون المحدد
    const s = hsv.s;
    const x = centerX + s * Math.cos(hsv.h * Math.PI / 180) * radius * 0.7;
    const y = centerY + s * Math.sin(hsv.h * Math.PI / 180) * radius * 0.7;
    
    ctx.beginPath();
    ctx.arc(x, y, 5, 0, Math.PI * 2);
    ctx.closePath();
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 2;
    ctx.stroke();
    
  }, [hsv]);

  // تحويل hsv إلى rgb
  function hsvToRgb(h: number, s: number, v: number) {
    const c = v * s;
    const x = c * (1 - Math.abs((h / 60) % 2 - 1));
    const m = v - c;
    
    let r = 0, g = 0, b = 0;
    
    if (h < 60) { r = c; g = x; b = 0; }
    else if (h < 120) { r = x; g = c; b = 0; }
    else if (h < 180) { r = 0; g = c; b = x; }
    else if (h < 240) { r = 0; g = x; b = c; }
    else if (h < 300) { r = x; g = 0; b = c; }
    else { r = c; g = 0; b = x; }
    
    return {
      r: Math.round((r + m) * 255),
      g: Math.round((g + m) * 255),
      b: Math.round((b + m) * 255)
    };
  }

  // تحويل hsv إلى hex
  function hsvToHex(h: number, s: number, v: number) {
    const rgb = hsvToRgb(h, s, v);
    return `#${rgb.r.toString(16).padStart(2, '0')}${rgb.g.toString(16).padStart(2, '0')}${rgb.b.toString(16).padStart(2, '0')}`;
  }

  // معالجة النقر والسحب على العجلة
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    handleMouseMove(e);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging && e.type !== 'mousedown') return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    
    // حساب المسافة من المركز
    const dx = x - centerX;
    const dy = y - centerY;
    
    // حساب زاوية اللون (hue)
    let angle = Math.atan2(dy, dx) * 180 / Math.PI;
    if (angle < 0) angle += 360;
    
    // حساب التشبع (محدود بين 0 و 1)
    const distance = Math.sqrt(dx * dx + dy * dy);
    const maxRadius = Math.min(centerX, centerY) - 5;
    const saturation = Math.min(1, distance / (maxRadius * 0.7));
    
    // تحديث قيم hsv
    const newHsv = { h: angle, s: saturation, v: hsv.v };
    setHsv(newHsv);
    
    // تحويل إلى hex وإرسال التغيير
    const hexColor = hsvToHex(newHsv.h, newHsv.s, newHsv.v);
    onColorChange(hexColor);
  };

  return (
    <div className="flex flex-col items-center space-y-2">
      <canvas
        ref={canvasRef}
        width={200}
        height={200}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="cursor-pointer"
      />
      <div className="flex items-center space-x-2">
        <div
          className="w-6 h-6 rounded-full border border-gray-300"
          style={{ backgroundColor: selectedColor }}
        />
        <span className="font-mono text-sm">{selectedColor.toUpperCase()}</span>
      </div>
    </div>
  );
}

export default function Leveling() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [botStatus, setBotStatus] = useState<'starting' | 'stopping' | 'running' | 'stopped'>('stopped');
  const [xpToAdd, setXpToAdd] = useState<Record<string, string>>({});
  const [levelToSet, setLevelToSet] = useState<Record<string, string>>({});
  const [coinsToAdd, setCoinsToAdd] = useState<Record<string, string>>({});
  const [processingAction, setProcessingAction] = useState<Record<string, boolean>>({});
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState("#3498db");
  const [showColorDialog, setShowColorDialog] = useState(false);
  const [customRanks, setCustomRanks] = useState<Record<number, string>>({});
  const [isAutoRewardActive, setIsAutoRewardActive] = useState(true);
  const [activeTab, setActiveTab] = useState("users");
  const { toast } = useToast();

  // تعريف الرتب الافتراضية
  const defaultRanks = {
    0: "🎯 مبتدئ",
    10: "🌱 مقاتل",
    20: "🔥 محارب",
    30: "⚡ متمرس",
    40: "🏹 قناص",
    50: "🛡️ حامي",
    60: "🗡️ محارب ماهر", 
    70: "⚔️ محارب متقدم",
    80: "💫 محارب عظيم",
    90: "🌟 أسطورة",
    100: "👑 خالد",
    150: "👿 الخالد الشيطاني"
  };

  // ألوان متدرجة للمستويات
  const levelGradients = {
    0: "linear-gradient(135deg, #3498db, #2980b9)",
    10: "linear-gradient(135deg, #95a5a6, #7f8c8d)",
    20: "linear-gradient(135deg, #006400, #2e8b57)",
    30: "linear-gradient(135deg, #000080, #0000CD)",
    40: "linear-gradient(135deg, #b8860b, #daa520)",
    50: "linear-gradient(135deg, #8b0000, #ff0000)",
    60: "linear-gradient(135deg, #008080, #20b2aa)",
    70: "linear-gradient(135deg, #228b22, #32cd32)",
    80: "linear-gradient(135deg, #1e90ff, #00bfff)",
    90: "linear-gradient(135deg, #ff8c00, #ffa500)",
    100: "linear-gradient(135deg, #ffd700, #ffff00)",
    150: "linear-gradient(135deg, #800080, #9400d3)"
  };

  // Load users
  const fetchUsers = async () => {
    try {
      setLoading(true);
      const data = await levelingSystem.getUsers();
      setUsers(data);
    } catch (error) {
      console.error("Error fetching users:", error);
      toast({
        title: "خطأ",
        description: "فشل في جلب بيانات المستخدمين",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
    
    // تحقق من حالة البوت عند التحميل
    const checkBotStatus = async () => {
      try {
        const status = await fetch('/api/bot/status').then(res => res.json());
        setBotStatus(status.status === 'online' ? 'running' : 'stopped');
      } catch (error) {
        console.error("Error checking bot status:", error);
        setBotStatus('stopped');
      }
    };
    
    checkBotStatus();
    
    // جدول زمني لتحديث تلقائي
    const interval = setInterval(() => {
      fetchUsers();
    }, 30000); // تحديث كل 30 ثانية
    
    return () => clearInterval(interval);
  }, []);

  // Start leveling bot
  const startBot = async () => {
    try {
      setBotStatus('starting');
      await levelingSystem.startBot();
      setBotStatus('running');
      toast({
        title: "تم التشغيل",
        description: "تم تشغيل نظام المستويات بنجاح",
      });
    } catch (error) {
      console.error("Error starting bot:", error);
      setBotStatus('stopped');
      toast({
        title: "خطأ",
        description: "فشل في تشغيل نظام المستويات",
        variant: "destructive",
      });
    }
  };

  // Stop leveling bot
  const stopBot = async () => {
    try {
      setBotStatus('stopping');
      await levelingSystem.stopBot();
      setBotStatus('stopped');
      toast({
        title: "تم الإيقاف",
        description: "تم إيقاف نظام المستويات بنجاح",
      });
    } catch (error) {
      console.error("Error stopping bot:", error);
      setBotStatus('running');
      toast({
        title: "خطأ",
        description: "فشل في إيقاف نظام المستويات",
        variant: "destructive",
      });
    }
  };

  // تحديث XP للمستخدم
  const updateXP = async (userId: string, amount: number) => {
    try {
      setProcessingAction({ ...processingAction, [userId]: true });
      
      if (isNaN(amount)) {
        toast({
          title: "خطأ",
          description: "الرجاء إدخال رقم صحيح",
          variant: "destructive",
        });
        return;
      }

      const user = users.find(u => u.userId === userId);
      if (!user) return;
      
      const newXP = user.xp + amount;
      const oldLevel = user.level;
      const newLevel = calculateLevel(newXP);
      
      await levelingSystem.updateUser(userId, { xp: newXP });
      
      // تحديث حالة المستخدم محليًا
      setUsers(users.map(u => 
        u.userId === userId 
        ? { ...u, xp: newXP, level: newLevel } 
        : u
      ));
      
      setXpToAdd({ ...xpToAdd, [userId]: '' });
      
      // منح عملات تلقائيًا إذا كان التفعيل التلقائي مفعلاً
      if (isAutoRewardActive && newLevel > oldLevel) {
        // 50 عملة لكل ترقية مستوى + 1 عملة لكل 10 XP
        const coinsToAward = 50 + Math.floor(amount / 10);
        const newCoins = (user.coins || 0) + coinsToAward;
        
        await levelingSystem.updateUser(userId, { coins: newCoins });
        
        // تحديث حالة العملات محليًا
        setUsers(users.map(u => 
          u.userId === userId 
          ? { ...u, coins: newCoins } 
          : u
        ));
        
        toast({
          title: "ترقية المستوى!",
          description: `تم ترقية المستخدم للمستوى ${newLevel} ومنحه ${coinsToAward} عملة`,
        });
      } else {
        toast({
          title: "تم التحديث",
          description: `تم تعديل XP للمستخدم بمقدار ${amount}`,
        });
      }
    } catch (error) {
      console.error("Error updating user:", error);
      toast({
        title: "خطأ",
        description: "فشل في تحديث بيانات المستخدم",
        variant: "destructive",
      });
    } finally {
      setProcessingAction({ ...processingAction, [userId]: false });
    }
  };

  // تعيين مستوى محدد للمستخدم
  const setUserLevel = async (userId: string) => {
    try {
      setProcessingAction({ ...processingAction, [userId]: true });
      const level = parseInt(levelToSet[userId] || '1');
      
      if (isNaN(level) || level < 1) {
        toast({
          title: "خطأ",
          description: "الرجاء إدخال رقم صحيح أكبر من 0",
          variant: "destructive",
        });
        return;
      }

      // حساب الـ XP اللازم للمستوى المطلوب
      const xpRequired = (level - 1) * 1000;
      
      await levelingSystem.updateUser(userId, { xp: xpRequired, level: level });
      
      // تحديث حالة المستخدم محليًا
      setUsers(users.map(u => 
        u.userId === userId 
        ? { ...u, xp: xpRequired, level: level } 
        : u
      ));
      
      setLevelToSet({ ...levelToSet, [userId]: '' });
      
      toast({
        title: "تم التحديث",
        description: `تم تعيين المستوى ${level} للمستخدم`,
      });
    } catch (error) {
      console.error("Error setting user level:", error);
      toast({
        title: "خطأ",
        description: "فشل في تحديث مستوى المستخدم",
        variant: "destructive",
      });
    } finally {
      setProcessingAction({ ...processingAction, [userId]: false });
    }
  };

  // إعادة تعيين مستوى المستخدم إلى المستوى 1
  const resetUserLevel = async (userId: string) => {
    try {
      setProcessingAction({ ...processingAction, [userId]: true });
      
      await levelingSystem.updateUser(userId, { xp: 0, level: 1 });
      
      // تحديث حالة المستخدم محليًا
      setUsers(users.map(u => 
        u.userId === userId 
        ? { ...u, xp: 0, level: 1 } 
        : u
      ));
      
      toast({
        title: "تم إعادة التعيين",
        description: "تم إعادة تعيين المستخدم إلى المستوى 1",
      });
    } catch (error) {
      console.error("Error resetting user:", error);
      toast({
        title: "خطأ",
        description: "فشل في إعادة تعيين مستوى المستخدم",
        variant: "destructive",
      });
    } finally {
      setProcessingAction({ ...processingAction, [userId]: false });
    }
  };

  // تحديث عملات المستخدم
  const updateCoins = async (userId: string, amount: number) => {
    try {
      setProcessingAction({ ...processingAction, [userId]: true });
      
      if (isNaN(amount)) {
        toast({
          title: "خطأ",
          description: "الرجاء إدخال رقم صحيح",
          variant: "destructive",
        });
        return;
      }

      const user = users.find(u => u.userId === userId);
      if (!user) return;
      
      const currentCoins = user.coins || 0;
      const newCoins = currentCoins + amount;
      
      if (newCoins < 0) {
        toast({
          title: "خطأ",
          description: "لا يمكن أن يكون رصيد العملات سالبًا",
          variant: "destructive",
        });
        return;
      }
      
      await levelingSystem.updateUser(userId, { coins: newCoins });
      
      // تحديث حالة المستخدم محليًا
      setUsers(users.map(u => 
        u.userId === userId 
        ? { ...u, coins: newCoins } 
        : u
      ));
      
      setCoinsToAdd({ ...coinsToAdd, [userId]: '' });
      
      toast({
        title: "تم التحديث",
        description: `تم تعديل عملات المستخدم بمقدار ${amount}`,
      });
    } catch (error) {
      console.error("Error updating user coins:", error);
      toast({
        title: "خطأ",
        description: "فشل في تحديث عملات المستخدم",
        variant: "destructive",
      });
    } finally {
      setProcessingAction({ ...processingAction, [userId]: false });
    }
  };

  // تغيير لون المستخدم
  const updateUserColor = async (userId: string, color: string) => {
    try {
      setProcessingAction({ ...processingAction, [userId]: true });
      
      await levelingSystem.updateUser(userId, { color });
      
      // تحديث حالة المستخدم محليًا
      setUsers(users.map(u => 
        u.userId === userId 
        ? { ...u, color } 
        : u
      ));
      
      toast({
        title: "تم التحديث",
        description: `تم تغيير لون المستخدم إلى ${color}`,
      });
      
      setShowColorDialog(false);
    } catch (error) {
      console.error("Error updating user color:", error);
      toast({
        title: "خطأ",
        description: "فشل في تحديث لون المستخدم",
        variant: "destructive",
      });
    } finally {
      setProcessingAction({ ...processingAction, [userId]: false });
    }
  };

  // Calculate level based on XP
  const calculateLevel = (xp: number): number => {
    return Math.max(1, Math.floor(xp / 1000) + 1);
  };

  // Get rank display
  const getRank = (level: number): string => {
    // البحث عن أقرب مستوى في الرتب المخصصة أو الافتراضية
    const rankLevels = Object.keys(customRanks).length > 0 
      ? Object.keys(customRanks).map(Number)
      : Object.keys(defaultRanks).map(Number);
    
    // ترتيب المستويات تنازليًا
    rankLevels.sort((a, b) => b - a);
    
    // البحث عن أقرب مستوى أقل من أو يساوي مستوى المستخدم
    for (const rankLevel of rankLevels) {
      if (level >= rankLevel) {
        return Object.keys(customRanks).length > 0 
          ? customRanks[rankLevel]
          : defaultRanks[rankLevel as keyof typeof defaultRanks];
      }
    }
    
    return "🎯 مبتدئ";
  };

  // Get rank color
  const getRankColor = (level: number): string => {
    // رتب المستويات تنازليًا
    const rankLevels = Object.keys(levelGradients).map(Number).sort((a, b) => b - a);
    
    // ابحث عن أقرب مستوى أقل من أو يساوي مستوى المستخدم
    for (const rankLevel of rankLevels) {
      if (level >= rankLevel) {
        return rankLevel.toString() as keyof typeof levelGradients;
      }
    }
    
    return "0";
  };

  // Generate XP bar
  const generateXPBar = (xp: number, level: number, color?: string) => {
    const currentLevelXP = (level - 1) * 1000;
    const nextLevelXP = level * 1000;
    const xpProgress = xp - currentLevelXP;
    const xpNeeded = nextLevelXP - currentLevelXP;
    const progress = Math.min(1.0, Math.max(0.0, xpProgress / xpNeeded));
    const percentage = Math.min(100, Math.max(0, Math.floor(progress * 100)));
    
    return (
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3 mb-1">
        <div 
          className="h-3 rounded-full transition-all duration-500"
          style={{ 
            width: `${percentage}%`,
            background: color || levelGradients[getRankColor(level) as keyof typeof levelGradients] || "linear-gradient(135deg, #3498db, #2980b9)"
          }}
        ></div>
      </div>
    );
  };

  // Format date
  const formatDate = (dateStr?: string) => {
    if (!dateStr) return "غير متوفر";
    
    const date = new Date(dateStr);
    return new Intl.DateTimeFormat('ar', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <div className="space-y-4 p-4 pb-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">نظام المستويات والعملات</h1>
        <div className="flex gap-2">
          {botStatus === 'running' || botStatus === 'stopping' ? (
            <Button 
              variant="destructive"
              size="sm" 
              disabled={botStatus === 'stopping'}
              onClick={stopBot}
            >
              {botStatus === 'stopping' ? <Loader2 className="h-4 w-4 ml-2 animate-spin" /> : <Pause className="h-4 w-4 ml-2" />}
              إيقاف النظام
            </Button>
          ) : (
            <Button 
              variant="default"
              size="sm" 
              disabled={botStatus === 'starting'}
              onClick={startBot}
            >
              {botStatus === 'starting' ? <Loader2 className="h-4 w-4 ml-2 animate-spin" /> : <Play className="h-4 w-4 ml-2" />}
              تشغيل النظام
            </Button>
          )}
          <Button 
            variant="outline"
            size="sm" 
            onClick={fetchUsers}
            disabled={loading}
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4 ml-2" />}
            تحديث
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="users" className="flex items-center">
            <Users className="h-4 w-4 ml-2" />
            المستخدمين
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center">
            <Settings className="h-4 w-4 ml-2" />
            الإعدادات
          </TabsTrigger>
          <TabsTrigger value="profiles" className="flex items-center">
            <User className="h-4 w-4 ml-2" />
            الملفات الشخصية
          </TabsTrigger>
        </TabsList>
        
        {/* تبويب المستخدمين */}
        <TabsContent value="users" className="space-y-4">
          <Card className="w-full">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Trophy className="ml-2 h-5 w-5 text-amber-500" />
                قائمة المستويات
              </CardTitle>
              <CardDescription>
                إدارة المستويات ونقاط الخبرة والعملات للمستخدمين
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center items-center p-8">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : users.length === 0 ? (
                <div className="text-center p-8 text-muted-foreground">
                  لا توجد بيانات متاحة. قم بتفعيل النظام وانتظر أول مستخدم.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-right">المستخدم</TableHead>
                        <TableHead className="text-right">المستوى</TableHead>
                        <TableHead className="text-right">نقاط XP</TableHead>
                        <TableHead className="text-right">العملات</TableHead>
                        <TableHead className="text-right">الرتبة</TableHead>
                        <TableHead className="text-right">التقدم</TableHead>
                        <TableHead className="text-right">الإجراءات</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.sort((a, b) => b.xp - a.xp).map((user) => (
                        <TableRow key={user.userId}>
                          <TableCell className="font-medium">
                            <div className="flex items-center space-x-2">
                              <div 
                                className="w-3 h-3 rounded-full" 
                                style={{ backgroundColor: user.color || '#3498db' }}
                              ></div>
                              <span dir="ltr">{user.userId}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <Crown className="ml-1 h-4 w-4 text-amber-500" />
                              {user.level}
                            </div>
                          </TableCell>
                          <TableCell>{user.xp.toLocaleString()}</TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <Star className="ml-1 h-4 w-4 text-yellow-500" />
                              {(user.coins || 0).toLocaleString()}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge 
                              className="inline-flex items-center px-2.5 py-0.5 text-xs font-medium rounded-full"
                              style={{ 
                                background: levelGradients[getRankColor(user.level) as keyof typeof levelGradients]
                              }}
                            >
                              {getRank(user.level)}
                            </Badge>
                          </TableCell>
                          <TableCell className="w-40">
                            {generateXPBar(user.xp, user.level, user.color)}
                            <span className="text-xs text-muted-foreground" dir="ltr">
                              {user.xp % 1000} / 1000 XP
                            </span>
                          </TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="outline" size="sm">
                                  الخيارات
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="start">
                                <Dialog>
                                  <DialogTrigger asChild>
                                    <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                      <Edit className="ml-2 h-4 w-4" />
                                      <span>تعديل نقاط XP</span>
                                    </DropdownMenuItem>
                                  </DialogTrigger>
                                  <DialogContent>
                                    <DialogHeader>
                                      <DialogTitle>تعديل نقاط XP</DialogTitle>
                                      <DialogDescription>
                                        أدخل القيمة التي تريد إضافتها أو خصمها (قيمة سالبة)
                                      </DialogDescription>
                                    </DialogHeader>
                                    <div className="flex items-center gap-4">
                                      <Input
                                        type="number"
                                        dir="ltr"
                                        value={xpToAdd[user.userId] || ''}
                                        onChange={(e) => setXpToAdd({...xpToAdd, [user.userId]: e.target.value})}
                                        placeholder="مثال: 500 أو -100"
                                      />
                                    </div>
                                    <DialogFooter>
                                      <Button 
                                        variant="default"
                                        onClick={() => updateXP(user.userId, parseInt(xpToAdd[user.userId] || '0'))}
                                        disabled={processingAction[user.userId]}
                                      >
                                        {processingAction[user.userId] ? 
                                          <Loader2 className="h-4 w-4 ml-2 animate-spin" /> : 
                                          <ChevronUp className="h-4 w-4 ml-2" />}
                                        تحديث XP
                                      </Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>

                                <Dialog>
                                  <DialogTrigger asChild>
                                    <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                      <Star className="ml-2 h-4 w-4" />
                                      <span>تعديل العملات</span>
                                    </DropdownMenuItem>
                                  </DialogTrigger>
                                  <DialogContent>
                                    <DialogHeader>
                                      <DialogTitle>تعديل عملات المستخدم</DialogTitle>
                                      <DialogDescription>
                                        أدخل القيمة التي تريد إضافتها أو خصمها (قيمة سالبة)
                                      </DialogDescription>
                                    </DialogHeader>
                                    <div className="flex items-center gap-4">
                                      <Input
                                        type="number"
                                        dir="ltr"
                                        value={coinsToAdd[user.userId] || ''}
                                        onChange={(e) => setCoinsToAdd({...coinsToAdd, [user.userId]: e.target.value})}
                                        placeholder="مثال: 100 أو -50"
                                      />
                                    </div>
                                    <DialogFooter>
                                      <Button 
                                        variant="default"
                                        onClick={() => updateCoins(user.userId, parseInt(coinsToAdd[user.userId] || '0'))}
                                        disabled={processingAction[user.userId]}
                                      >
                                        {processingAction[user.userId] ? 
                                          <Loader2 className="h-4 w-4 ml-2 animate-spin" /> : 
                                          <Star className="h-4 w-4 ml-2" />}
                                        تحديث العملات
                                      </Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>

                                <Dialog>
                                  <DialogTrigger asChild>
                                    <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                      <Crown className="ml-2 h-4 w-4" />
                                      <span>تعيين المستوى</span>
                                    </DropdownMenuItem>
                                  </DialogTrigger>
                                  <DialogContent>
                                    <DialogHeader>
                                      <DialogTitle>تعيين مستوى محدد</DialogTitle>
                                      <DialogDescription>
                                        أدخل المستوى الذي تريد تعيينه للمستخدم
                                      </DialogDescription>
                                    </DialogHeader>
                                    <div className="flex items-center gap-4">
                                      <Input
                                        type="number"
                                        dir="ltr"
                                        value={levelToSet[user.userId] || ''}
                                        onChange={(e) => setLevelToSet({...levelToSet, [user.userId]: e.target.value})}
                                        placeholder="أدخل المستوى"
                                        min="1"
                                      />
                                    </div>
                                    <DialogFooter>
                                      <Button 
                                        variant="default"
                                        onClick={() => setUserLevel(user.userId)}
                                        disabled={processingAction[user.userId]}
                                      >
                                        {processingAction[user.userId] ? 
                                          <Loader2 className="h-4 w-4 ml-2 animate-spin" /> : 
                                          <Crown className="h-4 w-4 ml-2" />}
                                        تعيين المستوى
                                      </Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>

                                <Dialog>
                                  <DialogTrigger asChild>
                                    <DropdownMenuItem onSelect={(e) => {
                                      e.preventDefault();
                                      setSelectedUserId(user.userId);
                                      setSelectedColor(user.color || "#3498db");
                                    }}>
                                      <Palette className="ml-2 h-4 w-4" />
                                      <span>تعديل اللون</span>
                                    </DropdownMenuItem>
                                  </DialogTrigger>
                                  <DialogContent>
                                    <DialogHeader>
                                      <DialogTitle>اختيار لون الملف الشخصي</DialogTitle>
                                      <DialogDescription>
                                        استخدم عجلة الألوان أو أدخل الكود اللوني
                                      </DialogDescription>
                                    </DialogHeader>
                                    <div className="flex flex-col items-center">
                                      <ColorWheel 
                                        selectedColor={selectedColor} 
                                        onColorChange={setSelectedColor} 
                                      />
                                      <div className="flex items-center mt-4 gap-2 w-full">
                                        <Label htmlFor="colorCode">كود اللون:</Label>
                                        <Input
                                          id="colorCode"
                                          dir="ltr"
                                          value={selectedColor}
                                          onChange={(e) => setSelectedColor(e.target.value)}
                                          placeholder="#rrggbb"
                                        />
                                      </div>
                                    </div>
                                    <DialogFooter>
                                      <Button 
                                        variant="default"
                                        onClick={() => updateUserColor(user.userId, selectedColor)}
                                        disabled={processingAction[user.userId]}
                                      >
                                        {processingAction[user.userId] ? 
                                          <Loader2 className="h-4 w-4 ml-2 animate-spin" /> : 
                                          <Palette className="h-4 w-4 ml-2" />}
                                        تطبيق اللون
                                      </Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>

                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <DropdownMenuItem 
                                      className="text-red-500"
                                      onSelect={(e) => e.preventDefault()}
                                    >
                                      <RotateCcw className="ml-2 h-4 w-4" />
                                      <span>إعادة للمستوى 1</span>
                                    </DropdownMenuItem>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>تأكيد إعادة التعيين</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        هل أنت متأكد من رغبتك في إعادة تعيين هذا المستخدم للمستوى 1؟ سيتم مسح جميع نقاط XP.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>إلغاء</AlertDialogCancel>
                                      <AlertDialogAction 
                                        className="bg-red-500 hover:bg-red-600"
                                        onClick={() => resetUserLevel(user.userId)}
                                      >
                                        تأكيد إعادة التعيين
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex flex-col items-start space-y-2">
              <p className="text-sm text-muted-foreground">
                يتم حساب المستوى تلقائيًا بناءً على XP. كل مستوى يتطلب 1000 XP إضافية.
              </p>
              <div className="flex items-center space-x-2">
                <Switch 
                  id="auto-reward"
                  checked={isAutoRewardActive}
                  onCheckedChange={setIsAutoRewardActive}
                />
                <Label htmlFor="auto-reward">
                  المكافآت التلقائية (50 عملة عند ترقية المستوى + عملة لكل 10 نقاط XP)
                </Label>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* تبويب الإعدادات */}
        <TabsContent value="settings" className="space-y-4">
          <Card className="w-full">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="ml-2 h-5 w-5" />
                إعدادات نظام المستويات
              </CardTitle>
              <CardDescription>
                تخصيص سلوك وخصائص نظام المستويات
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="ranks">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-center">
                      <Award className="ml-2 h-5 w-5 text-amber-500" />
                      <span>الرتب والألقاب</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4">
                      <p className="text-muted-foreground">
                        يمكنك هنا تعديل الرتب والألقاب التي تظهر للمستخدمين حسب مستوياتهم
                      </p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Object.entries(defaultRanks).map(([level, rank]) => (
                          <div key={level} className="flex items-center space-x-2">
                            <Label className="w-24 text-left" htmlFor={`rank-${level}`}>
                              المستوى {level}
                            </Label>
                            <Input
                              id={`rank-${level}`}
                              defaultValue={rank}
                              className="flex-1"
                              onChange={(e) => {
                                const newRanks = { ...customRanks };
                                newRanks[parseInt(level)] = e.target.value;
                                setCustomRanks(newRanks);
                              }}
                            />
                          </div>
                        ))}
                      </div>
                      
                      <div className="flex justify-end space-x-2">
                        <Button
                          variant="outline"
                          onClick={() => setCustomRanks({})}
                        >
                          إعادة للافتراضي
                        </Button>
                        <Button
                          onClick={() => {
                            toast({
                              title: "تم الحفظ",
                              description: "تم حفظ إعدادات الرتب بنجاح",
                            });
                          }}
                        >
                          حفظ الرتب
                        </Button>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="levelSettings">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-center">
                      <ArrowUpDown className="ml-2 h-5 w-5 text-blue-500" />
                      <span>إعدادات ترقية المستويات</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4">
                      <div className="flex flex-col space-y-2">
                        <Label>XP المطلوب لكل مستوى</Label>
                        <div className="flex items-center space-x-2">
                          <Slider
                            defaultValue={[1000]}
                            min={100}
                            max={5000}
                            step={100}
                            disabled
                          />
                          <span className="min-w-[4rem] text-center">1000</span>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          يتطلب كل مستوى 1000 نقطة XP بشكل ثابت
                        </p>
                      </div>
                      
                      <div className="flex items-center space-x-4">
                        <Label htmlFor="auto-level-up" className="flex-1">
                          ترقية المستوى تلقائيًا عند جمع XP الكافي
                        </Label>
                        <Switch id="auto-level-up" defaultChecked disabled />
                      </div>
                      
                      <div className="flex items-center space-x-4">
                        <Label htmlFor="auto-rewards" className="flex-1">
                          المكافآت التلقائية عند ترقية المستوى
                        </Label>
                        <Switch 
                          id="auto-rewards" 
                          checked={isAutoRewardActive} 
                          onCheckedChange={setIsAutoRewardActive} 
                        />
                      </div>
                      
                      <div className="border rounded-md p-4 bg-amber-50 dark:bg-amber-950/20">
                        <div className="flex items-start space-x-2">
                          <AlertTriangle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                          <div>
                            <h4 className="font-semibold">نظام الترقية</h4>
                            <p className="text-sm text-muted-foreground">
                              نظام المستويات يعمل بشكل موحد: كل مستوى يتطلب 1000 XP.
                              المستوى 1: 0-999 XP
                              المستوى 2: 1000-1999 XP
                              المستوى 3: 2000-2999 XP
                              وهكذا بدون حد أقصى للمستويات.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="rewards">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-center">
                      <Star className="ml-2 h-5 w-5 text-yellow-500" />
                      <span>المكافآت والعملات</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label>عملات لكل 10 نقاط XP</Label>
                        <div className="flex items-center space-x-2">
                          <RadioGroup defaultValue="1" className="flex">
                            <div className="flex items-center space-x-1">
                              <RadioGroupItem value="0.5" id="r1" disabled />
                              <Label htmlFor="r1">0.5</Label>
                            </div>
                            <div className="flex items-center space-x-1 mr-4">
                              <RadioGroupItem value="1" id="r2" disabled />
                              <Label htmlFor="r2">1</Label>
                            </div>
                            <div className="flex items-center space-x-1 mr-4">
                              <RadioGroupItem value="2" id="r3" disabled />
                              <Label htmlFor="r3">2</Label>
                            </div>
                          </RadioGroup>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>عملات عند ترقية المستوى</Label>
                        <div className="flex items-center space-x-2">
                          <Input
                            type="number"
                            dir="ltr"
                            className="w-20 text-center"
                            value="50"
                            disabled
                          />
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-4">
                        <Label htmlFor="auto-coins" className="flex-1">
                          تفعيل المكافآت التلقائية
                        </Label>
                        <Switch 
                          id="auto-coins" 
                          checked={isAutoRewardActive} 
                          onCheckedChange={setIsAutoRewardActive} 
                        />
                      </div>
                      
                      <div className="border rounded-md p-4 bg-green-50 dark:bg-green-950/20">
                        <div className="flex items-start space-x-2">
                          <span className="text-xl ml-2">💰</span>
                          <div>
                            <h4 className="font-semibold">نظام المكافآت</h4>
                            <p className="text-sm text-muted-foreground">
                              مع تفعيل المكافآت التلقائية، يحصل المستخدمون على عملة واحدة لكل 10 نقاط XP،
                              بالإضافة إلى 50 عملة إضافية عند ترقية المستوى.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="colors">
                  <AccordionTrigger className="hover:no-underline">
                    <div className="flex items-center">
                      <Palette className="ml-2 h-5 w-5 text-purple-500" />
                      <span>الألوان والمظهر</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4">
                      <p className="text-muted-foreground">
                        تخصيص ألوان المستويات والرتب
                      </p>
                      
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        {Object.entries(levelGradients).map(([level, gradient]) => (
                          <div 
                            key={level} 
                            className="border rounded-md p-2 flex flex-col items-center"
                          >
                            <div 
                              className="w-full h-6 rounded-md mb-1"
                              style={{ background: gradient }}
                            ></div>
                            <span className="text-xs">المستوى {level}+</span>
                          </div>
                        ))}
                      </div>
                      
                      <div className="border rounded-md p-4 bg-purple-50 dark:bg-purple-950/20">
                        <div className="flex items-start space-x-2">
                          <Sparkles className="h-5 w-5 text-purple-500 flex-shrink-0 mt-0.5" />
                          <div>
                            <h4 className="font-semibold">ألوان أسبوعية متجددة</h4>
                            <p className="text-sm text-muted-foreground">
                              يتم تحديث الألوان الأسبوعية تلقائيًا كل يوم سبت، ويمكن للمستخدمين شراؤها من المتجر.
                              استخدم أمر !colors لعرض الألوان المتاحة حاليًا.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
            <CardFooter>
              <p className="text-sm text-muted-foreground">
                بعض الإعدادات قد تتطلب إعادة تشغيل البوت لتصبح فعالة
              </p>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* تبويب الملفات الشخصية */}
        <TabsContent value="profiles" className="space-y-4">
          <Card className="w-full">
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="ml-2 h-5 w-5" />
                الملفات الشخصية
              </CardTitle>
              <CardDescription>
                عرض وتخصيص الملفات الشخصية للمستخدمين
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center items-center p-8">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : users.length === 0 ? (
                <div className="text-center p-8 text-muted-foreground">
                  لا توجد بيانات متاحة للمستخدمين.
                </div>
              ) : (
                <ScrollArea className="h-[450px] w-full pr-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {users.map((user) => (
                      <Card key={user.userId} className="overflow-hidden border-2 transition-all duration-300 hover:shadow-md"
                        style={{ borderColor: user.color || '#3498db' }}>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-lg flex items-center justify-between">
                            <span dir="ltr">{user.userId}</span>
                            <Badge 
                              className="text-xs"
                              style={{ 
                                background: levelGradients[getRankColor(user.level) as keyof typeof levelGradients]
                              }}
                            >
                              {getRank(user.level)}
                            </Badge>
                          </CardTitle>
                          <CardDescription className="flex items-center">
                            {user.is_vip && (
                              <Badge variant="outline" className="ml-2 border-amber-500 text-amber-500">
                                <Crown className="h-3 w-3 ml-1" /> VIP
                              </Badge>
                            )}
                            <Clock className="h-3 w-3 ml-1 mr-1" />
                            <span className="text-xs">انضم: {formatDate(user.joined_at)}</span>
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="pb-2 space-y-3">
                          <div className="flex justify-between items-center">
                            <div className="flex items-center">
                              <Crown className="h-4 w-4 ml-1 text-amber-500" />
                              <span>المستوى: <strong>{user.level}</strong></span>
                            </div>
                            <div className="flex items-center">
                              <Star className="h-4 w-4 ml-1 text-yellow-500" />
                              <span>العملات: <strong>{(user.coins || 0).toLocaleString()}</strong></span>
                            </div>
                          </div>
                          
                          <div>
                            <div className="flex justify-between items-center text-xs mb-1">
                              <span>XP: {user.xp.toLocaleString()}</span>
                              <span>
                                {user.xp % 1000} / 1000
                              </span>
                            </div>
                            {generateXPBar(user.xp, user.level, user.color)}
                          </div>
                          
                          <div className="flex justify-between items-center pt-1">
                            <div className="flex items-center space-x-1">
                              <div 
                                className="w-4 h-4 rounded-full"
                                style={{ backgroundColor: user.color || '#3498db' }}
                              />
                              <span className="text-xs font-mono" dir="ltr">
                                {user.color || '#3498db'}
                              </span>
                            </div>
                            
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-8"
                              onClick={() => {
                                setSelectedUserId(user.userId);
                                setSelectedColor(user.color || "#3498db");
                                setShowColorDialog(true);
                              }}
                            >
                              <Palette className="h-3.5 w-3.5 ml-1" />
                              تغيير اللون
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
            <CardFooter>
              <p className="text-sm text-muted-foreground">
                يمكن للمستخدمين عرض ملفاتهم الشخصية باستخدام أمر !profile
              </p>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* عجلة اختيار الألوان */}
      {selectedUserId && (
        <Dialog open={showColorDialog} onOpenChange={setShowColorDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>اختيار لون الملف الشخصي</DialogTitle>
              <DialogDescription>
                استخدم عجلة الألوان أو أدخل الكود اللوني
              </DialogDescription>
            </DialogHeader>
            <div className="flex flex-col items-center">
              <ColorWheel 
                selectedColor={selectedColor} 
                onColorChange={setSelectedColor} 
              />
              <div className="flex items-center mt-4 gap-2 w-full">
                <Label htmlFor="colorCodeDialog">كود اللون:</Label>
                <Input
                  id="colorCodeDialog"
                  dir="ltr"
                  value={selectedColor}
                  onChange={(e) => setSelectedColor(e.target.value)}
                  placeholder="#rrggbb"
                />
              </div>
            </div>
            <DialogFooter>
              <Button 
                variant="default"
                onClick={() => {
                  if (selectedUserId) {
                    updateUserColor(selectedUserId, selectedColor);
                  }
                }}
                disabled={!selectedUserId || processingAction[selectedUserId]}
              >
                {selectedUserId && processingAction[selectedUserId] ? 
                  <Loader2 className="h-4 w-4 ml-2 animate-spin" /> : 
                  <Palette className="h-4 w-4 ml-2" />}
                تطبيق اللون
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
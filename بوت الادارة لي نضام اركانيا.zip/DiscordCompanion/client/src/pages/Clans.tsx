import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "@/components/ui/avatar";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  Shield,
  Users,
  Crown,
  Star,
  Plus,
  X,
  Edit,
  Trash2,
  Search,
  ArrowUpDown,
  ShieldCheck,
  ShieldOff,
  UserPlus,
  UserMinus,
  RefreshCw,
  Filter,
  Coins
} from "lucide-react";

interface Clan {
  id: number;
  name: string;
  leaderId: string;
  description?: string;
  logoUrl?: string;
  treasury: number;
  level: number;
  experience: number;
  memberCount: number;
  consecutiveWins: number;
  blacklisted: boolean;
  specialChallengesRemaining: number;
  lastSpecialChallengeDate?: string;
  createdAt: string;
}

interface ClanMember {
  id: number;
  clanId: number;
  userId: string;
  role: string;
  contributions: number;
  tasksCompleted: number;
  donationAmount: number;
  joinDate: string;
}

// استخدام Zod لتحقق من صحة نموذج إنشاء العشيرة
const createClanSchema = z.object({
  name: z.string().min(3, { message: "اسم العشيرة يجب أن يكون 3 أحرف على الأقل" }).max(32, { message: "اسم العشيرة لا يجب أن يتجاوز 32 حرف" }),
  leaderId: z.string().min(1, { message: "يجب تحديد معرف قائد العشيرة" }),
  description: z.string().max(500, { message: "الوصف لا يجب أن يتجاوز 500 حرف" }),
  logoUrl: z.string().optional(),
});

export default function Clans() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [selectedClan, setSelectedClan] = useState<Clan | null>(null);
  
  const { data: clans = [], isLoading } = useQuery({
    queryKey: ["/api/clans"],
    queryFn: async () => {
      try {
        const response = await fetch("/api/clans");
        if (!response.ok) throw new Error("فشل في جلب بيانات العشائر");
        const data = await response.json();
        return data;
      } catch (error) {
        console.error("خطأ في جلب بيانات العشائر:", error);
        return [];
      }
    }
  });

  // استعلام عن أعضاء العشائر إذا تم تحديد عشيرة
  const { data: clanMembers = [] } = useQuery({
    queryKey: ["/api/clans/members", selectedClan?.id],
    queryFn: async () => {
      if (!selectedClan) return [];
      
      try {
        const response = await fetch(`/api/clans/${selectedClan.id}/members`);
        if (!response.ok) throw new Error("فشل في جلب بيانات أعضاء العشيرة");
        const data = await response.json();
        return data;
      } catch (error) {
        console.error("خطأ في جلب بيانات أعضاء العشيرة:", error);
        return [];
      }
    },
    enabled: !!selectedClan
  });

  // طلب إضافة عشيرة جديدة
  const createClanMutation = useMutation({
    mutationFn: async (newClan: z.infer<typeof createClanSchema>) => {
      const response = await fetch("/api/clans", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newClan)
      });
      
      if (!response.ok) {
        const error = await response.text();
        throw new Error(error || "فشل في إنشاء العشيرة");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم إنشاء العشيرة بنجاح",
        description: "تم إضافة العشيرة الجديدة إلى قائمة العشائر.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/clans"] });
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "فشل في إنشاء العشيرة",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // طلب تحديث حالة عشيرة
  const updateClanStatusMutation = useMutation({
    mutationFn: async ({ clanId, status }: { clanId: number; status: string }) => {
      const response = await fetch(`/api/clans/${clanId}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status })
      });
      
      if (!response.ok) {
        const error = await response.text();
        throw new Error(error || "فشل في تحديث حالة العشيرة");
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم تحديث حالة العشيرة",
        description: "تم تغيير حالة العشيرة بنجاح.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/clans"] });
    },
    onError: (error: Error) => {
      toast({
        title: "فشل في تحديث حالة العشيرة",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // استخدام react-hook-form لإنشاء نموذج جديد
  const form = useForm<z.infer<typeof createClanSchema>>({
    resolver: zodResolver(createClanSchema),
    defaultValues: {
      name: "",
      leaderId: "",
      description: "",
      logoUrl: ""
    }
  });

  // تقديم النموذج
  function onSubmit(values: z.infer<typeof createClanSchema>) {
    createClanMutation.mutate(values);
  }

  // تغيير حالة عشيرة
  const handleStatusChange = (clanId: number, newStatus: string) => {
    updateClanStatusMutation.mutate({ clanId, status: newStatus });
  };

  // ترتيب العشائر
  const sortedClans = [...(clans as Clan[])].sort((a, b) => {
    if (!a.blacklisted && b.blacklisted) return -1;
    if (a.blacklisted && !b.blacklisted) return 1;
    return b.experience - a.experience;
  });

  // تصفية العشائر حسب البحث والفلتر
  const filteredClans = sortedClans.filter((clan: Clan) => 
    (filterStatus === "all" || 
     (filterStatus === "active" && !clan.blacklisted) || 
     (filterStatus === "inactive" && clan.blacklisted)) &&
    (searchQuery === "" || 
     clan.name.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // مكون لعرض تفاصيل العشيرة
  const ClanDetails = ({ clan }: { clan: Clan }) => (
    <div className="space-y-4">
      <div className="flex justify-between items-start">
        <div className="flex items-center gap-3">
          <Avatar className="h-16 w-16 border-2 border-[#5865F2]">
            {clan.logoUrl ? <AvatarImage src={clan.logoUrl} /> : null}
            <AvatarFallback className="bg-gradient-to-br from-[#5865F2] to-[#4752C4] text-xl font-bold">
              {clan.name.substring(0, 2)}
            </AvatarFallback>
          </Avatar>
          <div>
            <h3 className="text-xl font-bold">{clan.name}</h3>
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <span className="flex items-center">
                <Star className="h-4 w-4 mr-1 text-yellow-500" />
                مستوى {clan.level}
              </span>
              <Badge variant={clan.blacklisted ? "destructive" : "default"}>
                {clan.blacklisted ? "مدرج بالقائمة السوداء" : "نشط"}
              </Badge>
            </div>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Edit className="h-4 w-4 mr-1" />
            تعديل
          </Button>
          {!clan.blacklisted ? (
            <Button variant="destructive" size="sm" onClick={() => handleStatusChange(clan.id, "blacklisted")}>
              <ShieldOff className="h-4 w-4 mr-1" />
              إضافة للقائمة السوداء
            </Button>
          ) : (
            <Button variant="default" size="sm" onClick={() => handleStatusChange(clan.id, "active")}>
              <ShieldCheck className="h-4 w-4 mr-1" />
              إزالة من القائمة السوداء
            </Button>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Users className="h-6 w-6 mx-auto mb-2 text-blue-500" />
            <div className="text-2xl font-bold">{clan.memberCount}</div>
            <div className="text-sm text-gray-400">عدد الأعضاء</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Crown className="h-6 w-6 mx-auto mb-2 text-yellow-500" />
            <div className="text-2xl font-bold">{clan.consecutiveWins}</div>
            <div className="text-sm text-gray-400">الانتصارات المتتالية</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Shield className="h-6 w-6 mx-auto mb-2 text-green-500" />
            <div className="text-2xl font-bold">{clan.experience}</div>
            <div className="text-sm text-gray-400">نقاط الخبرة</div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <h4 className="font-semibold mb-2">وصف العشيرة</h4>
          <p className="text-gray-300 text-sm">{clan.description || "لا يوجد وصف"}</p>
        </div>
        <div>
          <h4 className="font-semibold mb-2">معلومات إضافية</h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>خزينة العشيرة:</div>
            <div className="text-[#5865F2] font-semibold">{clan.treasury} أركانية</div>
            
            <div>تاريخ الإنشاء:</div>
            <div>{new Date(clan.createdAt).toLocaleDateString("ar-SA")}</div>
            
            <div>التحديات المتبقية:</div>
            <div>{clan.specialChallengesRemaining} تحدي</div>
            
            <div>آخر تحدي:</div>
            <div>{clan.lastSpecialChallengeDate ? new Date(clan.lastSpecialChallengeDate).toLocaleDateString("ar-SA") : "لا يوجد"}</div>
          </div>
        </div>
      </div>
      
      <div>
        <div className="flex justify-between items-center mb-2">
          <h4 className="font-semibold">أعضاء العشيرة</h4>
          <Button variant="outline" size="sm">
            <UserPlus className="h-4 w-4 mr-1" />
            إضافة عضو
          </Button>
        </div>
        
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>العضو</TableHead>
                <TableHead>الدور</TableHead>
                <TableHead>المساهمة</TableHead>
                <TableHead>المهام المكتملة</TableHead>
                <TableHead>التبرعات</TableHead>
                <TableHead>تاريخ الانضمام</TableHead>
                <TableHead>الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {clanMembers.map((member: ClanMember) => (
                <TableRow key={member.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-gray-700 text-xs">
                          {member.userId.substring(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <span>{member.userId}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={member.role === "leader" ? "default" : "outline"}>
                      {member.role === "leader" ? "قائد" : 
                       member.role === "admin" ? "مسؤول" : 
                       member.role === "moderator" ? "مشرف" : "عضو"}
                    </Badge>
                  </TableCell>
                  <TableCell>{member.contributions} نقطة</TableCell>
                  <TableCell>{member.tasksCompleted} مهمة</TableCell>
                  <TableCell>{member.donationAmount} أركانية</TableCell>
                  <TableCell className="text-sm text-gray-400">
                    {new Date(member.joinDate).toLocaleDateString("ar-SA")}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500">
                        <UserMinus className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {clanMembers.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-6 text-gray-400">
                    لا يوجد أعضاء في هذه العشيرة حالياً
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </Card>
      </div>
    </div>
  );

  return (
    <div className="container mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold mb-2">إدارة العشائر</h1>
          <p className="text-muted-foreground">قم بإدارة العشائر وأعضائها وضبط الإعدادات الخاصة بها</p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-[#5865F2] to-[#4752C4]">
              <Plus className="h-4 w-4 mr-2" />
              إنشاء عشيرة جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>إنشاء عشيرة جديدة</DialogTitle>
              <DialogDescription>
                قم بإدخال المعلومات الأساسية للعشيرة الجديدة. يمكنك تعديل المزيد من الإعدادات لاحقاً.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>اسم العشيرة</FormLabel>
                      <FormControl>
                        <Input placeholder="أدخل اسم العشيرة" {...field} />
                      </FormControl>
                      <FormDescription>
                        يجب أن يكون الاسم فريداً ومناسباً.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="leaderId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>معرف قائد العشيرة</FormLabel>
                      <FormControl>
                        <Input placeholder="أدخل معرف القائد" {...field} />
                      </FormControl>
                      <FormDescription>
                        معرف ديسكورد للقائد الذي سيتولى إدارة العشيرة
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>وصف العشيرة</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="أدخل وصفاً للعشيرة" 
                          {...field} 
                          className="resize-none" 
                          rows={3}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="logoUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>رابط شعار العشيرة</FormLabel>
                      <FormControl>
                        <Input placeholder="أدخل رابط الشعار (اختياري)" {...field} />
                      </FormControl>
                      <FormDescription>
                        رابط URL لشعار العشيرة، يفضل أن يكون مربعاً وبدقة عالية
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter className="gap-2 sm:gap-0">
                  <DialogClose asChild>
                    <Button type="button" variant="outline">إلغاء</Button>
                  </DialogClose>
                  <Button 
                    type="submit" 
                    className="bg-gradient-to-r from-[#5865F2] to-[#4752C4]"
                    disabled={createClanMutation.isPending}
                  >
                    {createClanMutation.isPending && (
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    )}
                    إنشاء العشيرة
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
      
      <Tabs defaultValue="list" className="w-full">
        <TabsList className="mb-4 bg-gray-800 p-1 rounded-xl">
          <TabsTrigger value="list" className="rounded-lg">
            قائمة العشائر
          </TabsTrigger>
          <TabsTrigger value="details" className="rounded-lg" disabled={!selectedClan}>
            تفاصيل العشيرة
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="list" className="mt-0">
          <Card className="border-gray-700 bg-[#2F3136]">
            <CardHeader className="pb-2">
              <div className="flex flex-col sm:flex-row gap-4 justify-between">
                <div className="relative w-full max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="البحث عن عشيرة..."
                    className="pl-9 bg-gray-800"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4 text-gray-400" />
                  <Select
                    value={filterStatus}
                    onValueChange={setFilterStatus}
                  >
                    <SelectTrigger className="bg-gray-800 w-[140px]">
                      <SelectValue placeholder="الكل" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">الكل</SelectItem>
                      <SelectItem value="active">العشائر النشطة</SelectItem>
                      <SelectItem value="inactive">العشائر المعطلة</SelectItem>
                      <SelectItem value="pending">العشائر المعلقة</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="icon" className="h-10 w-10" onClick={() => setFilterStatus("all")}>
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <RefreshCw className="h-8 w-8 animate-spin text-gray-400 mb-4" />
                  <p className="text-gray-400">جاري تحميل بيانات العشائر...</p>
                </div>
              ) : filteredClans.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Shield className="h-12 w-12 text-gray-500 mb-4" />
                  <h3 className="text-xl font-semibold mb-2">لا توجد عشائر</h3>
                  <p className="text-gray-400 max-w-md">
                    {searchQuery 
                      ? "لا توجد نتائج مطابقة لبحثك. حاول استخدام كلمات مختلفة أو تغيير الفلتر."
                      : "لم يتم إنشاء أي عشائر بعد. قم بإنشاء أول عشيرة باستخدام زر 'إنشاء عشيرة جديدة'."}
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredClans.map((clan: Clan) => (
                    <Card 
                      key={clan.id} 
                      className={`
                        overflow-hidden border-t-4 cursor-pointer transition-all duration-200
                        hover:shadow-lg hover:translate-y-[-2px]
                        ${!clan.blacklisted 
                          ? "border-t-[#5865F2]" 
                          : "border-t-red-600"
                        }
                      `}
                      onClick={() => setSelectedClan(clan)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <Avatar className="h-12 w-12 border-2 border-[#5865F2]">
                            {clan.logoUrl ? <AvatarImage src={clan.logoUrl} /> : null}
                            <AvatarFallback className="bg-gradient-to-br from-[#5865F2] to-[#4752C4] text-white font-bold">
                              {clan.name.substring(0, 2)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-bold flex items-center gap-2">
                              {clan.name}
                              {clan.blacklisted && (
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Badge variant="destructive" className="text-xs">
                                        القائمة السوداء
                                      </Badge>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      <p>هذه العشيرة مدرجة في القائمة السوداء (+10% للمنافسين)</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              )}
                            </h3>
                            <div className="flex items-center gap-2 text-sm text-gray-400">
                              <span className="flex items-center">
                                <Star className="h-3 w-3 mr-1 text-yellow-500" />
                                مستوى {clan.level}
                              </span>
                              <span>•</span>
                              <span>{clan.memberCount} عضو</span>
                            </div>
                          </div>
                        </div>
                        
                        <p className="text-gray-300 text-sm line-clamp-2 mb-3">{clan.description || "لا يوجد وصف"}</p>
                        
                        <div className="grid grid-cols-2 gap-2 mb-3">
                          <div className="bg-gray-800 rounded p-1.5 text-center">
                            <p className="text-xs text-gray-400">نقاط الخبرة</p>
                            <p className="font-semibold">{clan.experience}</p>
                          </div>
                          <div className="bg-gray-800 rounded p-1.5 text-center">
                            <p className="text-xs text-gray-400">الانتصارات المتتالية</p>
                            <p className="font-semibold">{clan.consecutiveWins}</p>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center text-sm">
                          <div className="flex items-center">
                            <Coins className="h-4 w-4 mr-1 text-yellow-500" />
                            <span>{clan.treasury} أركانية</span>
                          </div>
                          
                          <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={(e) => {
                              e.stopPropagation();
                              setSelectedClan(clan);
                            }}>
                              <Edit className="h-3 w-3" />
                            </Button>
                            {!clan.blacklisted ? (
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-6 w-6 text-red-500"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleStatusChange(clan.id, "blacklisted");
                                }}
                              >
                                <ShieldOff className="h-3 w-3" />
                              </Button>
                            ) : (
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-6 w-6 text-green-500"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleStatusChange(clan.id, "active");
                                }}
                              >
                                <ShieldCheck className="h-3 w-3" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="details" className="mt-0">
          {selectedClan ? (
            <Card className="border-gray-700 bg-[#2F3136]">
              <CardHeader className="pb-2 flex flex-row justify-between items-start">
                <div>
                  <CardTitle>تفاصيل العشيرة</CardTitle>
                  <CardDescription>عرض وتعديل معلومات العشيرة وإدارة الأعضاء</CardDescription>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8"
                  onClick={() => setSelectedClan(null)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </CardHeader>
              <CardContent>
                <ClanDetails clan={selectedClan} />
              </CardContent>
            </Card>
          ) : (
            <Card className="border-gray-700 bg-[#2F3136]">
              <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                <Shield className="h-12 w-12 text-gray-500 mb-4" />
                <h3 className="text-xl font-semibold mb-2">لم يتم تحديد عشيرة</h3>
                <p className="text-gray-400 max-w-md">
                  الرجاء تحديد عشيرة من قائمة العشائر لعرض تفاصيلها
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
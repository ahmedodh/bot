import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, AlertTriangle, Server, Globe, CloudCog } from "lucide-react";

export default function Deployment() {
  const deploymentOptions = [
    {
      name: "Local Deployment",
      description: "Run your bot on your local machine (for development)",
      icon: <Server className="h-6 w-6 text-[#5865F2] mb-2" />,
      steps: [
        "Install Node.js on your computer",
        "Clone your bot repository",
        "Run `npm install` to install dependencies",
        "Set up your .env file with your bot token",
        "Start your bot with `node index.js` or `npm start`"
      ]
    },
    {
      name: "Cloud Hosting (Recommended)",
      description: "Deploy your bot on a cloud platform for 24/7 uptime",
      icon: <CloudCog className="h-6 w-6 text-[#5865F2] mb-2" />,
      steps: [
        "Choose a cloud provider (Heroku, Railway, Digital Ocean, etc.)",
        "Set up a new project/application",
        "Connect your GitHub repository or upload your code",
        "Configure environment variables (add your bot token)",
        "Deploy your application"
      ]
    },
    {
      name: "VPS Deployment",
      description: "Run your bot on a Virtual Private Server for full control",
      icon: <Globe className="h-6 w-6 text-[#5865F2] mb-2" />,
      steps: [
        "Rent a VPS from a provider (DigitalOcean, Linode, AWS, etc.)",
        "SSH into your server",
        "Install Node.js and git",
        "Clone your repository",
        "Install PM2 globally: `npm install -g pm2`",
        "Configure environment variables",
        "Start your bot with PM2: `pm2 start index.js --name discord-bot`"
      ]
    }
  ];
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white mb-2">Deployment</h1>
        <p className="text-[#B9BBBE]">
          Learn how to deploy your Discord bot to keep it running 24/7.
        </p>
      </div>
      
      <Card className="bg-[#292B2F] border-gray-700">
        <CardHeader className="pb-2">
          <CardTitle className="text-white flex items-center">
            <AlertCircle className="text-[#5865F2] mr-2 h-5 w-5" />
            Before You Deploy
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-[#B9BBBE]">
          <p>Make sure your bot meets these requirements before deployment:</p>
          <ul className="list-disc pl-5 space-y-1">
            <li>Your bot token is stored as an environment variable</li>
            <li>All dependencies are listed in package.json</li>
            <li>The bot has proper error handling to prevent crashes</li>
            <li>You have tested your bot thoroughly in a development environment</li>
          </ul>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {deploymentOptions.map((option, index) => (
          <Card key={index} className="bg-[#292B2F] border-gray-700">
            <CardHeader className="pb-2">
              <div className="flex flex-col items-center">
                {option.icon}
                <CardTitle className="text-white">{option.name}</CardTitle>
                <CardDescription className="text-center text-[#B9BBBE] mt-1">
                  {option.description}
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent>
              <h3 className="font-medium text-white mb-2">Steps:</h3>
              <ol className="list-decimal pl-5 text-[#B9BBBE] space-y-1">
                {option.steps.map((step, i) => (
                  <li key={i}>{step}</li>
                ))}
              </ol>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <Card className="bg-[#292B2F] border-gray-700">
        <CardHeader className="pb-2">
          <CardTitle className="text-white flex items-center">
            <AlertTriangle className="text-[#FAA61A] mr-2 h-5 w-5" />
            Common Deployment Issues
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-[#B9BBBE]">
            <div>
              <h3 className="font-medium text-white mb-1">Environment Variables</h3>
              <p>Make sure your bot token and other sensitive information are set as environment variables on your hosting platform.</p>
            </div>
            <div>
              <h3 className="font-medium text-white mb-1">Node.js Version</h3>
              <p>Ensure your hosting platform uses a compatible Node.js version (recommended: v16.x or newer).</p>
            </div>
            <div>
              <h3 className="font-medium text-white mb-1">Memory Limits</h3>
              <p>Free tiers of hosting services often have memory limits. Monitor your bot's memory usage to avoid crashes.</p>
            </div>
            <div>
              <h3 className="font-medium text-white mb-1">Idle Timeouts</h3>
              <p>Some free hosting services will put your application to sleep after periods of inactivity. Consider using a service like UptimeRobot to ping your application regularly.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import { useQuery } from "@tanstack/react-query";
import StatusCard from "@/components/dashboard/StatusCard";
import QuickStatsCard from "@/components/dashboard/QuickStatsCard";
import SetupGuideCard from "@/components/dashboard/SetupGuideCard";
import CommandsCard from "@/components/dashboard/CommandsCard";
import ErrorLogsSection from "@/components/dashboard/ErrorLogsSection";
import { Activity, BotStatus, Command, Log } from "@/lib/types";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  // Get bot status
  const { 
    data: botStatusData, 
    isLoading: statusLoading,
    error: statusError
  } = useQuery<BotStatus>({
    queryKey: ['/api/bot/status'],
  });
  
  // Get commands
  const { 
    data: commandsData, 
    isLoading: commandsLoading,
    error: commandsError
  } = useQuery<Command[]>({
    queryKey: ['/api/commands'],
  });
  
  // Get logs
  const { 
    data: logsData, 
    isLoading: logsLoading,
    error: logsError
  } = useQuery<Log[]>({
    queryKey: ['/api/logs'],
  });
  
  // Processing logs into activities
  const activities: Activity[] = logsData
    ? logsData
        .filter(log => log.type === 'command' || log.type === 'info')
        .slice(0, 3)
        .map(log => {
          // Format timestamp
          const now = new Date();
          const logDate = new Date(log.timestamp);
          const diffMinutes = Math.floor((now.getTime() - logDate.getTime()) / (1000 * 60));
          
          let timeAgo;
          if (diffMinutes < 1) {
            timeAgo = 'just now';
          } else if (diffMinutes < 60) {
            timeAgo = `${diffMinutes} minutes ago`;
          } else if (diffMinutes < 24 * 60) {
            timeAgo = `${Math.floor(diffMinutes / 60)} hours ago`;
          } else {
            timeAgo = `${Math.floor(diffMinutes / (60 * 24))} days ago`;
          }
          
          return {
            time: timeAgo,
            message: log.message
          };
        })
    : [];
  
  // Default bot status if not loaded
  const defaultBotStatus: BotStatus = {
    status: 'offline',
    stats: {
      id: 0,
      uptime: 0,
      commandsUsed: 0,
      serverCount: 0,
      memoryUsage: 0,
      latency: 0,
      apiCalls: 0,
      lastUpdated: new Date().toISOString()
    }
  };
  
  const botStatus = botStatusData || defaultBotStatus;
  const commands = commandsData || [];
  const logs = logsData || [];
  
  return (
    <div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Status Card */}
        {statusLoading ? (
          <div className="bg-[#292B2F] rounded-lg shadow-lg p-6">
            <Skeleton className="h-6 w-32 mb-6" />
            <div className="space-y-4">
              {[...Array(4)].map((_, i) => (
                <div key={i}>
                  <Skeleton className="h-4 w-16 mb-1" />
                  <Skeleton className="h-5 w-24" />
                </div>
              ))}
            </div>
            <Skeleton className="h-10 w-full mt-6" />
          </div>
        ) : (
          <StatusCard botStatus={botStatus} />
        )}
        
        {/* Quick Stats */}
        {statusLoading ? (
          <div className="bg-[#292B2F] rounded-lg shadow-lg p-6 col-span-1 lg:col-span-2">
            <Skeleton className="h-6 w-32 mb-6" />
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="bg-[#36393F] p-4 rounded-md">
                  <Skeleton className="h-4 w-24 mb-1" />
                  <Skeleton className="h-8 w-16" />
                </div>
              ))}
            </div>
            <Skeleton className="h-6 w-32 mt-6 mb-3" />
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-12 w-full mb-2" />
            ))}
          </div>
        ) : (
          <QuickStatsCard botStatus={botStatus} activities={activities} />
        )}
        
        {/* Bot Setup Guide */}
        <SetupGuideCard />
        
        {/* Command Management */}
        {commandsLoading ? (
          <div className="bg-[#292B2F] rounded-lg shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <Skeleton className="h-6 w-24" />
              <Skeleton className="h-9 w-24" />
            </div>
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-16 w-full mb-3" />
            ))}
          </div>
        ) : (
          <CommandsCard commands={commands} />
        )}
      </div>
      
      {/* Error Logs Section */}
      {logsLoading ? (
        <div className="mt-8">
          <div className="flex justify-between items-center mb-4">
            <Skeleton className="h-8 w-32" />
            <Skeleton className="h-6 w-24" />
          </div>
          <div className="bg-[#292B2F] rounded-lg shadow-lg overflow-hidden">
            <div className="bg-[#36393F] py-3 px-6 border-b border-gray-700">
              <Skeleton className="h-6 w-32" />
            </div>
            {[...Array(3)].map((_, i) => (
              <div key={i} className="p-4 border-b border-gray-700">
                <div className="flex items-center justify-between mb-2">
                  <Skeleton className="h-5 w-24" />
                  <Skeleton className="h-4 w-32" />
                </div>
                <Skeleton className="h-4 w-full" />
              </div>
            ))}
          </div>
        </div>
      ) : (
        <ErrorLogsSection logs={logs} />
      )}
    </div>
  );
}

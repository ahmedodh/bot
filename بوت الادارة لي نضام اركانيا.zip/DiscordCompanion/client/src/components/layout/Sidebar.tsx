import { Link } from "wouter";
import { 
  Home, 
  Terminal, 
  Clock, 
  FileText, 
  Settings, 
  Server,
  MoreVertical,
  Trophy,
  ShoppingCart,
  Coins,
  Quote,
  Shield,
  Swords,
  Users,
  BrainCircuit
} from "lucide-react";

interface SidebarProps {
  currentPath: string;
}

export default function Sidebar({ currentPath }: SidebarProps) {
  return (
    <aside className="bg-[#2F3136] w-64 flex-shrink-0 hidden md:block">
      <div className="h-full flex flex-col">
        <div className="p-4 border-b border-gray-700 bg-gradient-to-r from-[#3F4679] to-[#2B2D31]">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#5865F2] to-[#4752C4] flex items-center justify-center text-white font-bold shadow-lg">
              A
            </div>
            <div>
              <h1 className="text-white font-bold text-lg">A r k a n y a</h1>
              <p className="text-xs text-gray-300">النظام</p>
            </div>
          </div>
        </div>
        
        <nav className="flex-1 overflow-y-auto py-4">
          <div className="px-3 mb-2">
            <h2 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 px-2">لوحة التحكم</h2>
            <ul className="space-y-1">
              <SidebarItem 
                href="/" 
                icon={<Home className="h-5 w-5 mr-3" />} 
                label="الرئيسية" 
                isActive={currentPath === "/"} 
              />
              <SidebarItem 
                href="/commands" 
                icon={<Terminal className="h-5 w-5 mr-3" />} 
                label="الأوامر" 
                isActive={currentPath === "/commands"} 
              />
              <SidebarItem 
                href="/events" 
                icon={<Clock className="h-5 w-5 mr-3" />} 
                label="مراقبة الأحداث" 
                isActive={currentPath === "/events"} 
              />
              <SidebarItem 
                href="/logs" 
                icon={<FileText className="h-5 w-5 mr-3" />} 
                label="السجلات" 
                isActive={currentPath === "/logs"} 
              />
            </ul>
          </div>

          <div className="mt-6 px-3">
            <h2 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 px-2">نظام المستويات</h2>
            <ul className="space-y-1">
              <SidebarItem 
                href="/leveling" 
                icon={<Trophy className="h-5 w-5 mr-3" />} 
                label="المستويات والترقيات" 
                isActive={currentPath === "/leveling"} 
              />
              <SidebarItem 
                href="/economy" 
                icon={<Coins className="h-5 w-5 mr-3" />} 
                label="نظام الاقتصاد" 
                isActive={currentPath === "/economy"} 
              />
              <SidebarItem 
                href="/shop" 
                icon={<ShoppingCart className="h-5 w-5 mr-3" />} 
                label="المتجر" 
                isActive={currentPath === "/shop"} 
              />
              <SidebarItem 
                href="/quotes" 
                icon={<Quote className="h-5 w-5 mr-3" />} 
                label="الاقتباسات" 
                isActive={currentPath === "/quotes"} 
              />
            </ul>
          </div>
          
          <div className="mt-6 px-3">
            <h2 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 px-2">الذكاء الاصطناعي</h2>
            <ul className="space-y-1">
              <SidebarItem 
                href="/ai-assistant" 
                icon={<BrainCircuit className="h-5 w-5 mr-3" />} 
                label="المساعد الذكي" 
                isActive={currentPath === "/ai-assistant"} 
              />
            </ul>
          </div>
          
          <div className="mt-6 px-3">
            <h2 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 px-2">نظام العشائر</h2>
            <ul className="space-y-1">
              <SidebarItem 
                href="/clans" 
                icon={<Shield className="h-5 w-5 mr-3" />} 
                label="إدارة العشائر" 
                isActive={currentPath === "/clans"} 
              />
              <SidebarItem 
                href="/clan-wars" 
                icon={<Swords className="h-5 w-5 mr-3" />} 
                label="حرب العشائر" 
                isActive={currentPath === "/clan-wars"} 
              />
            </ul>
          </div>
          
          <div className="mt-6 px-3">
            <h2 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 px-2">الإعدادات</h2>
            <ul className="space-y-1">
              <SidebarItem 
                href="/settings" 
                icon={<Settings className="h-5 w-5 mr-3" />} 
                label="إعدادات البوت" 
                isActive={currentPath === "/settings"} 
              />
              <SidebarItem 
                href="/deployment" 
                icon={<Server className="h-5 w-5 mr-3" />} 
                label="النشر والتفعيل" 
                isActive={currentPath === "/deployment"} 
              />
            </ul>
          </div>
        </nav>
        
        <div className="p-4 mt-2 border-t border-gray-700 bg-gradient-to-r from-[#2F3136] to-[#262728]">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#43B581] to-[#308559] flex items-center justify-center text-white uppercase font-medium shadow-md">
                  A
                </div>
                <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-[#43B581] rounded-full border-2 border-[#2F3136]"></div>
              </div>
              <div>
                <div className="text-white font-medium">لوحة التحكم</div>
                <div className="flex items-center text-[#B9BBBE] text-xs">
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-green-500 mr-1.5"></span>
                  متصل
                </div>
              </div>
            </div>
            
            <button className="text-[#B9BBBE] hover:text-white hover:bg-gray-700 rounded-full p-1 transition">
              <MoreVertical className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}

interface SidebarItemProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
}

function SidebarItem({ href, icon, label, isActive }: SidebarItemProps) {
  return (
    <li>
      <Link href={href}>
        <a className={`
          flex items-center px-4 py-3 rounded-md font-medium transition-all duration-200
          ${isActive 
            ? "text-white bg-gradient-to-r from-[#5865F2] to-[#4752C4] shadow-md" 
            : "text-[#B9BBBE] hover:text-white hover:bg-[#292B2F] hover:translate-x-1"
          }
        `}>
          <div className={`
            flex items-center justify-center p-1
            ${isActive ? "text-white" : "text-[#B9BBBE]"}
          `}>
            {icon}
          </div>
          <span className="mr-1">{label}</span>
          
          {/* مؤشر نشط للعنصر المحدد */}
          {isActive && (
            <div className="mr-auto w-1.5 h-1.5 rounded-full bg-white animate-pulse"></div>
          )}
        </a>
      </Link>
    </li>
  );
}

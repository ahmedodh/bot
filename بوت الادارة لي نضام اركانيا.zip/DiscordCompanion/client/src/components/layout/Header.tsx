import { Button } from "@/components/ui/button";
import { RefreshCw, Search, Bell, Sun, Moon, Menu } from "lucide-react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";

interface HeaderProps {
  pageTitle: string;
}

export default function Header({ pageTitle }: HeaderProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [notificationCount, setNotificationCount] = useState(0);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  
  // استعلام لحالة البوت
  const { data: botStatus } = useQuery({
    queryKey: ['/api/bot/status'],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/bot/status", null);
      return res;
    },
    refetchInterval: 30000, // إعادة الاستعلام كل 30 ثانية
  });
  
  // إعادة تشغيل البوت
  const restartBotMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/bot/restart", {});
    },
    onSuccess: () => {
      toast({
        title: "تم بنجاح",
        description: "تم إعادة تشغيل البوت بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bot/status'] });
    },
    onError: (error) => {
      toast({
        title: "خطأ",
        description: `فشل في إعادة تشغيل البوت: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  // تبديل وضع الألوان (مظلم/فاتح)
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    // يمكن إضافة كود لتغيير السمة هنا إذا كان لديك تطبيق لذلك
  };
  
  // محاكاة إشعارات جديدة
  useEffect(() => {
    // تعيين عدد الإشعارات افتراضياً إلى 2 للعرض التوضيحي
    setNotificationCount(2);
  }, []);
  
  const handleRestartBot = () => {
    restartBotMutation.mutate();
  };
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      toast({
        title: "البحث",
        description: `جاري البحث عن: ${searchQuery}`,
      });
      // يمكن تنفيذ البحث الفعلي هنا
    }
  };
  
  return (
    <header className="bg-gradient-to-r from-[#2F3136] to-[#36393F] border-b border-gray-700 py-3 px-6 shadow-md">
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          {/* زر القائمة للموبايل - يظهر فقط على الشاشات الصغيرة */}
          <button 
            className="md:hidden text-[#B9BBBE] hover:text-white mr-3"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <Menu className="h-6 w-6" />
          </button>
          
          {/* عنوان الصفحة */}
          <div>
            <h2 className="text-xl font-bold text-white">{pageTitle}</h2>
            <p className="text-xs text-gray-400 hidden sm:block">لوحة تحكم بوت ديسكورد</p>
          </div>
        </div>
        
        {/* شريط البحث والأزرار */}
        <div className="flex items-center space-x-3 rtl:space-x-reverse">
          {/* نموذج البحث - إخفاء على الشاشات الصغيرة */}
          <form onSubmit={handleSearch} className="relative hidden md:flex items-center">
            <Input
              type="text"
              placeholder="البحث..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-48 lg:w-64 h-9 bg-[#202225] border-0 text-sm focus-visible:ring-1 focus-visible:ring-[#5865F2]"
            />
            <button 
              type="submit" 
              className="absolute left-2 text-gray-400 hover:text-white"
              aria-label="بحث"
            >
              <Search className="h-4 w-4" />
            </button>
          </form>
          
          {/* حالة البوت */}
          <div className="hidden md:flex items-center mr-2">
            <Badge 
              variant={botStatus?.status === 'online' ? "success" : "destructive"}
              className={`
                px-2 py-0.5 text-xs font-medium mr-2
                ${botStatus?.status === 'online' ? 'bg-green-500 hover:bg-green-600' : 'bg-red-500 hover:bg-red-600'}
              `}
            >
              {botStatus?.status === 'online' ? 'متصل' : 'غير متصل'}
            </Badge>
          </div>
          
          {/* زر الإشعارات */}
          <button className="relative text-[#B9BBBE] hover:text-white p-1.5 rounded-full hover:bg-gray-700 transition">
            <Bell className="h-5 w-5" />
            {notificationCount > 0 && (
              <span className="absolute top-0 right-0 inline-flex items-center justify-center w-4 h-4 text-xs font-bold text-white bg-red-500 rounded-full">
                {notificationCount}
              </span>
            )}
          </button>
          
          {/* زر تبديل الوضع المظلم/الفاتح */}
          <button 
            className="text-[#B9BBBE] hover:text-white p-1.5 rounded-full hover:bg-gray-700 transition"
            onClick={toggleDarkMode}
            aria-label={isDarkMode ? "تفعيل الوضع الفاتح" : "تفعيل الوضع المظلم"}
          >
            {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>
          
          {/* زر إعادة تشغيل البوت */}
          <Button
            onClick={handleRestartBot}
            disabled={restartBotMutation.isPending}
            className="bg-[#5865F2] hover:bg-[#4752C4] text-white"
            size="sm"
          >
            {restartBotMutation.isPending ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                جاري التشغيل...
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4 mr-2" />
                تحديث البوت
              </>
            )}
          </Button>
        </div>
      </div>
      
      {/* القائمة المنسدلة للموبايل */}
      {isMobileMenuOpen && (
        <div className="md:hidden mt-4 pt-4 border-t border-gray-700">
          <form onSubmit={handleSearch} className="relative flex items-center mb-4">
            <Input
              type="text"
              placeholder="البحث..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-9 bg-[#202225] border-0 text-sm focus-visible:ring-1 focus-visible:ring-[#5865F2]"
            />
            <button 
              type="submit" 
              className="absolute left-2 text-gray-400 hover:text-white"
              aria-label="بحث"
            >
              <Search className="h-4 w-4" />
            </button>
          </form>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Badge 
                variant={botStatus?.status === 'online' ? "success" : "destructive"} 
                className={botStatus?.status === 'online' ? 'bg-green-500' : 'bg-red-500'}
              >
                {botStatus?.status === 'online' ? 'متصل' : 'غير متصل'}
              </Badge>
              <span className="text-gray-400 text-sm mr-2">حالة البوت</span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

export default function SetupGuideCard() {
  return (
    <div className="bg-[#292B2F] rounded-lg shadow-lg p-6">
      <h3 className="font-medium text-white mb-4">Discord.js Bot Setup Guide</h3>
      <div className="space-y-4">
        <div className="border border-gray-700 rounded-md overflow-hidden">
          <div className="bg-[#36393F] py-2 px-4 text-white font-medium border-b border-gray-700">1. Install Dependencies</div>
          <pre className="bg-[#2F3136] p-4 text-[#B9BBBE] font-mono text-sm overflow-x-auto">npm install discord.js dotenv</pre>
        </div>
        <div className="border border-gray-700 rounded-md overflow-hidden">
          <div className="bg-[#36393F] py-2 px-4 text-white font-medium border-b border-gray-700">2. Create .env File</div>
          <pre className="bg-[#2F3136] p-4 text-[#B9BBBE] font-mono text-sm overflow-x-auto">TOKEN=your_discord_bot_token</pre>
        </div>
        <div className="border border-gray-700 rounded-md overflow-hidden">
          <div className="bg-[#36393F] py-2 px-4 text-white font-medium border-b border-gray-700">3. Basic Bot Setup (index.js)</div>
          <pre className="bg-[#2F3136] p-4 text-[#B9BBBE] font-mono text-sm overflow-x-auto">{`require('dotenv').config();
const { Client, GatewayIntentBits } = require('discord.js');

const client = new Client({ 
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ] 
});

client.once('ready', () => {
  console.log(\`Logged in as \${client.user.tag}!\`);
});

client.on('messageCreate', async message => {
  if (message.author.bot) return;
  
  if (message.content.startsWith('!ping')) {
    await message.reply('Pong!');
  }
});

client.login(process.env.TOKEN);`}</pre>
        </div>
        <div className="border border-gray-700 rounded-md overflow-hidden">
          <div className="bg-[#36393F] py-2 px-4 text-white font-medium border-b border-gray-700">4. Start the Bot</div>
          <pre className="bg-[#2F3136] p-4 text-[#B9BBBE] font-mono text-sm overflow-x-auto">node index.js</pre>
        </div>
      </div>
    </div>
  );
}

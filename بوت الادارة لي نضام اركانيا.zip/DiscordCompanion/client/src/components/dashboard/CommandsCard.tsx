import { Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Command } from "@/lib/types";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

interface CommandsCardProps {
  commands: Command[];
}

export default function CommandsCard({ commands }: CommandsCardProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const deleteCommandMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/commands/${id}`, null);
    },
    onSuccess: () => {
      toast({
        title: "Command deleted",
        description: "The command has been deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/commands'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete command: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const handleDeleteCommand = (id: number, name: string) => {
    if (window.confirm(`Are you sure you want to delete the command ${name}?`)) {
      deleteCommandMutation.mutate(id);
    }
  };
  
  return (
    <div className="bg-[#292B2F] rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-medium text-white">Commands</h3>
        <Link href="/commands">
          <Button size="sm" className="bg-[#5865F2] hover:bg-opacity-80 text-white">
            + Add New
          </Button>
        </Link>
      </div>
      <div className="space-y-3">
        {commands.length === 0 ? (
          <div className="text-[#B9BBBE] text-center py-4">
            No commands available
          </div>
        ) : (
          commands.slice(0, 4).map((command) => (
            <div 
              key={command.id} 
              className="bg-[#36393F] p-3 rounded-md flex items-center justify-between"
            >
              <div>
                <div className="text-white font-medium">{command.name}</div>
                <div className="text-[#B9BBBE] text-xs">{command.description}</div>
              </div>
              <div className="flex space-x-2">
                <Link href={`/commands/edit/${command.id}`}>
                  <button className="text-[#B9BBBE] hover:text-white">
                    <Pencil className="h-5 w-5" />
                  </button>
                </Link>
                <button 
                  className="text-[#B9BBBE] hover:text-[#ED4245]"
                  onClick={() => handleDeleteCommand(command.id, command.name)}
                  disabled={deleteCommandMutation.isPending}
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            </div>
          ))
        )}
        
        {commands.length > 4 && (
          <div className="text-center mt-4">
            <Link href="/commands">
              <Button variant="link" className="text-[#5865F2]">
                View all {commands.length} commands
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}

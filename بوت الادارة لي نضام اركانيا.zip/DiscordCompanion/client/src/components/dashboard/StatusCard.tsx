import { BotStatus } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface StatusCardProps {
  botStatus: BotStatus;
}

export default function StatusCard({ botStatus }: StatusCardProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const formatUptime = (seconds: number): string => {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    return `${days}d ${hours}h ${minutes}m`;
  };
  
  const restartBotMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/bot/restart", {});
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Bot has been restarted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bot/status'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to restart bot: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const handleRestartBot = () => {
    restartBotMutation.mutate();
  };
  
  return (
    <div className="bg-[#292B2F] rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-medium text-white">Bot Status</h3>
        <span className={`${botStatus.status === 'online' ? 'bg-[#43B581]' : 'bg-[#ED4245]'} text-white text-xs px-2 py-1 rounded-full font-medium`}>
          {botStatus.status === 'online' ? 'Online' : 'Offline'}
        </span>
      </div>
      <div className="space-y-4">
        <div>
          <div className="text-[#B9BBBE] text-sm mb-1">Name</div>
          <div className="text-white">DiscordBot</div>
        </div>
        <div>
          <div className="text-[#B9BBBE] text-sm mb-1">Uptime</div>
          <div className="text-white">
            {botStatus.status === 'online' 
              ? formatUptime(botStatus.stats.uptime)
              : 'N/A'}
          </div>
        </div>
        <div>
          <div className="text-[#B9BBBE] text-sm mb-1">Commands Used</div>
          <div className="text-white">
            {botStatus.status === 'online' 
              ? botStatus.stats.commandsUsed
              : 'N/A'}
          </div>
        </div>
        <div>
          <div className="text-[#B9BBBE] text-sm mb-1">Servers</div>
          <div className="text-white">
            {botStatus.status === 'online' 
              ? botStatus.stats.serverCount
              : 'N/A'}
          </div>
        </div>
      </div>
      <div className="mt-6">
        <Button
          variant="destructive"
          className="w-full bg-[#ED4245] hover:bg-opacity-90"
          onClick={handleRestartBot}
          disabled={restartBotMutation.isPending}
        >
          {restartBotMutation.isPending ? "Restarting..." : "Restart Bot"}
        </Button>
      </div>
    </div>
  );
}

import { useQuery } from "@tanstack/react-query";
import { Activity, BotStatus, Log } from "@/lib/types";
import { Skeleton } from "@/components/ui/skeleton";

interface QuickStatsCardProps {
  botStatus: BotStatus;
  activities: Activity[];
}

export default function QuickStatsCard({ botStatus, activities }: QuickStatsCardProps) {
  return (
    <div className="bg-[#292B2F] rounded-lg shadow-lg p-6">
      <h3 className="font-medium text-white mb-6">Quick Stats</h3>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#36393F] p-4 rounded-md">
          <div className="text-[#B9BBBE] text-sm">Bot Latency</div>
          <div className="text-white text-2xl font-semibold mt-1">
            {botStatus.status === 'online' ? `${botStatus.stats.latency}ms` : 'N/A'}
          </div>
        </div>
        <div className="bg-[#36393F] p-4 rounded-md">
          <div className="text-[#B9BBBE] text-sm">Memory Usage</div>
          <div className="text-white text-2xl font-semibold mt-1">
            {botStatus.status === 'online' ? `${botStatus.stats.memoryUsage}MB` : 'N/A'}
          </div>
        </div>
        <div className="bg-[#36393F] p-4 rounded-md">
          <div className="text-[#B9BBBE] text-sm">API Calls</div>
          <div className="text-white text-2xl font-semibold mt-1">
            {botStatus.status === 'online' 
              ? `${botStatus.stats.apiCalls >= 1000 
                  ? (botStatus.stats.apiCalls / 1000).toFixed(1) + 'K' 
                  : botStatus.stats.apiCalls}`
              : 'N/A'}
          </div>
        </div>
      </div>
      <div className="mt-6">
        <h4 className="text-[#B9BBBE] text-sm mb-3">Recent Activity</h4>
        {activities.length === 0 ? (
          <div className="text-[#B9BBBE] text-center py-4">
            No recent activity
          </div>
        ) : (
          activities.map((activity, index) => (
            <div 
              key={index} 
              className="flex items-center py-2 border-b border-gray-700"
            >
              <div className="text-[#B9BBBE] text-sm flex-shrink-0 w-32">
                {activity.time}
              </div>
              <div 
                className="ml-2 text-white"
                dangerouslySetInnerHTML={{ 
                  __html: activity.message
                    .replace(/!([a-z]+)/g, '<span class="text-[#5865F2]">!$1</span>')
                    .replace(/in (.+)$/, 'in <span class="text-[#43B581]">$1</span>')
                }}
              />
            </div>
          ))
        )}
      </div>
    </div>
  );
}

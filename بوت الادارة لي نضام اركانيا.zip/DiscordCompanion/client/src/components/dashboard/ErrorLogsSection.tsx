import { Log } from "@/lib/types";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { format } from "date-fns";

interface ErrorLogsSectionProps {
  logs: Log[];
}

export default function ErrorLogsSection({ logs }: ErrorLogsSectionProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const clearLogsMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", "/api/logs", null);
    },
    onSuccess: () => {
      toast({
        title: "Logs cleared",
        description: "All logs have been cleared successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/logs'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to clear logs: ${error.message}`,
        variant: "destructive",
      });
    }
  });
  
  const handleClearLogs = () => {
    if (window.confirm("Are you sure you want to clear all logs?")) {
      clearLogsMutation.mutate();
    }
  };
  
  const getLogTypeInfo = (type: string) => {
    switch (type) {
      case 'error':
        return {
          color: 'bg-[#ED4245]',
          textColor: 'text-[#ED4245]',
          label: 'Error'
        };
      case 'warning':
        return {
          color: 'bg-[#FAA61A]',
          textColor: 'text-[#FAA61A]',
          label: 'Warning'
        };
      default:
        return {
          color: 'bg-[#5865F2]',
          textColor: 'text-[#5865F2]',
          label: type.charAt(0).toUpperCase() + type.slice(1)
        };
    }
  };
  
  const formatLogDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    
    // Today
    if (date.toDateString() === now.toDateString()) {
      return `Today, ${format(date, 'HH:mm')}`;
    }
    
    // Yesterday
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) {
      return `Yesterday, ${format(date, 'HH:mm')}`;
    }
    
    // Other days
    return format(date, 'dd MMM, HH:mm');
  };
  
  // Filter logs to show only errors and warnings
  const errorLogs = logs.filter(log => 
    log.type === 'error' || log.type === 'warning'
  ).slice(0, 3);
  
  return (
    <div className="mt-8">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-white">Error Logs</h3>
        <Link href="/logs">
          <Button variant="link" className="text-[#5865F2]">
            View all logs
          </Button>
        </Link>
      </div>
      <div className="bg-[#292B2F] rounded-lg shadow-lg overflow-hidden">
        <div className="bg-[#36393F] py-3 px-6 border-b border-gray-700 flex justify-between items-center">
          <div className="text-white font-medium">Recent Errors</div>
          <Button 
            variant="ghost" 
            size="sm"
            className="text-[#B9BBBE] hover:text-white text-sm"
            onClick={handleClearLogs}
            disabled={clearLogsMutation.isPending}
          >
            Clear All
          </Button>
        </div>
        <div className="divide-y divide-gray-700">
          {errorLogs.length === 0 ? (
            <div className="p-4 text-center text-[#B9BBBE]">
              No error logs found
            </div>
          ) : (
            errorLogs.map(log => {
              const typeInfo = getLogTypeInfo(log.type);
              return (
                <div key={log.id} className="p-4 hover:bg-[#36393F]">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center">
                      <div className={`w-2 h-2 ${typeInfo.color} rounded-full mr-2`}></div>
                      <div className={`${typeInfo.textColor} font-medium`}>
                        {typeInfo.label}
                      </div>
                    </div>
                    <div className="text-[#B9BBBE] text-sm">
                      {formatLogDate(log.timestamp)}
                    </div>
                  </div>
                  <p className="text-[#B9BBBE] text-sm">{log.message}</p>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}


from flask import Flask
from threading import Thread

app = Flask(__name__)

@app.route('/ping')
def ping():
    return "Bot is alive!"

def run_web_server():
    app.run(host='0.0.0.0', port=5000)

def keep_alive():
    server = Thread(target=run_web_server)
    server.start()

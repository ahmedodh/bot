
import asyncio
import os
import sys
import logging
from datetime import datetime
from dotenv import load_dotenv
from web_server import keep_alive

# إعداد التسجيل
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('bot.log')
    ]
)
logger = logging.getLogger('bot')

load_dotenv()

def check_token():
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        logger.error("خطأ: DISCORD_TOKEN غير موجود في ملف .env")
        logger.error("الرجاء التأكد من إضافة التوكن إلى إعدادات البوت")
        return False
    return True

async def run_bot_with_retry():
    while True:
        try:
            if not check_token():
                await asyncio.sleep(60)  # انتظر دقيقة قبل إعادة المحاولة
                continue

            from bot import bot, start_bot
            logger.info("بدء تشغيل بوت Discord...")
            
            try:
                await start_bot()
            except Exception as e:
                logger.error(f"حدث خطأ أثناء تشغيل البوت: {e}")
                logger.info("إعادة المحاولة بعد 30 ثانية...")
                await asyncio.sleep(30)
                continue
                
        except Exception as e:
            logger.error(f"خطأ غير متوقع: {e}")
            logger.info("إعادة المحاولة بعد 60 ثانية...")
            await asyncio.sleep(60)

if __name__ == "__main__":
    keep_alive()  # Start the web server
    logger.info("تهيئة نظام المستويات...")
    
    # التأكد من تثبيت المكتبات المطلوبة
    try:
        import discord
        from discord.ext import commands
        logger.info("✅ تم التحقق من مكتبات Discord")
    except ImportError:
        logger.error("❌ فشل تحميل مكتبات Discord. تأكد من تثبيت discord.py")
        sys.exit(1)
    
    # تشغيل البوت مع إعادة المحاولة التلقائية
    loop = asyncio.get_event_loop()
    try:
        loop.run_until_complete(run_bot_with_retry())
    except KeyboardInterrupt:
        logger.info("\nتم إيقاف البوت بواسطة المستخدم")
    finally:
        loop.close()

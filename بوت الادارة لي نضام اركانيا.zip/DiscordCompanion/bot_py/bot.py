import discord
from discord.ext import commands, tasks
import json
import os
from datetime import datetime, timedelta
import asyncio
from dotenv import load_dotenv
from discord.ui import Button, View, Select
import logging
import sys
import random
import aiohttp
import calendar
from typing import Dict, List, Optional, Union, Any

# إعداد السجلات
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('bot')

# تحميل متغيرات البيئة
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
if not TOKEN:
    logger.error("لم يتم العثور على توكن Discord")

# تكوين النظام
XP_PER_LEVEL = 1000  # XP المطلوب لكل مستوى (ثابت)
COINS_PER_XP = 10  # الحصول على عملة واحدة كل 10 نقاط XP
LEVEL_BONUS = 50  # مكافأة العملات عند الوصول لمستوى جديد
DATA_FILE = 'user_data.json'  # ملف تخزين البيانات (سيتم استبداله لاحقًا بقاعدة البيانات)

class LevelingBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True
        intents.members = True
        super().__init__(command_prefix="!", intents=intents, help_command=None)
        
        # تهيئة متغيرات النظام
        self.shop_items = [
            {
                "id": 1,
                "name": "عضوية VIP",
                "description": "احصل على +20% XP وعلامة مميزة لمدة 30 يوم",
                "price": 1500,
                "type": "VIP",
                "duration": 30  # بالأيام
            },
            {
                "id": 2,
                "name": "تغيير لون",
                "description": "اختر لونًا مخصصًا لملفك الشخصي",
                "price": 500,
                "type": "COLOR",
                "duration": 0  # دائم
            },
            {
                "id": 3,
                "name": "إضافة اقتباس",
                "description": "أضف اقتباسًا إلى مكتبة اقتباساتك",
                "price": 10,
                "type": "QUOTE",
                "duration": 0  # دائم
            }
        ]
        
        # قائمة الألوان المتاحة في المتجر
        self.available_colors = {
            "أحمر": "#e74c3c",
            "أخضر": "#2ecc71",
            "أزرق": "#3498db",
            "ذهبي": "#f1c40f",
            "برتقالي": "#e67e22",
            "أرجواني": "#9b59b6",
            "وردي": "#e84393",
            "تركواز": "#1abc9c",
            "كهرماني": "#f39c12",
            "أسود": "#000000"
        }
        
        # ألوان أسبوعية متجددة - سيتم تحديثها في setup_hook
        self.weekly_colors = {}
        self.last_color_update = None
        
        # قائمة الألقاب للمستويات
        self.rank_titles = {
            0: "🎯 مبتدئ",
            10: "🌱 مقاتل",
            20: "🔥 محارب",
            30: "⚡ متمرس",
            40: "🏹 قناص",
            50: "🛡️ حامي",
            60: "🗡️ محارب ماهر",
            70: "⚔️ محارب متقدم",
            80: "💫 محارب عظيم",
            90: "🌟 أسطورة",
            100: "👑 خالد",
            150: "👿 الخالد الشيطاني"
        }
        
        # قائمة الألوان للمستويات
        self.rank_colors = {
            0: discord.Color.from_rgb(88, 101, 242),    # مبتدئ - أزرق ديسكورد
            10: discord.Color.from_rgb(169, 169, 169),  # مقاتل - رمادي
            20: discord.Color.from_rgb(0, 100, 0),      # محارب - أخضر داكن
            30: discord.Color.from_rgb(0, 0, 139),      # متمرس - أزرق داكن
            40: discord.Color.from_rgb(184, 134, 11),   # قناص - ذهبي داكن
            50: discord.Color.from_rgb(220, 20, 60),    # حامي - أحمر
            60: discord.Color.from_rgb(0, 128, 128),    # محارب ماهر - أزرق مخضر
            70: discord.Color.from_rgb(50, 205, 50),    # محارب متقدم - أخضر
            80: discord.Color.from_rgb(0, 191, 255),    # محارب عظيم - أزرق سماوي
            90: discord.Color.from_rgb(255, 140, 0),    # أسطورة - برتقالي
            100: discord.Color.from_rgb(255, 215, 0),   # خالد - ذهبي
            150: discord.Color.from_rgb(128, 0, 128)    # الخالد الشيطاني - بنفسجي غامق
        }
        
        # كوبونات الخصم المتاحة
        self.coupons = {
            "ARKANYA10": {"discount": 0.1, "max_uses": 50, "uses": 0, "expiry": "2025-12-31"},  # خصم 10٪
            "NEWUSER25": {"discount": 0.25, "max_uses": 100, "uses": 0, "expiry": "2025-06-30"}, # خصم 25٪ للمستخدمين الجدد
            "VIP50": {"discount": 0.5, "max_uses": 20, "uses": 0, "expiry": "2025-03-30"},      # خصم 50٪ على VIP
            "LEVEL100": {"discount": 0.75, "max_uses": 10, "uses": 0, "expiry": "2025-12-31"},  # خصم 75٪ للمستوى 100
            "RAMADAN": {"discount": 0.3, "max_uses": 1000, "uses": 0, "expiry": "2025-06-01"}   # خصم 30٪ خلال رمضان
        }
        
        # صناديق الحظ (العشوائية)
        self.random_boxes = [
            {
                "id": 10,
                "name": "صندوق عشوائي",
                "description": "يحتوي على عناصر عشوائية، احتمالية الفوز بجائزة كبيرة!",
                "price": 300,
                "type": "RANDOM_BOX",
                "possible_rewards": [
                    {"type": "COINS", "amount": 50, "chance": 0.3},     # 30% فرصة الفوز بـ 50 عملة
                    {"type": "COINS", "amount": 150, "chance": 0.25},   # 25% فرصة الفوز بـ 150 عملة
                    {"type": "XP", "amount": 200, "chance": 0.2},       # 20% فرصة الفوز بـ 200 نقطة خبرة
                    {"type": "COLOR", "chance": 0.15},                  # 15% فرصة الفوز بتغيير لون
                    {"type": "VIP", "days": 7, "chance": 0.08},         # 8% فرصة الفوز بعضوية VIP لمدة أسبوع
                    {"type": "COINS", "amount": 500, "chance": 0.02}    # 2% فرصة الفوز بـ 500 عملة
                ]
            },
            {
                "id": 11,
                "name": "صندوق الأبطال",
                "description": "صندوق خاص للمستويات العالية، يحتوي على جوائز قيمة!",
                "price": 750,
                "type": "RANDOM_BOX",
                "min_level": 30,  # الحد الأدنى للمستوى
                "possible_rewards": [
                    {"type": "COINS", "amount": 300, "chance": 0.3},    # 30% فرصة الفوز بـ 300 عملة
                    {"type": "XP", "amount": 500, "chance": 0.25},      # 25% فرصة الفوز بـ 500 نقطة خبرة
                    {"type": "COLOR", "chance": 0.2},                   # 20% فرصة الفوز بتغيير لون
                    {"type": "VIP", "days": 15, "chance": 0.15},        # 15% فرصة الفوز بعضوية VIP لمدة أسبوعين
                    {"type": "COINS", "amount": 1000, "chance": 0.08},  # 8% فرصة الفوز بـ 1000 عملة
                    {"type": "RARE_COLOR", "chance": 0.02}              # 2% فرصة الفوز بلون نادر
                ]
            }
        ]

    async def setup_hook(self):
        """تهيئة البوت عند بدء التشغيل"""
        logger.info("تهيئة البوت...")
        if not os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'w', encoding='utf-8') as f:
                json.dump({}, f)
                
        # تهيئة قاعدة البيانات (سيتم إضافة كود الاتصال بقاعدة البيانات لاحقاً)
        
        # تحديث الألوان الأسبوعية
        await self.update_weekly_colors()
                
        # بدء دوال التحقق الدورية
        self.bg_tasks = {
            "check_vip_expiry": self.create_task(self.check_vip_expiry()),
            "check_weekly_colors": self.create_task(self.check_weekly_colors())
        }
        
        # سنستخدم التحقق من التحديث في مهمة منفصلة بدلاً من tasks.loop
    
    def create_task(self, coro):
        """إنشاء مهمة في الخلفية"""
        async def error_handler(task):
            try:
                await task
            except Exception as error:
                logger.error(f"خطأ في المهمة: {error}")
                
        task = self.loop.create_task(coro)
        task.add_done_callback(lambda t: self.loop.create_task(error_handler(t)) if t.exception() else None)
        return task
    
    async def check_vip_expiry(self):
        """التحقق من انتهاء صلاحية عضويات VIP"""
        await self.wait_until_ready()
        while not self.is_closed():
            try:
                data = self.load_data()
                current_time = datetime.now()
                
                for user_id, user_data in data.items():
                    if "vip_expiry" in user_data and user_data["vip_expiry"]:
                        expiry_date = datetime.fromisoformat(user_data["vip_expiry"])
                        if current_time > expiry_date:
                            user_data["is_vip"] = False
                            user_data["vip_expiry"] = None
                            self.save_data(data)
                            
                            # إرسال إشعار للمستخدم (إذا أمكن)
                            try:
                                user = await self.fetch_user(int(user_id))
                                await user.send("⚠️ انتهت صلاحية عضويتك VIP. يمكنك تجديدها من خلال المتجر!")
                            except:
                                pass
            except Exception as e:
                logger.error(f"خطأ في التحقق من انتهاء صلاحية VIP: {e}")
                
            await asyncio.sleep(3600)  # تحقق كل ساعة

    def load_data(self):
        """تحميل بيانات المستخدمين من الملف"""
        try:
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"خطأ في تحميل البيانات: {e}")
            return {}

    def save_data(self, data):
        """حفظ بيانات المستخدمين في الملف"""
        try:
            with open(DATA_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
        except Exception as e:
            logger.error(f"خطأ في حفظ البيانات: {e}")

    def get_user_data(self, user_id: str):
        """الحصول على بيانات المستخدم، مع إنشاء بيانات جديدة إذا لم تكن موجودة"""
        data = self.load_data()
        
        # بيانات المستخدم الافتراضية
        default_data = {
            "xp": 0,
            "total_xp": 0,
            "level": 1,
            "coins": 0,
            "rank": "مبتدئ",
            "color": "#3498db",
            "joined_at": datetime.now().isoformat(),
            "is_vip": False,
            "vip_expiry": None,
            "inventory": [],
            "quotes": []
        }
            
        # إنشاء مستخدم جديد إذا لم يكن موجودًا
        if user_id not in data:
            data[user_id] = default_data
            self.save_data(data)
        else:
            # إضافة الحقول المفقودة إذا كان المستخدم موجودًا ولكن ناقص بعض البيانات
            for key, value in default_data.items():
                if key not in data[user_id]:
                    data[user_id][key] = value
                    print(f"تمت إضافة الحقل المفقود: {key} للمستخدم {user_id}")
            
            # التأكد من أن أي تغييرات تم حفظها
            self.save_data(data)
            
        return data[user_id]

    @staticmethod
    def calculate_level(xp: int) -> int:
        # كل مستوى يحتاج بالضبط 1000 نقطة XP وبدون حد أقصى للمستويات
        # المستوى 1: 0-999 XP, المستوى 2: 1000-1999 XP, المستوى 3: 2000-2999 XP, وهكذا
        return max(1, (xp // 1000) + 1)

    @staticmethod
    def generate_xp_bar(xp: int, level: int, length: int = 20) -> tuple:
        try:
            # حساب XP للمستوى الحالي والتالي
            current_level_xp = (level - 1) * 1000
            next_level_xp = level * 1000

            # حساب التقدم في المستوى الحالي
            xp_progress = xp - current_level_xp
            xp_needed = next_level_xp - current_level_xp

            # حساب النسبة المئوية والشريط
            progress = min(1.0, max(0.0, xp_progress / xp_needed))
            filled = int(length * progress)
            percentage = min(100, max(0, int(progress * 100)))

            if percentage > 90:
                bar = "💫" + "━" * filled + "╍" * (length - filled)
            elif percentage > 75:
                bar = "⭐" + "━" * filled + "╍" * (length - filled)
            elif percentage > 50:
                bar = "✨" + "━" * filled + "╍" * (length - filled)
            elif percentage > 25:
                bar = "⚡" + "━" * filled + "╍" * (length - filled)
            else:
                bar = "🌟" + "━" * filled + "╍" * (length - filled)

            return bar, percentage
        except Exception as e:
            logger.error(f"خطأ في إنشاء شريط التقدم: {e}")
            return "⚠️" + "━" * length, 0

    def get_motivational_message(self, level: int) -> str:
        messages = {
            1: "🌱 بداية رحلتك نحو النجاح! استمر في التقدم",
            5: "⭐ أنت تتألق! خمس مستويات من التميز",
            10: "🌟 عشرة مستويات من الإبداع! أنت نجم ساطع",
            15: "💫 خمسة عشر مستوى! قوتك تزداد",
            20: "🎯 عشرون مستوى! أنت تحقق المستحيل",
            25: "👑 خمسة وعشرون مستوى! أنت ملك التحدي",
            30: "🌈 ثلاثون مستوى! أسطورة حقيقية",
            40: "⚡ أربعون مستوى! قوة لا تقهر",
            50: "🌠 خمسون مستوى! نصف الطريق إلى القمة",
            75: "🎭 خمسة وسبعون مستوى! أنت أسطورة",
            100: "🔱 مستوى مئة! وصلت إلى القمة"
        }
        return messages.get(level, "🌟 أنت تتقدم بشكل رائع!")
    
    async def update_weekly_colors(self):
        """تحديث قائمة الألوان الأسبوعية"""
        try:
            # توليد ألوان عشوائية جديدة
            colors = {
                "أحمر ناري": f"#{random.randint(180, 255):02x}{random.randint(0, 100):02x}{random.randint(0, 100):02x}",
                "أزرق سماوي": f"#{random.randint(0, 100):02x}{random.randint(100, 200):02x}{random.randint(200, 255):02x}",
                "أخضر زمردي": f"#{random.randint(0, 100):02x}{random.randint(180, 255):02x}{random.randint(0, 100):02x}",
                "بنفسجي ملكي": f"#{random.randint(100, 180):02x}{random.randint(0, 100):02x}{random.randint(180, 255):02x}",
                "ذهبي لامع": f"#{random.randint(200, 255):02x}{random.randint(180, 230):02x}{random.randint(0, 100):02x}",
                "وردي باستيل": f"#{random.randint(230, 255):02x}{random.randint(150, 200):02x}{random.randint(180, 230):02x}",
                "أزرق غامق": f"#{random.randint(0, 80):02x}{random.randint(0, 100):02x}{random.randint(120, 200):02x}",
                "تركواز مشرق": f"#{random.randint(0, 100):02x}{random.randint(180, 255):02x}{random.randint(180, 255):02x}",
                "برتقالي شروق": f"#{random.randint(230, 255):02x}{random.randint(100, 180):02x}{random.randint(0, 100):02x}",
                "رمادي فضي": f"#{random.randint(150, 200):02x}{random.randint(150, 200):02x}{random.randint(150, 200):02x}"
            }
            
            self.weekly_colors = colors
            self.last_color_update = datetime.now().isoformat()
            
            # إعلان للمستخدمين في قنوات محددة (اختياري)
            for guild in self.guilds:
                try:
                    system_channel = guild.system_channel
                    if system_channel:
                        embed = discord.Embed(
                            title="🎨 تم تحديث ألوان المتجر الأسبوعية!",
                            description="تفضل بزيارة المتجر للاطلاع على الألوان الجديدة. استخدم `!colors` لعرض قائمة الألوان المتاحة.",
                            color=discord.Color.from_rgb(255, 215, 0)
                        )
                        await system_channel.send(embed=embed)
                except Exception as e:
                    logger.error(f"خطأ في إرسال إشعار تحديث الألوان: {e}")
            
            logger.info("تم تحديث الألوان الأسبوعية بنجاح")
            return True
        except Exception as e:
            logger.error(f"خطأ في تحديث الألوان الأسبوعية: {e}")
            return False
    
    async def check_weekly_colors(self):
        """التحقق من وقت تحديث الألوان الأسبوعية"""
        await self.wait_until_ready()
        while not self.is_closed():
            try:
                # التحقق مما إذا كان اليوم هو السبت وتحديث الألوان إذا كان كذلك
                current_date = datetime.now()
                
                # إذا كان اليوم سبت (5 هو رقم اليوم للسبت في نظام Python)
                if current_date.weekday() == 5:
                    # إذا لم يتم التحديث بعد اليوم
                    if not self.last_color_update or datetime.fromisoformat(self.last_color_update).date() != current_date.date():
                        await self.update_weekly_colors()
                
            except Exception as e:
                logger.error(f"خطأ في التحقق من تحديث الألوان الأسبوعية: {e}")
            
            # التحقق كل 6 ساعات
            await asyncio.sleep(6 * 3600)
    
# استخدام فحص دوري بدلًا من tasks.loop


bot = LevelingBot()

class ProfileView(View):
    def __init__(self, ctx):
        super().__init__(timeout=300)  # زيادة وقت الانتظار إلى 5 دقائق
        self.ctx = ctx
        self.add_buttons()

    def add_buttons(self):
        # الصف الأول من الأزرار - الإجراءات الرئيسية
        row1_buttons = [
            ("🎭 الملف الشخصي", discord.ButtonStyle.primary, self.show_profile),
            ("⚡ إضافة XP", discord.ButtonStyle.success, self.add_xp),
            ("💰 المتجر", discord.ButtonStyle.success, self.show_shop),
            ("👑 المتصدرين", discord.ButtonStyle.secondary, self.show_leaderboard)
        ]
        
        # الصف الثاني من الأزرار - إجراءات إضافية
        row2_buttons = [
            ("💼 حقيبتي", discord.ButtonStyle.secondary, self.show_inventory),
            ("🎯 المستوى التالي", discord.ButtonStyle.secondary, self.show_next_level),
            ("💫 الاقتباسات", discord.ButtonStyle.secondary, self.show_quotes),
            ("🏆 التحديات", discord.ButtonStyle.secondary, self.show_challenges)
        ]

        # إضافة أزرار الصف الأول
        for i, (label, style, callback) in enumerate(row1_buttons):
            button = Button(style=style, label=label, row=0)
            button.callback = callback
            self.add_item(button)
            
        # إضافة أزرار الصف الثاني
        for i, (label, style, callback) in enumerate(row2_buttons):
            button = Button(style=style, label=label, row=1)
            button.callback = callback
            self.add_item(button)

        # إضافات خاصة بناءً على مستوى المستخدم
        user_data = bot.get_user_data(str(self.ctx.author.id))
        
        # إضافة زر فتح المستوى 150 إذا كان المستوى 100 أو أعلى
        if user_data["level"] >= 100:
            unlock_button = Button(
                style=discord.ButtonStyle.danger, 
                label="👿 فتح المستوى 150", 
                row=2
            )
            unlock_button.callback = self.unlock_level_150
            self.add_item(unlock_button)
            
        # إضافة زر تحويل العملات إذا كان لديه عملات
        if user_data["coins"] >= 10:
            transfer_button = Button(
                style=discord.ButtonStyle.secondary, 
                label="🔄 تحويل عملات", 
                row=2
            )
            transfer_button.callback = self.transfer_coins
            self.add_item(transfer_button)

    async def show_profile(self, interaction):
        await interaction.response.defer()
        await profile(self.ctx, interaction.user)

    async def add_xp(self, interaction):
        user_data = bot.get_user_data(str(interaction.user.id))
        old_level = user_data["level"]
        user_data["xp"] += 100
        user_data["level"] = bot.calculate_level(user_data["xp"])
        bot.save_data({str(interaction.user.id): user_data})

        remaining_xp = 1000 - (user_data["xp"] % 1000)
        message = f"✨ تم إضافة 100 XP!\n📊 المستوى الحالي: {user_data['level']}\n🎯 XP الحالي: {user_data['xp']:,}\n💫 المتبقي للمستوى التالي: {remaining_xp:,} XP"

        if user_data["level"] > old_level:
            message += f"\n🎉 تهانينا! لقد وصلت للمستوى {user_data['level']}!"

        await interaction.response.send_message(message, ephemeral=True)

    async def remove_xp(self, interaction):
        user_data = bot.get_user_data(str(interaction.user.id))
        if user_data["xp"] >= 100:
            user_data["xp"] -= 100
            user_data["level"] = bot.calculate_level(user_data["xp"])
            bot.save_data({str(interaction.user.id): user_data})
            remaining_xp = 1000 - (user_data["xp"] % 1000)
            await interaction.response.send_message(
                f"💫 تم خصم 100 XP\n"
                f"📊 المستوى الحالي: {user_data['level']}\n"
                f"🎯 XP الحالي: {user_data['xp']:,}\n"
                f"✨ المتبقي للمستوى التالي: {remaining_xp:,} XP",
                ephemeral=True
            )
        else:
            await interaction.response.send_message("❌ رصيدك غير كافٍ!", ephemeral=True)

    async def show_leaderboard(self, interaction):
        await interaction.response.defer()
        await leaderboard(self.ctx)

    async def show_next_level(self, interaction):
        user_data = bot.get_user_data(str(interaction.user.id))
        remaining_xp = 1000 - (user_data["xp"] % 1000)
        await interaction.response.send_message(
            f"🎯 المستوى الحالي: {user_data['level']}\n"
            f"✨ المتبقي للمستوى التالي: {remaining_xp:,} XP",
            ephemeral=True
        )

    async def show_shop(self, interaction):
        """عرض متجر العناصر بطريقة تفاعلية"""
        user_data = bot.get_user_data(str(interaction.user.id))
        
        # إنشاء قائمة بالعناصر المتاحة في المتجر
        embed = discord.Embed(
            title="💰 متجر العناصر",
            description=f"رصيدك الحالي: {user_data['coins']:,} عملة",
            color=discord.Color.from_rgb(255, 215, 0)
        )
        
        # إضافة أقسام المتجر
        for item in bot.shop_items:
            embed.add_field(
                name=f"{item['name']} - {item['price']:,} عملة",
                value=f"{item['description']}\nالنوع: {item['type']}",
                inline=False
            )
        
        # إنشاء أزرار الشراء
        shop_view = View(timeout=120)
        
        for item in bot.shop_items:
            # تعطيل الزر إذا كان رصيد المستخدم غير كافٍ
            disabled = user_data['coins'] < item['price']
            
            button = Button(
                style=discord.ButtonStyle.success if not disabled else discord.ButtonStyle.secondary,
                label=f"شراء {item['name']} ({item['price']:,})",
                disabled=disabled,
                row=item['id'] - 1
            )
            
            # تعريف وظيفة الزر
            async def button_callback(i, item_id=item['id']):
                await self.buy_item(i, item_id)
            
            button.callback = lambda i, item_id=item['id']: button_callback(i, item_id)
            shop_view.add_item(button)
        
        await interaction.response.send_message(embed=embed, view=shop_view, ephemeral=True)
    
    async def buy_item(self, interaction, item_id: int):
        """شراء عنصر من المتجر"""
        user_data = bot.get_user_data(str(interaction.user.id))
        
        # البحث عن العنصر
        item = next((i for i in bot.shop_items if i['id'] == item_id), None)
        if not item:
            await interaction.response.send_message("❌ العنصر غير موجود", ephemeral=True)
            return
        
        # التحقق من كفاية الرصيد
        if user_data['coins'] < item['price']:
            await interaction.response.send_message(
                f"❌ رصيدك غير كافٍ. أنت بحاجة إلى {item['price'] - user_data['coins']:,} عملة إضافية",
                ephemeral=True
            )
            return
        
        # خصم سعر العنصر من الرصيد
        user_data['coins'] -= item['price']
        
        # تنفيذ إجراءات الشراء حسب نوع العنصر
        purchase_message = ""
        
        if item['type'] == "VIP":
            # تفعيل VIP وحساب تاريخ الانتهاء
            user_data['is_vip'] = True
            expiry_date = datetime.now() + timedelta(days=item['duration'])
            user_data['vip_expiry'] = expiry_date.isoformat()
            purchase_message = f"✅ تم تفعيل عضوية VIP حتى {expiry_date.strftime('%Y-%m-%d')}"
            
        elif item['type'] == "COLOR":
            # إضافة العنصر للمخزون
            if 'inventory' not in user_data:
                user_data['inventory'] = []
                
            user_data['inventory'].append({
                'id': len(user_data['inventory']) + 1,
                'type': item['type'],
                'name': item['name'],
                'purchased_at': datetime.now().isoformat()
            })
            
            # عرض قائمة الألوان المتاحة
            color_select = Select(
                placeholder="اختر اللون المفضل لديك",
                options=[
                    discord.SelectOption(label=color_name, value=color_code) 
                    for color_name, color_code in bot.available_colors.items()
                ]
            )
            
            async def color_callback(select_interaction):
                color_name = select_interaction.data['values'][0]
                color_code = bot.available_colors.get(color_name)
                
                if color_code:
                    user_data['color'] = color_code
                    bot.save_data({str(interaction.user.id): user_data})
                    await select_interaction.response.send_message(
                        f"🎨 تم تغيير لونك إلى {color_name}!",
                        ephemeral=True
                    )
            
            color_select.callback = color_callback
            color_view = View()
            color_view.add_item(color_select)
            
            purchase_message = "🎨 تم شراء تغيير اللون. اختر لونك الجديد:"
            await interaction.response.send_message(purchase_message, view=color_view, ephemeral=True)
            
        elif item['type'] == "QUOTE":
            # إضافة قدرة الاقتباس
            purchase_message = "✅ تم شراء قدرة إضافة اقتباس. استخدم الأمر !اضف_اقتباس لإضافة اقتباس جديد"
        
        # حفظ البيانات المحدثة
        bot.save_data({str(interaction.user.id): user_data})
        
        if purchase_message and item['type'] != "COLOR":  # تم التعامل مع COLOR بطريقة خاصة
            await interaction.response.send_message(purchase_message, ephemeral=True)
    
    async def show_inventory(self, interaction):
        """عرض حقيبة المستخدم ومقتنياته"""
        user_data = bot.get_user_data(str(interaction.user.id))
        
        if 'inventory' not in user_data or not user_data['inventory']:
            await interaction.response.send_message("🎒 حقيبتك فارغة! اشترِ عناصر من المتجر.", ephemeral=True)
            return
        
        embed = discord.Embed(
            title="🎒 حقيبتك",
            description=f"العناصر التي تمتلكها ({len(user_data['inventory'])} عنصر)",
            color=discord.Color.from_rgb(61, 90, 128)
        )
        
        # تنظيم العناصر حسب النوع
        item_types = {}
        for item in user_data['inventory']:
            if item['type'] not in item_types:
                item_types[item['type']] = []
            item_types[item['type']].append(item)
        
        # إضافة كل نوع من العناصر إلى الإمبد
        for type_name, items in item_types.items():
            items_list = "\n".join([f"• {item['name']}" for item in items])
            embed.add_field(
                name=f"{type_name} ({len(items)})",
                value=items_list,
                inline=False
            )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    async def show_quotes(self, interaction):
        """عرض اقتباسات المستخدم"""
        user_data = bot.get_user_data(str(interaction.user.id))
        
        if 'quotes' not in user_data or not user_data['quotes']:
            await interaction.response.send_message("📜 ليس لديك اقتباسات بعد! استخدم الأمر !اضف_اقتباس لإضافة اقتباس.", ephemeral=True)
            return
        
        embed = discord.Embed(
            title="📜 اقتباساتك",
            description=f"اقتباساتك المفضلة ({len(user_data['quotes'])} اقتباس)",
            color=discord.Color.from_rgb(75, 123, 236)
        )
        
        # إضافة الاقتباسات إلى الإمبد
        for i, quote in enumerate(user_data['quotes'], 1):
            embed.add_field(
                name=f"اقتباس #{i}",
                value=quote,
                inline=False
            )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    async def show_challenges(self, interaction):
        """عرض التحديات المتاحة للمستخدم"""
        user_data = bot.get_user_data(str(interaction.user.id))
        
        # قائمة بالتحديات حسب مستوى المستخدم
        challenges = [
            {
                "id": 1,
                "name": "إضافة 500 نقطة XP",
                "description": "قم بإضافة 500 نقطة خبرة في يوم واحد",
                "reward": 50,
                "min_level": 1
            },
            {
                "id": 2,
                "name": "شراء 3 عناصر",
                "description": "قم بشراء 3 عناصر مختلفة من المتجر",
                "reward": 100,
                "min_level": 5
            },
            {
                "id": 3,
                "name": "الوصول للمستوى 10",
                "description": "قم بالوصول إلى المستوى 10",
                "reward": 150,
                "min_level": 1
            }
        ]
        
        # فلترة التحديات حسب مستوى المستخدم
        available_challenges = [c for c in challenges if c["min_level"] <= user_data["level"]]
        
        embed = discord.Embed(
            title="🏆 التحديات المتاحة",
            description="أكمل التحديات لكسب المزيد من العملات!",
            color=discord.Color.from_rgb(255, 121, 63)
        )
        
        if not available_challenges:
            embed.add_field(
                name="لا توجد تحديات",
                value="لا توجد تحديات متاحة حالياً. قم بزيادة مستواك للحصول على المزيد من التحديات!",
                inline=False
            )
        else:
            for challenge in available_challenges:
                embed.add_field(
                    name=f"{challenge['name']} (+{challenge['reward']} عملة)",
                    value=challenge["description"],
                    inline=False
                )
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    async def transfer_coins(self, interaction):
        """تحويل عملات إلى مستخدم آخر"""
        modal = discord.ui.Modal(title="🔄 تحويل عملات")
        
        user_id_input = discord.ui.TextInput(
            label="معرف المستخدم",
            placeholder="أدخل معرف المستخدم (الرقم)",
            style=discord.TextStyle.short,
            required=True
        )
        
        amount_input = discord.ui.TextInput(
            label="المبلغ",
            placeholder="أدخل عدد العملات",
            style=discord.TextStyle.short,
            required=True
        )
        
        modal.add_item(user_id_input)
        modal.add_item(amount_input)
        
        async def on_submit(submitted_modal):
            try:
                target_id = submitted_modal.children[0].value
                amount = int(submitted_modal.children[1].value)
                
                # التحقق من سلامة المدخلات
                if amount <= 0:
                    await submitted_modal.response.send_message("❌ يجب أن يكون المبلغ موجباً", ephemeral=True)
                    return
                
                # التحقق من رصيد المستخدم
                sender_data = bot.get_user_data(str(interaction.user.id))
                if sender_data["coins"] < amount:
                    await submitted_modal.response.send_message(
                        f"❌ رصيدك غير كافٍ. لديك {sender_data['coins']:,} عملة فقط.",
                        ephemeral=True
                    )
                    return
                
                # التحقق من وجود المستخدم المستهدف
                try:
                    target_user = await interaction.client.fetch_user(int(target_id))
                    if not target_user:
                        raise ValueError("المستخدم غير موجود")
                except:
                    await submitted_modal.response.send_message("❌ معرف المستخدم غير صالح", ephemeral=True)
                    return
                
                # تحديث بيانات المستخدمين
                receiver_data = bot.get_user_data(target_id)
                
                # خصم العملات من المرسل
                sender_data["coins"] -= amount
                bot.save_data({str(interaction.user.id): sender_data})
                
                # إضافة العملات للمستلم
                receiver_data["coins"] += amount
                bot.save_data({target_id: receiver_data})
                
                # إرسال تأكيد للمرسل
                embed = discord.Embed(
                    title="✅ تم التحويل بنجاح",
                    description=f"تم تحويل {amount:,} عملة إلى {target_user.mention}",
                    color=discord.Color.green()
                )
                embed.add_field(
                    name="رصيدك الحالي",
                    value=f"{sender_data['coins']:,} عملة",
                    inline=True
                )
                
                await submitted_modal.response.send_message(embed=embed, ephemeral=True)
                
                # إرسال إشعار للمستلم
                try:
                    embed_notification = discord.Embed(
                        title="💰 استلمت عملات جديدة!",
                        description=f"{interaction.user.mention} قام بتحويل {amount:,} عملة إليك",
                        color=discord.Color.gold()
                    )
                    await target_user.send(embed=embed_notification)
                except:
                    pass  # تجاهل الأخطاء في حالة عدم قدرة البوت على إرسال رسالة خاصة
                
            except ValueError:
                await submitted_modal.response.send_message("❌ قيمة غير صالحة. تأكد من أن المبلغ عدد صحيح.", ephemeral=True)
            except Exception as e:
                await submitted_modal.response.send_message(f"❌ حدث خطأ: {e}", ephemeral=True)
        
        modal.on_submit = on_submit
        await interaction.response.send_modal(modal)
    
    async def unlock_level_150(self, interaction):
        """فتح المستوى 150 - للمستويات العالية فقط"""
        user_data = bot.get_user_data(str(interaction.user.id))
        if user_data["level"] >= 100:
            embed = discord.Embed(
                title="👿 فتح المستوى 150",
                description="هل أنت متأكد من فتح المستوى 150؟\nستحصل على رتبة الخالد الشيطاني عند الوصول إليه!",
                color=discord.Color.purple()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            # إضافة رتبة جديدة إذا لم تكن موجودة
            role = discord.utils.get(interaction.guild.roles, name="الخالد الشيطاني")
            if role is None:
                role = await interaction.guild.create_role(
                    name="الخالد الشيطاني",
                    color=discord.Color.purple(),
                    reason="فتح المستوى 150"
                )

@bot.command(name="profile")
async def profile(ctx, member: discord.Member = None):
    try:
        member = member or ctx.author
        user_data = bot.get_user_data(str(member.id))

        # تحديد لون البروفايل حسب المستوى
        rank_colors = {
            150: discord.Color.from_rgb(128, 0, 128),  # الخالد الشيطاني - بنفسجي غامق
            100: discord.Color.from_rgb(255, 215, 0),  # خالد - ذهبي
            90: discord.Color.from_rgb(255, 140, 0),   # أسطورة - برتقالي
            80: discord.Color.from_rgb(0, 191, 255),   # محارب عظيم - أزرق سماوي
            70: discord.Color.from_rgb(50, 205, 50),   # محارب متقدم - أخضر
            60: discord.Color.from_rgb(0, 128, 128),   # محارب ماهر - أزرق مخضر
            50: discord.Color.from_rgb(220, 20, 60),   # حامي - أحمر
            40: discord.Color.from_rgb(184, 134, 11),  # قناص - ذهبي داكن
            30: discord.Color.from_rgb(0, 0, 139),     # متمرس - أزرق داكن
            20: discord.Color.from_rgb(0, 100, 0),     # محارب - أخضر داكن
            10: discord.Color.from_rgb(169, 169, 169), # مقاتل - رمادي
            0: discord.Color.from_rgb(88, 101, 242)    # مبتدئ - أزرق ديسكورد
        }

        # تحديد اللون المناسب للمستوى
        embed_color = next((color for level, color in rank_colors.items() 
                          if user_data["level"] >= level), 
                         discord.Color.from_rgb(88, 101, 242))

        # حساب XP للمستوى الحالي والتالي
        current_level_xp = (user_data["level"] - 1) * 1000
        next_level_xp = user_data["level"] * 1000
        current_progress = user_data["xp"] % 1000

        # تحديد الرتبة والصلاحيات بناءً على المستوى
        ranks = {
            150: ("👿 الخالد الشيطاني", discord.Color.purple()),
            100: ("👑 خالد", discord.Color.gold()),
            90: ("🌟 أسطورة", discord.Color.orange()),
            80: ("💫 محارب عظيم", discord.Color.blue()),
            70: ("⚔️ محارب متقدم", discord.Color.green()),
            60: ("🗡️ محارب ماهر", discord.Color.teal()),
            50: ("🛡️ حامي", discord.Color.red()),
            40: ("🏹 قناص", discord.Color.dark_gold()),
            30: ("⚡ متمرس", discord.Color.dark_blue()),
            20: ("🔥 محارب", discord.Color.dark_green()),
            10: ("🌱 مقاتل", discord.Color.greyple()),
            0: ("🎯 مبتدئ", discord.Color.default())
        }

        # تحديد الرتبة الحالية
        current_rank_level = max((level for level in ranks.keys() if user_data["level"] >= level), default=0)
        rank_display, rank_color = ranks[current_rank_level]

        # إضافة رتب السيرفر للمستويات المتقدمة
        if user_data["level"] >= 150 and discord.utils.get(member.roles, name="الخالد الشيطاني") is None:
            demonic_role = discord.utils.get(ctx.guild.roles, name="الخالد الشيطاني")
            if demonic_role is None:
                demonic_role = await ctx.guild.create_role(name="الخالد الشيطاني", color=discord.Color.purple())
            await member.add_roles(demonic_role)
        elif user_data["level"] >= 100 and discord.utils.get(member.roles, name="خالد") is None:
            immortal_role = discord.utils.get(ctx.guild.roles, name="خالد")
            if immortal_role is None:
                immortal_role = await ctx.guild.create_role(name="خالد", color=discord.Color.gold())
            await member.add_roles(immortal_role)

        # إنشاء شريط التقدم
        progress_bar, percentage = bot.generate_xp_bar(user_data["xp"], user_data["level"])

        # إنشاء الإمبد
        embed = discord.Embed(
            title=f"بروفايل {member.display_name}",
            color=embed_color
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(
            name="📊 المستوى والرتبة",
            value=f"**المستوى:** {user_data['level']}\n**الرتبة:** {rank_display}",
            inline=False
        )
        embed.add_field(
            name="✨ نقاط الخبرة",
            value=f"**XP الحالي:** {user_data['xp']:,}\n**XP للمستوى التالي:** {next_level_xp:,}",
            inline=False
        )
        embed.add_field(
            name=f"🎮 التقدم ({percentage}%)",
            value=f"`{progress_bar}`\n{current_progress:,}/{1000:,} XP",
            inline=False
        )

        # رسالة تحفيزية حسب المستوى
        if user_data["level"] in (1, 5, 10, 15, 20, 25, 30, 40, 50, 75, 100):
            embed.add_field(
                name="💬 رسالة",
                value=bot.get_motivational_message(user_data["level"]),
                inline=False
            )

        embed.set_footer(text=f"تم تحديث البيانات • {datetime.now().strftime('%Y-%m-%d %H:%M')}")

        # إنشاء أزرار التفاعل
        view = ProfileView(ctx)
        await ctx.send(embed=embed, view=view)
    except Exception as e:
        logger.error(f"خطأ في عرض البروفايل: {e}")
        await ctx.send(f"❌ حدث خطأ: {e}")

@bot.command(name="addxp_admin")
@commands.has_permissions(administrator=True)
async def add_xp(ctx, member: discord.Member, amount: int):
    """Add XP to another member - Admin only command"""
    try:
        if amount <= 0:
            await ctx.send("❌ The value must be positive")
            return

        user_data = bot.get_user_data(str(member.id))
        old_level = user_data["level"]
        
        # حساب XP الجديد والتحقق من زيادة في VIP
        xp_bonus = 1.2 if user_data.get("is_vip", False) else 1.0
        actual_xp = int(amount * xp_bonus)
        
        user_data["xp"] += actual_xp
        user_data["total_xp"] += actual_xp
        user_data["level"] = bot.calculate_level(user_data["total_xp"])
        
        # إضافة عملات أركانيا
        coins_from_xp = actual_xp // COINS_PER_XP
        user_data["coins"] += coins_from_xp
        
        # بونص إضافي للمستوى الجديد
        if user_data["level"] > old_level:
            level_bonus = LEVEL_BONUS * (user_data["level"] - old_level)
            user_data["coins"] += level_bonus
            
            # تحديث الرتبة إذا لزم الأمر
            old_rank_level = max((level for level in bot.rank_titles.keys() if old_level >= level), default=0)
            new_rank_level = max((level for level in bot.rank_titles.keys() if user_data["level"] >= level), default=0)
            
            if new_rank_level > old_rank_level:
                user_data["rank"] = bot.rank_titles[new_rank_level]
        
        bot.save_data({str(member.id): user_data})

        embed = discord.Embed(
            title="✅ تم إضافة XP",
            description=f"تم إضافة {actual_xp:,} نقطة خبرة لـ {member.mention}",
            color=discord.Color.green()
        )
        embed.add_field(name="📊 المستوى الحالي", value=f"{user_data['level']}", inline=True)
        embed.add_field(name="🎯 XP الإجمالي", value=f"{user_data['total_xp']:,}", inline=True)
        embed.add_field(name="💰 العملات المكتسبة", value=f"{coins_from_xp:,}", inline=True)

        level_bonus = 50  # مكافأة ثابتة للترقية
        
        if user_data["level"] > old_level:
            embed.add_field(
                name="🎉 ترقية!",
                value=f"تهانينا! لقد وصل {member.mention} للمستوى {user_data['level']} من المستوى {old_level}!\n+{level_bonus} عملة إضافية 💰",
                inline=False
            )
            
            # تحديد مستويات الرتب
            old_rank_level = 0
            new_rank_level = 0
            
            # حساب مستوى الرتبة السابق والجديد
            if old_level >= 100:
                old_rank_level = 5
            elif old_level >= 75:
                old_rank_level = 4
            elif old_level >= 50:
                old_rank_level = 3
            elif old_level >= 25:
                old_rank_level = 2
            elif old_level >= 10:
                old_rank_level = 1
                
            if user_data["level"] >= 100:
                new_rank_level = 5
            elif user_data["level"] >= 75:
                new_rank_level = 4
            elif user_data["level"] >= 50:
                new_rank_level = 3
            elif user_data["level"] >= 25:
                new_rank_level = 2
            elif user_data["level"] >= 10:
                new_rank_level = 1
            
            # إذا تغيرت الرتبة
            if old_rank_level < new_rank_level:
                rank_titles = {
                    0: "مبتدئ",
                    1: "متعلم",
                    2: "محارب",
                    3: "بطل",
                    4: "أسطورة",
                    5: "إمبراطور"
                }
                
                embed.add_field(
                    name="🏅 رتبة جديدة!",
                    value=f"تمت ترقيتك إلى رتبة: **{rank_titles[new_rank_level]}**",
                    inline=False
                )

        await ctx.send(embed=embed)
    except Exception as e:
        logger.error(f"خطأ في إضافة XP: {e}")
        await ctx.send(f"❌ حدث خطأ: {e}")
        
# أمر إضافة XP يدويًا (للمستخدم) - باللغة الإنجليزية لتسهيل الاستخدام
@bot.command(name="addxp")
@commands.cooldown(1, 30, commands.BucketType.user)  # cooldown 30 seconds to prevent abuse
async def add_xp_self(ctx, amount: int):
    """Add XP to yourself - Maximum 500 XP per use with 30 second cooldown"""
    try:
        if amount <= 0 or amount > 500:
            await ctx.send("❌ The value must be between 1 and 500")
            return
            
        user_data = bot.get_user_data(str(ctx.author.id))
        old_level = user_data["level"]
        
        # حساب XP والعملات
        xp_bonus = 1.2 if user_data.get("is_vip", False) else 1.0
        actual_xp = int(amount * xp_bonus)
        
        user_data["xp"] += actual_xp
        user_data["total_xp"] += actual_xp
        user_data["level"] = bot.calculate_level(user_data["total_xp"])
        
        # إضافة عملات أركانيا
        coins_earned = actual_xp // COINS_PER_XP
        user_data["coins"] += coins_earned
        
        # بونص المستوى الجديد
        level_bonus = 0
        if user_data["level"] > old_level:
            level_bonus = LEVEL_BONUS * (user_data["level"] - old_level)
            user_data["coins"] += level_bonus
            
            # تحديث الرتبة
            old_rank_level = max((level for level in bot.rank_titles.keys() if old_level >= level), default=0)
            new_rank_level = max((level for level in bot.rank_titles.keys() if user_data["level"] >= level), default=0)
            
            if new_rank_level > old_rank_level:
                user_data["rank"] = bot.rank_titles[new_rank_level]
        
        bot.save_data({str(ctx.author.id): user_data})
        
        # إنشاء الإمبد بالمعلومات
        embed = discord.Embed(
            title="✨ تم إضافة XP",
            description=f"قمت بإضافة {actual_xp:,} نقطة خبرة لنفسك!",
            color=discord.Color.from_rgb(67, 160, 71)
        )
        embed.add_field(name="📊 المستوى", value=f"{user_data['level']}", inline=True)
        embed.add_field(name="💰 العملات المكتسبة", value=f"{coins_earned:,}", inline=True)
        embed.add_field(name="👑 الرتبة", value=f"{user_data['rank']}", inline=True)
        
        # شريط التقدم
        progress_bar, percentage = bot.generate_xp_bar(user_data["total_xp"], user_data["level"])
        embed.add_field(
            name=f"🎮 التقدم ({percentage}%)",
            value=f"`{progress_bar}`",
            inline=False
        )
        
        if level_bonus > 0:
            embed.add_field(
                name="🎁 مكافأة المستوى الجديد",
                value=f"+{level_bonus:,} عملة إضافية! 🎉",
                inline=False
            )
        
        embed.set_footer(text=f"تم التحديث • {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        
        await ctx.send(embed=embed)
    except Exception as e:
        logger.error(f"خطأ في إضافة XP: {e}")
        await ctx.send(f"❌ حدث خطأ: {e}")
        
# أمر عرض المحفظة
@bot.command(name="محفظتي")
async def wallet(ctx):
    try:
        user_data = bot.get_user_data(str(ctx.author.id))
        
        embed = discord.Embed(
            title=f"💰 محفظة {ctx.author.display_name}",
            color=discord.Color.gold()
        )
        
        embed.add_field(name="💸 العملات", value=f"{user_data['coins']:,} عملة أركانيا", inline=False)
        
        # عرض حالة الـ VIP إذا كان نشطًا
        if user_data.get("is_vip", False):
            vip_expiry = datetime.fromisoformat(user_data.get("vip_expiry", datetime.now().isoformat()))
            days_left = (vip_expiry - datetime.now()).days
            embed.add_field(
                name="👑 عضوية VIP",
                value=f"نشطة! متبقي {days_left} يوم",
                inline=False
            )
        
        # عرض العناصر المملوكة
        if "inventory" in user_data and user_data["inventory"]:
            items_text = ""
            for item in user_data["inventory"]:
                items_text += f"• {item['name']}\n"
            embed.add_field(name="🎁 العناصر المملوكة", value=items_text, inline=False)
        else:
            embed.add_field(name="🎁 العناصر المملوكة", value="لا يوجد عناصر بعد", inline=False)
        
        embed.set_thumbnail(url=ctx.author.display_avatar.url)
        embed.set_footer(text=f"استخدم !متجر لشراء عناصر • {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        
        await ctx.send(embed=embed)
    except Exception as e:
        logger.error(f"خطأ في عرض المحفظة: {e}")
        await ctx.send(f"❌ حدث خطأ: {e}")
        
# أمر عرض المتجر
@bot.command(name="متجر")
async def shop(ctx):
    try:
        user_data = bot.get_user_data(str(ctx.author.id))
        
        # إنشاء الإمبد
        embed = discord.Embed(
            title="🛒 متجر أركانيا",
            description=f"رصيدك الحالي: {user_data['coins']:,} عملة\nاستخدم `!شراء <رقم_العنصر>` للشراء أو `!كوبون <كود_الخصم>` لاستخدام كوبون",
            color=discord.Color.from_rgb(233, 30, 99)
        )
        
        # عرض الكوبون النشط إذا وجد
        if "active_coupon" in user_data and user_data["active_coupon"]:
            expiry = datetime.fromisoformat(user_data["active_coupon"]["expiry"])
            if datetime.now() < expiry:
                discount_percent = int(user_data["active_coupon"]["discount"] * 100)
                embed.add_field(
                    name="🏷️ الكوبون النشط",
                    value=f"لديك خصم {discount_percent}% من كوبون `{user_data['active_coupon']['code']}`\nصالح حتى: {expiry.strftime('%H:%M:%S')}",
                    inline=False
                )
        
        # إضافة العناصر الأساسية
        embed.add_field(
            name="🛍️ العناصر الأساسية",
            value="العناصر الدائمة المتوفرة في المتجر",
            inline=False
        )
        
        for item in bot.shop_items:
            duration_text = f"(لمدة {item['duration']} يوم)" if item['duration'] > 0 else "(دائم)"
            embed.add_field(
                name=f"#{item['id']} | {item['name']} - {item['price']:,} عملة",
                value=f"{item['description']} {duration_text}\n`!شراء {item['id']}`",
                inline=True
            )
        
        # إضافة صناديق الحظ
        embed.add_field(
            name="📦 صناديق الحظ",
            value="صناديق عشوائية تحتوي على جوائز مختلفة\nاستخدم `!صندوق <رقم_الصندوق>` للشراء",
            inline=False
        )
        
        for box in bot.random_boxes:
            if "min_level" in box and user_data["level"] < box["min_level"]:
                continue  # تخطي العناصر التي تحتاج لمستوى أعلى
                
            embed.add_field(
                name=f"#{box['id']} | {box['name']} - {box['price']:,} عملة",
                value=f"{box['description']}",
                inline=True
            )
        
        # إضافة معلومات الكوبونات
        embed.add_field(
            name="🏷️ كوبونات الخصم",
            value="استخدم الأمر `!كوبون <كود_الخصم>` للحصول على خصم على مشترياتك",
            inline=False
        )
        
        embed.set_footer(text=f"أركانيا متجر العناصر • {datetime.now().strftime('%Y-%m-%d %H:%M')}")
            
        await ctx.send(embed=embed)
    except Exception as e:
        logger.error(f"خطأ في عرض المتجر: {e}")
        await ctx.send(f"❌ حدث خطأ: {e}")
        
# أمر الشراء من المتجر
@bot.command(name="شراء")
async def buy_item(ctx, item_id: int):
    try:
        user_data = bot.get_user_data(str(ctx.author.id))
        
        # البحث عن العنصر في المتجر
        item = next((item for item in bot.shop_items if item["id"] == item_id), None)
        
        if not item:
            await ctx.send("❌ رقم العنصر غير صحيح. استخدم !متجر لعرض العناصر المتاحة.")
            return
        
        # التحقق من رصيد العملات
        if user_data["coins"] < item["price"]:
            await ctx.send(f"❌ رصيدك غير كافٍ! تحتاج إلى {item['price']:,} عملة لشراء هذا العنصر.")
            return
        
        # خصم العملات
        user_data["coins"] -= item["price"]
        
        # تهيئة inventory إذا لم يكن موجودًا
        if "inventory" not in user_data:
            user_data["inventory"] = []
            
        # تنفيذ عملية الشراء حسب نوع العنصر
        if item["type"] == "VIP":
            # تفعيل عضوية VIP
            user_data["is_vip"] = True
            expiry_date = datetime.now() + timedelta(days=item["duration"])
            user_data["vip_expiry"] = expiry_date.isoformat()
            
            message = f"✅ تم شراء عضوية VIP بنجاح!\n⌛ مدة العضوية: {item['duration']} يوم\n🎁 المزايا: +20% XP، علامة مميزة"
            
        elif item["type"] == "COLOR":
            # إضافة قائمة اختيار الألوان
            color_select = Select(
                placeholder="اختر اللون المناسب",
                options=[
                    discord.SelectOption(label=color_name, value=color_code) 
                    for color_name, color_code in bot.available_colors.items()
                ]
            )
            
            async def color_callback(interaction):
                selected_color = color_select.values[0]
                user_data["color"] = selected_color
                
                # إضافة العنصر للـ inventory
                user_data["inventory"].append({
                    "id": item["id"],
                    "name": f"لون مخصص ({dict(map(reversed, bot.available_colors.items()))[selected_color]})",
                    "type": item["type"],
                    "purchase_date": datetime.now().isoformat()
                })
                
                bot.save_data({str(ctx.author.id): user_data})
                
                await interaction.response.send_message(f"✅ تم تغيير لون ملفك الشخصي بنجاح إلى {dict(map(reversed, bot.available_colors.items()))[selected_color]}!")
            
            color_select.callback = color_callback
            view = View()
            view.add_item(color_select)
            
            await ctx.send(f"✅ تم شراء تغيير اللون بنجاح! اختر اللون المناسب:", view=view)
            bot.save_data({str(ctx.author.id): user_data})
            return
            
        elif item["type"] == "QUOTE":
            # فتح نافذة إضافة اقتباس
            message = f"✅ تم شراء اقتباس بنجاح! استخدم الأمر !اقتباس_جديد لإضافة الاقتباس الخاص بك."
            
            # إضافة العنصر للـ inventory
            user_data["inventory"].append({
                "id": item["id"],
                "name": "اقتباس فارغ",
                "type": item["type"],
                "purchase_date": datetime.now().isoformat()
            })
            
        # حفظ البيانات وعرض رسالة التأكيد
        bot.save_data({str(ctx.author.id): user_data})
        
        embed = discord.Embed(
            title="✅ تمت عملية الشراء بنجاح",
            description=message,
            color=discord.Color.green()
        )
        embed.add_field(name="💰 رصيدك الحالي", value=f"{user_data['coins']:,} عملة", inline=False)
        
        await ctx.send(embed=embed)
    except Exception as e:
        logger.error(f"خطأ في عملية الشراء: {e}")
        await ctx.send(f"❌ حدث خطأ: {e}")
        
# أمر تحويل العملات
@bot.command(name="تحويل")
async def transfer_coins(ctx, member: discord.Member, amount: int):
    try:
        if member.id == ctx.author.id:
            await ctx.send("❌ لا يمكنك تحويل العملات لنفسك!")
            return
            
        if amount <= 0:
            await ctx.send("❌ يجب أن تكون القيمة موجبة")
            return
            
        sender_data = bot.get_user_data(str(ctx.author.id))
        
        # التحقق من رصيد المرسل
        if sender_data["coins"] < amount:
            await ctx.send(f"❌ رصيدك غير كافٍ! لديك فقط {sender_data['coins']:,} عملة.")
            return
            
        # خصم العملات من المرسل
        sender_data["coins"] -= amount
        
        # إضافة العملات للمستلم
        receiver_data = bot.get_user_data(str(member.id))
        receiver_data["coins"] += amount
        
        # حفظ البيانات
        data = bot.load_data()
        data[str(ctx.author.id)] = sender_data
        data[str(member.id)] = receiver_data
        bot.save_data(data)
        
        # تسجيل المعاملة في سجل المعاملات (إذا كان موجودًا)
        if "transactions" not in data:
            data["transactions"] = []
            
        data["transactions"].append({
            "sender": str(ctx.author.id),
            "receiver": str(member.id),
            "amount": amount,
            "type": "TRANSFER",
            "timestamp": datetime.now().isoformat()
        })
        bot.save_data(data)
        
        # عرض رسالة التأكيد
        embed = discord.Embed(
            title="💸 تم تحويل العملات بنجاح",
            color=discord.Color.green()
        )
        embed.add_field(name="👤 المرسل", value=ctx.author.mention, inline=True)
        embed.add_field(name="👥 المستلم", value=member.mention, inline=True)
        embed.add_field(name="💰 المبلغ", value=f"{amount:,} عملة", inline=True)
        embed.add_field(name="💹 الرصيد الحالي", value=f"{sender_data['coins']:,} عملة", inline=False)
        
        await ctx.send(embed=embed)
        
        # إرسال إشعار للمستلم
        try:
            receiver_embed = discord.Embed(
                title="💰 استلمت عملات!",
                description=f"قام {ctx.author.display_name} بتحويل {amount:,} عملة إليك!",
                color=discord.Color.gold()
            )
            await member.send(embed=receiver_embed)
        except:
            pass
            
    except Exception as e:
        logger.error(f"خطأ في تحويل العملات: {e}")
        await ctx.send(f"❌ حدث خطأ: {e}")
        
# أمر إضافة اقتباس
@bot.command(name="اقتباس_جديد")
async def add_quote(ctx, *, quote_text):
    try:
        user_data = bot.get_user_data(str(ctx.author.id))
        
        # التحقق من وجود اقتباسات غير مستخدمة في الـ inventory
        has_quote_item = False
        if "inventory" in user_data:
            for item in user_data["inventory"]:
                if item["type"] == "QUOTE" and item["name"] == "اقتباس فارغ":
                    has_quote_item = True
                    user_data["inventory"].remove(item)
                    break
                    
        if not has_quote_item:
            await ctx.send("❌ يجب أن تشتري اقتباسًا من المتجر أولاً!")
            return
            
        # تهيئة قائمة الاقتباسات إذا لم تكن موجودة
        if "quotes" not in user_data:
            user_data["quotes"] = []
            
        # إضافة الاقتباس
        quote_author = ctx.author.display_name
        user_data["quotes"].append({
            "content": quote_text,
            "author": quote_author,
            "date": datetime.now().isoformat()
        })
        
        # تحديث الـ inventory
        user_data["inventory"].append({
            "id": 3,
            "name": f"اقتباس: {quote_text[:20]}...",
            "type": "QUOTE_USED",
            "purchase_date": datetime.now().isoformat()
        })
        
        # حفظ البيانات
        bot.save_data({str(ctx.author.id): user_data})
        
        # عرض رسالة التأكيد
        embed = discord.Embed(
            title="✅ تمت إضافة الاقتباس بنجاح",
            description=f"\"{quote_text}\"",
            color=discord.Color.blue()
        )
        embed.set_footer(text=f"استخدم !اقتباساتي لعرض اقتباساتك • {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        
        await ctx.send(embed=embed)
        
    except Exception as e:
        logger.error(f"خطأ في إضافة اقتباس: {e}")
        await ctx.send(f"❌ حدث خطأ: {e}")
        
# أمر عرض الاقتباسات
@bot.command(name="اقتباساتي")
async def show_quotes(ctx):
    try:
        user_data = bot.get_user_data(str(ctx.author.id))
        
        if "quotes" not in user_data or not user_data["quotes"]:
            await ctx.send("❌ ليس لديك أي اقتباسات بعد! استخدم !اقتباس_جديد لإضافة اقتباس.")
            return
            
        embed = discord.Embed(
            title="📜 مكتبة الاقتباسات الخاصة بك",
            color=discord.Color.from_rgb(142, 68, 173)
        )
        
        for i, quote in enumerate(user_data["quotes"], 1):
            date = datetime.fromisoformat(quote["date"]).strftime("%Y-%m-%d")
            embed.add_field(
                name=f"اقتباس #{i}",
                value=f"\"{quote['content']}\"\n- {quote['author']} ({date})",
                inline=False
            )
            
        embed.set_footer(text=f"استخدم !اقتباس لعرض اقتباس عشوائي • {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        
        await ctx.send(embed=embed)
        
    except Exception as e:
        logger.error(f"خطأ في عرض الاقتباسات: {e}")
        await ctx.send(f"❌ حدث خطأ: {e}")
        
# أمر عرض اقتباس عشوائي
@bot.command(name="اقتباس")
async def random_quote(ctx):
    try:
        data = bot.load_data()
        all_quotes = []
        
        # جمع جميع الاقتباسات من المستخدمين
        for user_id, user_data in data.items():
            if "quotes" in user_data and user_data["quotes"]:
                for quote in user_data["quotes"]:
                    quote_copy = quote.copy()
                    try:
                        user = await bot.fetch_user(int(user_id))
                        quote_copy["username"] = user.display_name
                    except:
                        quote_copy["username"] = "مستخدم مجهول"
                    all_quotes.append(quote_copy)
                    
        if not all_quotes:
            await ctx.send("❌ لا توجد اقتباسات في النظام بعد!")
            return
            
        # اختيار اقتباس عشوائي
        random_quote = random.choice(all_quotes)
        
        embed = discord.Embed(
            title="💭 اقتباس عشوائي",
            description=f"\"{random_quote['content']}\"",
            color=discord.Color.from_rgb(41, 128, 185)
        )
        
        embed.set_footer(text=f"- {random_quote.get('author', random_quote['username'])}")
        
        await ctx.send(embed=embed)
        
    except Exception as e:
        logger.error(f"خطأ في عرض اقتباس عشوائي: {e}")
        await ctx.send(f"❌ حدث خطأ: {e}")


@bot.command(name="كوبون")
async def redeem_coupon(ctx, coupon_code: str = None):
    """استخدام كوبون خصم للمتجر"""
    try:
        if not coupon_code:
            await ctx.send("❌ يرجى تحديد كود الكوبون. مثال: !كوبون ARKANYA10")
            return
            
        # التحقق من وجود الكوبون
        coupon = bot.coupons.get(coupon_code.upper())
        if not coupon:
            await ctx.send("❌ كود الكوبون غير صالح أو غير موجود.")
            return
            
        # التحقق من عدد الاستخدامات
        if coupon["uses"] >= coupon["max_uses"]:
            await ctx.send("❌ تم استنفاد جميع استخدامات هذا الكوبون.")
            return
            
        # التحقق من تاريخ الانتهاء
        if datetime.now() > datetime.fromisoformat(coupon["expiry"]):
            await ctx.send("❌ انتهت صلاحية هذا الكوبون.")
            return
            
        # الحصول على بيانات المستخدم
        user_data = bot.get_user_data(str(ctx.author.id))
        
        # التحقق من استخدام المستخدم للكوبون من قبل
        if "used_coupons" not in user_data:
            user_data["used_coupons"] = []
            
        if coupon_code.upper() in user_data["used_coupons"]:
            await ctx.send("❌ لقد استخدمت هذا الكوبون بالفعل.")
            return
            
        # إضافة الكوبون لحساب المستخدم
        user_data["used_coupons"].append(coupon_code.upper())
        user_data["active_coupon"] = {
            "code": coupon_code.upper(),
            "discount": coupon["discount"],
            "expiry": (datetime.now() + timedelta(hours=1)).isoformat()  # صالح لمدة ساعة
        }
        
        # زيادة عدد استخدامات الكوبون
        bot.coupons[coupon_code.upper()]["uses"] += 1
        
        # حفظ البيانات
        bot.save_data({str(ctx.author.id): user_data})
        
        # إعداد رسالة التأكيد
        discount_percentage = int(coupon["discount"] * 100)
        embed = discord.Embed(
            title="✅ تم تفعيل الكوبون",
            description=f"تم تفعيل كوبون الخصم `{coupon_code.upper()}` بنسبة {discount_percentage}% على مشترياتك القادمة",
            color=discord.Color.green()
        )
        embed.add_field(
            name="⏱️ مدة الصلاحية",
            value="الكوبون صالح لمدة ساعة واحدة فقط",
            inline=False
        )
        embed.add_field(
            name="💰 كيفية استخدام الخصم",
            value="سيتم تطبيق الخصم تلقائياً عند شرائك لأي عنصر خلال الساعة القادمة",
            inline=False
        )
        
        await ctx.send(embed=embed)
    except Exception as e:
        logger.error(f"خطأ في استخدام الكوبون: {e}")
        await ctx.send(f"❌ حدث خطأ: {e}")


@bot.command(name="صندوق")
async def buy_random_box(ctx, box_id: int = None):
    """شراء صندوق حظ عشوائي"""
    try:
        if box_id is None:
            await ctx.send("❌ يرجى تحديد رقم الصندوق. مثال: !صندوق 10")
            return
            
        # البحث عن الصندوق
        box = next((b for b in bot.random_boxes if b["id"] == box_id), None)
        if not box:
            await ctx.send("❌ رقم الصندوق غير صحيح. يمكنك عرض الصناديق المتاحة باستخدام الأمر !متجر")
            return
            
        # التحقق من مستوى المستخدم
        user_data = bot.get_user_data(str(ctx.author.id))
        if "min_level" in box and user_data["level"] < box["min_level"]:
            await ctx.send(f"❌ يجب أن تكون في المستوى {box['min_level']} على الأقل لشراء هذا الصندوق!")
            return
            
        # التحقق من كفاية الرصيد
        price = box["price"]
        
        # تطبيق خصم الكوبون إذا كان متاحًا
        discount = 0
        if "active_coupon" in user_data and user_data["active_coupon"]:
            coupon_expiry = datetime.fromisoformat(user_data["active_coupon"]["expiry"])
            if datetime.now() < coupon_expiry:
                discount = price * user_data["active_coupon"]["discount"]
                price = int(price - discount)
                
                # إزالة الكوبون بعد استخدامه
                del user_data["active_coupon"]
            else:
                # حذف الكوبون المنتهي
                del user_data["active_coupon"]
            
        if user_data["coins"] < price:
            await ctx.send(f"❌ رصيدك غير كافٍ. أنت بحاجة إلى {price - user_data['coins']:,} عملة إضافية.")
            return
            
        # خصم الرصيد
        user_data["coins"] -= price
        
        # اختيار هدية عشوائية
        rewards = box["possible_rewards"]
        rand_val = random.random()  # قيمة عشوائية بين 0 و 1
        
        cumulative_probability = 0
        selected_reward = None
        
        for reward in rewards:
            cumulative_probability += reward["chance"]
            if rand_val <= cumulative_probability:
                selected_reward = reward
                break
                
        if not selected_reward:  # للتأكد من اختيار هدية
            selected_reward = rewards[-1]
            
        # تطبيق الهدية
        reward_message = ""
        
        if selected_reward["type"] == "COINS":
            coin_amount = selected_reward["amount"]
            user_data["coins"] += coin_amount
            reward_message = f"🎉 مبروك! لقد ربحت {coin_amount:,} عملة!"
            
        elif selected_reward["type"] == "XP":
            xp_amount = selected_reward["amount"]
            old_level = user_data["level"]
            user_data["xp"] += xp_amount
            user_data["total_xp"] = user_data.get("total_xp", user_data["xp"]) + xp_amount
            user_data["level"] = bot.calculate_level(user_data["xp"])
            reward_message = f"🎉 مبروك! لقد ربحت {xp_amount:,} نقطة خبرة!"
            
            if user_data["level"] > old_level:
                reward_message += f"\n⭐ لقد وصلت إلى المستوى {user_data['level']}!"
                
        elif selected_reward["type"] == "COLOR":
            if "inventory" not in user_data:
                user_data["inventory"] = []
                
            user_data["inventory"].append({
                "id": len(user_data["inventory"]) + 1,
                "type": "COLOR",
                "name": "تغيير لون (هدية)",
                "purchased_at": datetime.now().isoformat()
            })
            reward_message = "🎨 مبروك! لقد ربحت خاصية تغيير اللون! استخدم الأمر !لون لتغيير لونك."
            
        elif selected_reward["type"] == "RARE_COLOR":
            # إضافة لون نادر للمستخدم
            rare_colors = {
                "أحمر ناري": "#FF3D00",
                "أزرق مضيء": "#00B0FF",
                "أخضر نيون": "#76FF03",
                "ذهبي لامع": "#FFD700",
                "أرجواني ملكي": "#9C27B0",
                "توركواز مضيء": "#1DE9B6"
            }
            
            rare_color_name, rare_color_code = random.choice(list(rare_colors.items()))
            
            if "inventory" not in user_data:
                user_data["inventory"] = []
                
            user_data["inventory"].append({
                "id": len(user_data["inventory"]) + 1,
                "type": "RARE_COLOR",
                "name": f"لون نادر: {rare_color_name}",
                "color_code": rare_color_code,
                "purchased_at": datetime.now().isoformat()
            })
            reward_message = f"✨✨ مبروك! لقد ربحت لوناً نادراً: {rare_color_name}! استخدم الأمر !لون لتغيير لونك."
            
        elif selected_reward["type"] == "VIP":
            days = selected_reward["days"]
            user_data["is_vip"] = True
            
            if user_data.get("vip_expiry"):
                current_expiry = datetime.fromisoformat(user_data["vip_expiry"])
                new_expiry = current_expiry + timedelta(days=days)
            else:
                new_expiry = datetime.now() + timedelta(days=days)
                
            user_data["vip_expiry"] = new_expiry.isoformat()
            reward_message = f"👑 مبروك! لقد ربحت عضوية VIP لمدة {days} يوم!"
            
        # حفظ البيانات
        bot.save_data({str(ctx.author.id): user_data})
        
        # عرض النتيجة
        embed = discord.Embed(
            title=f"📦 فتح صندوق {box['name']}",
            description=reward_message,
            color=discord.Color.from_rgb(255, 193, 7)
        )
        
        # إظهار معلومات الخصم إذا تم تطبيقه
        if discount > 0:
            discount_percentage = int((discount / box["price"]) * 100)
            embed.add_field(
                name="🏷️ خصم كوبون",
                value=f"تم تطبيق خصم {discount_percentage}% ({discount:,} عملة)",
                inline=True
            )
            
        embed.add_field(
            name="💰 السعر المدفوع",
            value=f"{price:,} عملة",
            inline=True
        )
        
        embed.add_field(
            name="💰 رصيدك الحالي",
            value=f"{user_data['coins']:,} عملة",
            inline=True
        )
        
        embed.set_footer(text=f"استخدم !متجر لعرض المزيد من الصناديق • {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        
        await ctx.send(embed=embed)
    except Exception as e:
        logger.error(f"خطأ في شراء صندوق الحظ: {e}")
        await ctx.send(f"❌ حدث خطأ: {e}")

@bot.command(name="leaderboard")
async def leaderboard(ctx):
    try:
        data = bot.load_data()
        if not data:
            await ctx.send("❌ لا يوجد بيانات متاحة للمتصدرين")
            return

        # تحويل البيانات إلى قائمة وترتيبها
        users_data = [(user_id, user_data) for user_id, user_data in data.items()]
        users_data.sort(key=lambda x: x[1]["xp"], reverse=True)

        # اقتصار القائمة على أعلى 10 مستخدمين
        top_users = users_data[:10]

        # إنشاء إمبد للمتصدرين
        embed = discord.Embed(
            title="🏆 قائمة المتصدرين",
            description="أعلى 10 أعضاء في نقاط الخبرة",
            color=discord.Color.gold()
        )

        # إضافة المستخدمين إلى الإمبد
        for index, (user_id, user_data) in enumerate(top_users, 1):
            try:
                user = await ctx.guild.fetch_member(int(user_id))
                username = user.display_name if user else f"مستخدم #{user_id}"
            except:
                username = f"مستخدم #{user_id}"

            # تنسيق ترتيب المتصدرين بشكل جمالي
            medal = "🥇" if index == 1 else "🥈" if index == 2 else "🥉" if index == 3 else f"{index}."
            embed.add_field(
                name=f"{medal} {username}",
                value=f"**المستوى:** {user_data['level']}\n**XP:** {user_data['xp']:,}",
                inline=False
            )

        embed.set_footer(text=f"تم التحديث • {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        await ctx.send(embed=embed)
    except Exception as e:
        logger.error(f"خطأ في عرض المتصدرين: {e}")
        await ctx.send(f"❌ حدث خطأ: {e}")

@bot.command(name="reset_xp")
@commands.has_permissions(administrator=True)
async def reset_xp(ctx, member: discord.Member):
    try:
        data = bot.load_data()
        if str(member.id) in data:
            # حفظ البيانات القديمة للتأكيد
            old_data = data[str(member.id)]
            old_level = old_data["level"]
            old_xp = old_data["xp"]

            # إعادة تعيين البيانات
            data[str(member.id)] = {"xp": 0, "level": 1, "rank": "مبتدئ"}
            bot.save_data(data)

            embed = discord.Embed(
                title="🔄 إعادة تعيين XP",
                description=f"تم إعادة تعيين نقاط خبرة {member.mention}",
                color=discord.Color.red()
            )
            embed.add_field(name="📊 المستوى القديم", value=f"{old_level}", inline=True)
            embed.add_field(name="🎯 XP القديم", value=f"{old_xp:,}", inline=True)
            embed.add_field(name="✨ الحالة الجديدة", value="المستوى 1 | 0 XP", inline=False)

            await ctx.send(embed=embed)
        else:
            await ctx.send(f"❌ لم يتم العثور على بيانات للمستخدم {member.mention}")
    except Exception as e:
        logger.error(f"خطأ في إعادة تعيين XP: {e}")
        await ctx.send(f"❌ حدث خطأ: {e}")

@bot.event
async def on_message(message):
    # تجاهل رسائل البوت
    if message.author.bot:
        return

    # معالجة الأوامر أولاً
    await bot.process_commands(message)
    
    # لا نضيف XP تلقائيًا عند إرسال الرسائل كما طلب المستخدم
    # التعليق على الكود السابق لمنع إضافة XP تلقائيًا
    """
    try:
        user_id = str(message.author.id)
        user_data = bot.get_user_data(user_id)
        old_level = user_data["level"]

        # إضافة 15-25 XP عشوائي
        import random
        xp_gained = random.randint(15, 25)
        user_data["xp"] += xp_gained
        
        # تحديث المستوى بناءً على XP الجديد
        user_data["level"] = bot.calculate_level(user_data["xp"])
        
        # حفظ البيانات المحدثة
        data = bot.load_data()
        data[user_id] = user_data
        bot.save_data(data)
        
        # إذا ترقى المستخدم للمستوى التالي
        if user_data["level"] > old_level:
            embed = discord.Embed(
                title="🎉 ترقية المستوى!",
                description=f"تهانينا {message.author.mention}! لقد وصلت للمستوى {user_data['level']}!",
                color=discord.Color.gold()
            )
            
            # رسالة تحفيزية للمستويات المميزة
            if user_data["level"] in (1, 5, 10, 15, 20, 25, 30, 40, 50, 75, 100):
                embed.add_field(
                    name="💬 رسالة خاصة",
                    value=bot.get_motivational_message(user_data["level"]),
                    inline=False
                )
                
            # إضافة شريط التقدم
            progress_bar, percentage = bot.generate_xp_bar(user_data["xp"], user_data["level"])
            embed.add_field(
                name=f"🎮 التقدم ({percentage}%)",
                value=f"`{progress_bar}`\n{user_data['xp'] % 1000:,}/{1000:,} XP",
                inline=False
            )
            
            await message.channel.send(embed=embed)
    except Exception as e:
        logger.error(f"خطأ في معالجة XP للرسالة: {e}")
    """

@bot.command(name="help")
async def help_command(ctx, category=None):
    if category is None:
        # عرض القائمة الرئيسية للأوامر
        embed = discord.Embed(
            title="🌟 دليل أوامر بوت أركانيا",
            description="مرحبًا بك في نظام أركانيا للمستويات والاقتصاد! اختر فئة من الفئات التالية للحصول على معلومات مفصلة:",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="📋 فئات الأوامر المتاحة",
            value=(
                "**!help profile** - أوامر الملف الشخصي والحساب\n"
                "**!help levels** - أوامر المستويات والخبرة\n"
                "**!help economy** - أوامر الاقتصاد والعملات\n"
                "**!help shop** - أوامر المتجر والتسوق\n"
                "**!help colors** - أوامر الألوان وتخصيص المظهر\n"
                "**!help quotes** - أوامر الاقتباسات\n"
                "**!help clan** - أوامر العشيرة والحروب\n"
                "**!help admin** - أوامر الإدارة (تتطلب صلاحيات)"
            ),
            inline=False
        )
        
        # معلومات النظام
        embed.add_field(
            name="💡 معلومات النظام",
            value=(
                "• كل **1000 XP** = مستوى واحد\n"
                "• كل **10 XP** = عملة أركانيا واحدة\n"
                "• ترقية المستوى = **50 عملة** إضافية\n"
                "• عضوية VIP = **+20%** على XP المكتسب\n"
                "• تحصل على ألقاب وألوان مميزة كل 10 مستويات\n"
                "• يتم تحديث قائمة الألوان كل يوم سبت بشكل تلقائي"
            ),
            inline=False
        )
        
        embed.set_footer(text=f"بوت أركانيا • {datetime.now().strftime('%Y-%m-%d %H:%M')} • استخدم !help <اسم الفئة> للمزيد من المعلومات")

    elif category.lower() == "profile":
        # أوامر الملف الشخصي
        embed = discord.Embed(
            title="👤 أوامر الملف الشخصي",
            description="جميع الأوامر المتعلقة بالملف الشخصي والحساب:",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="الأوامر المتاحة",
            value=(
                "**!profile** - عرض ملفك الشخصي بشكل تفاعلي\n"
                "**!profile <member>** - عرض ملف شخص آخر\n"
                "**!inventory** - عرض حقيبتك ومقتنياتك\n"
                "**!next_level** - عرض معلومات المستوى التالي والمكافآت\n"
                "**!challenges** - عرض التحديات المتاحة لك حاليًا"
            ),
            inline=False
        )
        
        embed.add_field(
            name="نصائح",
            value="- استخدم الأزرار التفاعلية في الملف الشخصي للوصول إلى جميع الميزات\n- يمكنك تغيير لون الملف الشخصي من خلال المتجر",
            inline=False
        )
    
    elif category.lower() == "levels" or category.lower() == "xp":
        # أوامر المستويات والخبرة
        embed = discord.Embed(
            title="🏆 أوامر المستويات و XP",
            description="جميع الأوامر المتعلقة بنظام المستويات والخبرة:",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="الأوامر المتاحة",
            value=(
                "**!leaderboard** - عرض قائمة المتصدرين في المستويات\n"
                "**!addxp <amount>** - إضافة XP لنفسك (الحد الأقصى 500)\n"
                "**!next_level** - عرض متطلبات وصولك للمستوى التالي\n"
                "**!rank <member>** - عرض مستوى ورتبة شخص آخر"
            ),
            inline=False
        )
        
        embed.add_field(
            name="نصائح",
            value="- يمكنك الحصول على XP من خلال التفاعل في الدردشة\n- عضوية VIP تزيد معدل اكتساب XP بنسبة 20%",
            inline=False
        )
        
    elif category.lower() == "economy":
        # أوامر الاقتصاد
        embed = discord.Embed(
            title="💰 أوامر الاقتصاد والعملات",
            description="جميع الأوامر المتعلقة بالعملات والموارد:",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="الأوامر المتاحة",
            value=(
                "**!محفظتي** - عرض رصيدك من العملات\n"
                "**!تحويل <member> <amount>** - تحويل عملات لعضو آخر\n"
                "**!daily** - الحصول على المكافأة اليومية\n"
                "**!bank** - عرض معلومات بنك العملات الخاص بك"
            ),
            inline=False
        )
        
        embed.add_field(
            name="نصائح",
            value="- يمكنك كسب عملات بمعدل 1 عملة لكل 10 نقاط خبرة\n- ترقية المستوى تمنحك 50 عملة إضافية\n- راقب العروض الخاصة في المتجر للحصول على خصومات",
            inline=False
        )
        
    elif category.lower() == "shop":
        # أوامر المتجر
        embed = discord.Embed(
            title="🛒 أوامر المتجر والتسوق",
            description="جميع الأوامر المتعلقة بالمتجر والشراء:",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="الأوامر المتاحة",
            value=(
                "**!متجر** - عرض المتجر وقائمة العناصر للشراء\n"
                "**!شراء <item_id>** - شراء عنصر من المتجر\n"
                "**!كوبون <code>** - استخدام كوبون خصم في المتجر\n"
                "**!صندوق <box_id>** - شراء وفتح صندوق حظ عشوائي\n"
                "**!عروض** - عرض العروض الخاصة والخصومات الحالية"
            ),
            inline=False
        )
        
        embed.add_field(
            name="نصائح",
            value="- تتجدد العروض كل أسبوع\n- الصناديق العشوائية قد تحتوي على عناصر نادرة\n- استخدم الكوبونات للحصول على خصومات إضافية",
            inline=False
        )
        
    elif category.lower() == "colors":
        # أوامر الألوان
        embed = discord.Embed(
            title="🎨 أوامر الألوان وتخصيص المظهر",
            description="جميع الأوامر المتعلقة بتخصيص الألوان والمظهر:",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="الأوامر المتاحة",
            value=(
                "**!colors** - عرض الألوان المتاحة حاليًا\n"
                "**!set_profile_color <color_id>** - تغيير لون الملف الشخصي\n"
                "**!set_text_color <color_id>** - تغيير لون النص في الملف الشخصي\n"
                "**!preview_color <color_id>** - معاينة شكل اللون قبل الشراء\n"
                "**!latest_colors** - عرض أحدث الألوان الأسبوعية"
            ),
            inline=False
        )
        
        embed.add_field(
            name="معلومات هامة",
            value="- يتم تحديث الألوان المتاحة كل يوم سبت بشكل عشوائي\n- بعض الألوان متاحة فقط لأصحاب المستويات العالية أو عضوية VIP\n- يمكنك شراء ألوان دائمة أو مؤقتة بأسعار مختلفة",
            inline=False
        )
        
    elif category.lower() == "quotes":
        # أوامر الاقتباسات
        embed = discord.Embed(
            title="📜 أوامر الاقتباسات",
            description="جميع الأوامر المتعلقة بنظام الاقتباسات:",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="الأوامر المتاحة",
            value=(
                "**!اقتباس** - عرض اقتباس عشوائي من مكتبة الاقتباسات\n"
                "**!اقتباس_جديد <نص الاقتباس>** - إضافة اقتباس جديد إلى مكتبتك\n"
                "**!اقتباساتي** - عرض قائمة الاقتباسات الخاصة بك\n"
                "**!احذف_اقتباس <id>** - حذف اقتباس من مكتبتك\n"
                "**!اقتباسات_السيرفر** - عرض أفضل اقتباسات السيرفر"
            ),
            inline=False
        )
        
        embed.add_field(
            name="نصائح",
            value="- يمكنك تزيين اقتباساتك بألوان مختلفة عند شراء ميزة 'ألوان الاقتباسات' من المتجر\n- الاقتباسات المميزة تظهر بشكل أكبر في قائمة اقتباسات السيرفر",
            inline=False
        )
        
    elif category.lower() == "clan" or category.lower() == "clans":
        # أوامر العشيرة
        embed = discord.Embed(
            title="⚔️ أوامر العشيرة والحروب",
            description="جميع الأوامر المتعلقة بنظام العشائر وحروب العشائر:",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="أوامر العشيرة الأساسية",
            value=(
                "**!clan create <name>** - إنشاء عشيرة جديدة\n"
                "**!clan info** - عرض معلومات عشيرتك\n"
                "**!clan join <id>** - الانضمام إلى عشيرة\n"
                "**!clan leave** - مغادرة العشيرة الحالية\n"
                "**!clan members** - عرض أعضاء العشيرة\n"
                "**!clan rank** - عرض تصنيف العشائر"
            ),
            inline=False
        )
        
        embed.add_field(
            name="أوامر إدارة العشيرة",
            value=(
                "**!clan invite <member>** - دعوة عضو للانضمام للعشيرة\n"
                "**!clan kick <member>** - طرد عضو من العشيرة\n"
                "**!clan promote <member>** - ترقية عضو في العشيرة\n"
                "**!clan demote <member>** - تخفيض رتبة عضو في العشيرة\n"
                "**!clan rename <new_name>** - تغيير اسم العشيرة\n"
                "**!clan icon <url>** - تغيير شعار العشيرة"
            ),
            inline=False
        )
        
        embed.add_field(
            name="أوامر حروب العشائر",
            value=(
                "**!clan war start <clan_id>** - بدء حرب عشائر\n"
                "**!clan war info** - عرض معلومات الحرب الحالية\n"
                "**!clan war task** - عرض المهام المطلوبة في الحرب\n"
                "**!clan war stats** - عرض إحصائيات حروب العشيرة\n"
                "**!clan war history** - عرض سجل حروب العشيرة السابقة"
            ),
            inline=False
        )
        
        embed.add_field(
            name="أوامر موارد العشيرة",
            value=(
                "**!clan resources** - عرض موارد العشيرة\n"
                "**!clan donate <amount>** - التبرع بعملات للعشيرة\n"
                "**!clan upgrade <feature>** - ترقية ميزة في العشيرة\n"
                "**!clan shop** - عرض متجر العشيرة\n"
                "**!clan buy <item_id>** - شراء عنصر من متجر العشيرة"
            ),
            inline=False
        )
        
    elif category.lower() == "admin":
        # أوامر الإدارة
        embed = discord.Embed(
            title="👑 أوامر الإدارة",
            description="هذه الأوامر متاحة فقط لمن لديهم صلاحيات إدارية:",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="أوامر إدارة المستويات",
            value=(
                "**!add_xp <member> <amount>** - إضافة XP لعضو\n"
                "**!remove_xp <member> <amount>** - إزالة XP من عضو\n"
                "**!reset_xp <member>** - إعادة تعيين XP لعضو\n"
                "**!set_level <member> <level>** - تعيين مستوى محدد لعضو"
            ),
            inline=False
        )
        
        embed.add_field(
            name="أوامر إدارة الاقتصاد",
            value=(
                "**!add_coins <member> <amount>** - إضافة عملات لعضو\n"
                "**!remove_coins <member> <amount>** - إزالة عملات من عضو\n"
                "**!create_coupon <code> <discount> <uses>** - إنشاء كوبون خصم\n"
                "**!delete_coupon <code>** - حذف كوبون خصم"
            ),
            inline=False
        )
        
        embed.add_field(
            name="أوامر إدارة النظام",
            value=(
                "**!reset_weekly_colors** - تحديث الألوان الأسبوعية يدويًا\n"
                "**!add_shop_item** - إضافة عنصر جديد للمتجر\n"
                "**!remove_shop_item <item_id>** - إزالة عنصر من المتجر\n"
                "**!backup_data** - عمل نسخة احتياطية من بيانات النظام"
            ),
            inline=False
        )
        
    else:
        # إذا تم إدخال فئة غير صحيحة
        embed = discord.Embed(
            title="❓ فئة غير معروفة",
            description=f"الفئة '{category}' غير موجودة. يرجى استخدام `!help` لعرض قائمة الفئات المتاحة.",
            color=discord.Color.red()
        )
    
    await ctx.send(embed=embed)

@bot.command(name="colors")
async def colors_command(ctx, action=None):

    """عرض الألوان المتاحة حاليًا في النظام"""
    if action == "refresh" and ctx.author.guild_permissions.administrator:
        # تحديث الألوان الأسبوعية يدويًا (للمشرفين فقط)
        await bot.update_weekly_colors()
        await ctx.send("✅ تم تحديث قائمة الألوان الأسبوعية بنجاح!")
        return
    
    embed = discord.Embed(
        title="🎨 الألوان المتاحة في نظام أركانيا",
        description=(
            "يمكنك استخدام هذه الألوان لتخصيص ملفك الشخصي واقتباساتك. "
            "لشراء أحد الألوان، استخدم `!متجر` ثم اشترِ عنصر 'تغيير لون'."
        ),
        color=discord.Color.from_rgb(255, 215, 0)
    )
    
    # عرض الألوان الثابتة المتاحة دائمًا
    embed.add_field(
        name="🌈 الألوان الأساسية",
        value=(
            "الألوان التالية متاحة دائمًا للاختيار:\n" +
            "\n".join([f"• **{name}** (`{code}`)" for name, code in bot.available_colors.items()])
        ),
        inline=False
    )
    
    # عرض الألوان الأسبوعية المتجددة
    if hasattr(bot, 'weekly_colors') and bot.weekly_colors:
        embed.add_field(
            name="✨ الألوان الأسبوعية الخاصة",
            value=(
                "هذه الألوان تتجدد أسبوعيًا كل يوم سبت:\n" +
                "\n".join([f"• **{name}** (`{code}`)" for name, code in bot.weekly_colors.items()]) +
                "\n\n🕒 تاريخ التحديث القادم: {next_update}"
            ).format(
                next_update=get_next_saturday().strftime("%Y-%m-%d")
            ),
            inline=False
        )
    
    # للمستويات المتقدمة
    user_data = bot.get_user_data(str(ctx.author.id))
    if user_data["level"] >= 50:
        embed.add_field(
            name="👑 ألوان المستويات العالية",
            value=(
                "هذه الألوان متاحة فقط لأصحاب المستويات 50 فما فوق:\n"
                "• **ذهبي ملكي** (`#FFD700`)\n"
                "• **لازوردي** (`#0000CD`)\n"
                "• **قرمزي** (`#DC143C`)\n"
                "• **زمردي** (`#50C878`)"
            ),
            inline=False
        )
    
    # للعضوية المميزة
    if user_data.get("is_vip", False):
        embed.add_field(
            name="💎 ألوان VIP الحصرية",
            value=(
                "هذه الألوان متاحة فقط لأعضاء VIP:\n"
                "• **ألماسي** (`#B9F2FF`)\n"
                "• **قوس قزح** (متغير)\n"
                "• **نيون** (`#39FF14`)\n"
                "• **غروب الشمس** (متدرج)\n"
                "• **فضائي** (`#3D0066`)"
            ),
            inline=False
        )
    
    # معاينة الألوان
    embed.add_field(
        name="🔍 معاينة الألوان",
        value=(
            "لمعاينة أي لون قبل الشراء، استخدم الأمر التالي:\n"
            "`!preview_color <color_code>`\n"
            "مثال: `!preview_color #FF5733`"
        ),
        inline=False
    )
    
    await ctx.send(embed=embed)

@bot.command(name="preview_color")
async def preview_color_command(ctx, color_code: str):

    """معاينة اللون قبل الشراء"""
    try:
        # التحقق من صحة كود اللون
        if not color_code.startswith('#') or len(color_code) != 7:
            await ctx.send("❌ صيغة اللون غير صحيحة. يجب أن يبدأ بـ # ويتكون من 6 أرقام/حروف. مثال: `#FF5733`")
            return
        
        # استخراج قيم RGB
        hex_color = color_code.lstrip('#')
        r, g, b = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        
        # إنشاء عرض معاينة للون
        embed = discord.Embed(
            title=f"🎨 معاينة اللون: {color_code}",
            description=(
                f"**RGB**: ({r}, {g}, {b})\n"
                f"**HEX**: {color_code.upper()}\n\n"
                "هذا هو شكل اللون في العناصر المختلفة:"
            ),
            color=discord.Color.from_rgb(r, g, b)
        )
        
        embed.add_field(
            name="استخدامات اللون",
            value=(
                "• خلفية الملف الشخصي\n"
                "• لون النص في الاقتباسات\n"
                "• تمييز اسمك في قائمة المتصدرين\n"
                "• شريط التقدم في المستويات"
            ),
            inline=False
        )
        
        # اسم مقترح للون بناءً على قيمه
        color_name = "لون مخصص"
        if r > 200 and g < 100 and b < 100:
            color_name = "أحمر"
        elif r < 100 and g > 200 and b < 100:
            color_name = "أخضر"
        elif r < 100 and g < 100 and b > 200:
            color_name = "أزرق"
        elif r > 200 and g > 200 and b < 100:
            color_name = "أصفر"
        elif r > 200 and g > 150 and b < 100:
            color_name = "برتقالي"
        elif r > 200 and g < 100 and b > 200:
            color_name = "وردي"
        elif r > 150 and g > 150 and b > 150:
            color_name = "رمادي فاتح" if r > 200 else "رمادي"
        elif r < 100 and g < 100 and b < 100:
            color_name = "أسود"
        
        embed.add_field(
            name="الاسم المقترح",
            value=f"**{color_name}**",
            inline=False
        )
        
        await ctx.send(embed=embed)
    except Exception as e:
        logger.error(f"خطأ في معاينة اللون: {e}")
        await ctx.send("❌ حدث خطأ أثناء معاينة اللون. تأكد من صيغة اللون الصحيحة (مثال: `#FF5733`).")

@bot.command(name="set_profile_color")
async def set_profile_color_command(ctx, color_code: str):

    """تعيين لون الملف الشخصي"""
    user_data = bot.get_user_data(str(ctx.author.id))
    
    # التحقق من امتلاك العنصر
    has_color_item = False
    if 'inventory' in user_data:
        for item in user_data['inventory']:
            if item['type'] == 'COLOR':
                has_color_item = True
                break
    
    if not has_color_item:
        await ctx.send("❌ يجب عليك شراء عنصر 'تغيير لون' من المتجر أولاً!")
        return
    
    # التحقق من صحة كود اللون
    if not color_code.startswith('#') or len(color_code) != 7:
        await ctx.send("❌ صيغة اللون غير صحيحة. يجب أن يبدأ بـ # ويتكون من 6 أرقام/حروف. مثال: `#FF5733`")
        return
    
    # التحقق من أن اللون متاح للمستخدم
    available_colors = set(bot.available_colors.values())
    if hasattr(bot, 'weekly_colors'):
        available_colors.update(set(bot.weekly_colors.values()))
    
    # ألوان خاصة للمستويات العالية
    if user_data["level"] >= 50:
        available_colors.update(["#FFD700", "#0000CD", "#DC143C", "#50C878"])
    
    # ألوان خاصة للـ VIP
    if user_data.get("is_vip", False):
        available_colors.update(["#B9F2FF", "#39FF14", "#3D0066"])
    
    if color_code.upper() not in [c.upper() for c in available_colors]:
        await ctx.send("❌ هذا اللون غير متاح لك! استخدم `!colors` لعرض الألوان المتاحة.")
        return
    
    # تحديث لون الملف الشخصي
    user_data['color'] = color_code
    bot.save_data({str(ctx.author.id): user_data})
    
    # تأكيد التغيير
    await ctx.send(f"✅ تم تغيير لون ملفك الشخصي بنجاح إلى {color_code}!")

@bot.command(name="latest_colors")
async def latest_colors_command(ctx):

    """عرض آخر الألوان المضافة أسبوعيًا"""
    if not hasattr(bot, 'weekly_colors') or not bot.weekly_colors:
        await ctx.send("⚠️ لم يتم تحديث الألوان الأسبوعية بعد. تفضل بالعودة يوم السبت!")
        return
    
    last_update = "غير معروف"
    if bot.last_color_update:
        last_update = datetime.fromisoformat(bot.last_color_update).strftime("%Y-%m-%d %H:%M")
    
    embed = discord.Embed(
        title="✨ أحدث الألوان الأسبوعية",
        description=f"تم تحديث هذه الألوان في: {last_update}\nالتحديث القادم: {get_next_saturday().strftime('%Y-%m-%d')}",
        color=discord.Color.from_rgb(255, 215, 0)
    )
    
    # إضافة الألوان الأسبوعية إلى الإمبد
    for i, (name, code) in enumerate(bot.weekly_colors.items()):
        # استخراج قيم RGB
        hex_color = code.lstrip('#')
        r, g, b = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        
        embed.add_field(
            name=f"{i+1}. {name}",
            value=f"كود اللون: `{code}`",
            inline=True
        )
    
    # إضافة كيفية الشراء
    embed.add_field(
        name="كيفية الحصول على اللون",
        value=(
            "1. اشترِ عنصر 'تغيير لون' من المتجر باستخدام `!متجر`\n"
            "2. استخدم الأمر `!set_profile_color <color_code>` لتعيين اللون"
        ),
        inline=False
    )
    
    await ctx.send(embed=embed)

# دالة مساعدة للحصول على تاريخ السبت القادم
def get_next_saturday():
    today = datetime.now()
    days_until_saturday = (5 - today.weekday()) % 7  # 5 هو رقم السبت في Python
    if days_until_saturday == 0:  # إذا كان اليوم هو السبت
        # إذا كنا بالفعل في يوم سبت، فسيكون السبت القادم بعد 7 أيام
        days_until_saturday = 7
    next_saturday = today + timedelta(days=days_until_saturday)
    return next_saturday

@bot.command(name="reset_weekly_colors")
@commands.has_permissions(administrator=True)
async def reset_weekly_colors_command(ctx):

    """أمر إداري لإعادة تعيين الألوان الأسبوعية"""
    await bot.update_weekly_colors()
    await ctx.send("✅ تم تحديث الألوان الأسبوعية بنجاح!")

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.errors.MissingPermissions):
        await ctx.send("❌ ليس لديك الصلاحيات الكافية لاستخدام هذا الأمر!")
    elif isinstance(error, commands.errors.MissingRequiredArgument):
        await ctx.send("❌ أحد المعلمات المطلوبة مفقودة. استخدم !help للحصول على المساعدة.")
    elif isinstance(error, commands.errors.CommandNotFound):
        pass  # تجاهل أخطاء الأوامر غير الموجودة
    else:
        logger.error(f"خطأ في الأمر: {error}")
        await ctx.send(f"❌ حدث خطأ: {error}")

async def start_bot():
    try:
        await bot.start(TOKEN)
    except Exception as e:
        logger.error(f"خطأ في بدء تشغيل البوت: {e}")

if __name__ == "__main__":
    import asyncio
    loop = asyncio.get_event_loop()
    loop.run_until_complete(start_bot())
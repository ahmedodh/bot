import { pgTable, serial, text, integer, timestamp, boolean, pgEnum, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// جدول المستخدمين
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// جدول الأوامر
export const commands = pgTable("commands", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull(),
  usage: text("usage").default("").notNull(),
  category: text("category").default("general").notNull(),
  enabled: boolean("enabled").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// جدول السجلات
export const logs = pgTable("logs", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(),
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// جدول الإحصائيات
export const stats = pgTable("stats", {
  id: serial("id").primaryKey(),
  uptime: integer("uptime").default(0).notNull(),
  commandsUsed: integer("commands_used").default(0).notNull(),
  serverCount: integer("server_count").default(0).notNull(),
  memoryUsage: integer("memory_usage").default(0).notNull(),
  latency: integer("latency").default(0).notNull(),
  apiCalls: integer("api_calls").default(0).notNull(),
  aiInteractions: integer("ai_interactions").default(0).notNull(),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

// تعريف أنواع المهام
export const taskTypeEnum = pgEnum("task_type", ["daily", "group", "skill"]);

// جدول المهام
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  serverId: text("server_id").notNull(),
  description: text("description").notNull(),
  type: taskTypeEnum("type").notNull(),
  points: integer("points").notNull(),
  expectedTime: integer("expected_time").notNull(), // بالدقائق
  completed: boolean("completed").default(false).notNull(),
  timeSpent: integer("time_spent"), // الوقت المستغرق بالدقائق (يملأ عند الإكمال)
  deadline: timestamp("deadline"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

// جدول العشائر
export const clans = pgTable("clans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  leaderId: text("leader_id").notNull(),
  description: text("description"),
  logoUrl: text("logo_url"),
  treasury: integer("treasury").default(0).notNull(), // خزينة العشيرة
  level: integer("level").default(1).notNull(),
  experience: integer("experience").default(0).notNull(),
  memberCount: integer("member_count").default(1).notNull(),
  consecutiveWins: integer("consecutive_wins").default(0).notNull(), // عدد الانتصارات المتتالية
  blacklisted: boolean("blacklisted").default(false).notNull(), // هل العشيرة في اللائحة السوداء
  specialChallengesRemaining: integer("special_challenges_remaining").default(1).notNull(), // عدد التحديات الخاصة المتبقية
  lastSpecialChallengeDate: timestamp("last_special_challenge_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// جدول أعضاء العشيرة
export const clanMembers = pgTable("clan_members", {
  id: serial("id").primaryKey(),
  clanId: integer("clan_id").notNull(),
  userId: text("user_id").notNull(),
  role: text("role").default("member").notNull(), // leader, officer, member
  contributions: integer("contributions").default(0).notNull(), // مساهمات العضو (تبرعات، مهام، الخ)
  tasksCompleted: integer("tasks_completed").default(0).notNull(),
  donationAmount: integer("donation_amount").default(0).notNull(),
  joinDate: timestamp("join_date").defaultNow().notNull(),
});

// تبرعات العشيرة
export const clanDonations = pgTable("clan_donations", {
  id: serial("id").primaryKey(),
  clanId: integer("clan_id").notNull(),
  userId: text("user_id").notNull(),
  amount: integer("amount").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// طلبات ترقية الأعضاء
export const promotionRequests = pgTable("promotion_requests", {
  id: serial("id").primaryKey(),
  clanId: integer("clan_id").notNull(),
  userId: text("user_id").notNull(),
  currentRole: text("current_role").notNull(),
  requestedRole: text("requested_role").notNull(),
  reason: text("reason"),
  status: text("status").default("pending").notNull(), // pending, approved, rejected
  reviewerId: text("reviewer_id"),
  reviewTimestamp: timestamp("review_timestamp"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// جدول تحديات العشيرة (مهام جماعية)
export const clanChallenges = pgTable("clan_challenges", {
  id: serial("id").primaryKey(),
  clanId: integer("clan_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  points: integer("points").notNull(),
  requiredMembers: integer("required_members").notNull(),
  currentMembers: integer("current_members").default(0).notNull(),
  deadline: timestamp("deadline").notNull(),
  completed: boolean("completed").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  isSpecial: boolean("is_special").default(false), // للتحديات الخاصة
  specialType: text("special_type"), // نوع التحدي الخاص
});

// جدول إحصائيات الإنتاجية
export const productivityStats = pgTable("productivity_stats", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  dailyTasksCompleted: integer("daily_tasks_completed").default(0).notNull(),
  groupTasksCompleted: integer("group_tasks_completed").default(0).notNull(),
  skillTasksCompleted: integer("skill_tasks_completed").default(0).notNull(),
  totalPointsEarned: integer("total_points_earned").default(0).notNull(),
  averageCompletionTime: integer("average_completion_time").default(0).notNull(), // متوسط الوقت المستغرق بالدقائق
  streak: integer("streak").default(0).notNull(), // عدد الأيام المتتالية التي أكمل فيها مهمة واحدة على الأقل
  lastActiveDate: timestamp("last_active_date").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// جدول الإنجازات والشارات
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull(),
  iconUrl: text("icon_url").notNull(),
  requiredPoints: integer("required_points").notNull(),
  type: text("type").notNull(), // morning_star, efficiency_expert, productivity_leader, etc.
  rarity: text("rarity").notNull(), // common, rare, epic, legendary
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// جدول إنجازات المستخدمين
export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  achievementId: integer("achievement_id").notNull(),
  earnedAt: timestamp("earned_at").defaultNow().notNull(),
});

// جدول محادثات الذكاء الاصطناعي
export const aiConversations = pgTable("ai_conversations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  model: text("model").notNull(), // gpt-4o, gpt-4, gpt-3.5-turbo
  feedback: text("feedback"), // positive, negative
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// جدول الصور المنشأة
export const generatedImages = pgTable("generated_images", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  prompt: text("prompt").notNull(),
  imageUrl: text("image_url").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// جدول تحسينات الكود
export const improvedCodes = pgTable("improved_codes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  originalCode: text("original_code").notNull(),
  improvedCode: text("improved_code").notNull(),
  explanation: text("explanation").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// جدول توصيات الأوامر التكيفية
export const commandRecommendations = pgTable("command_recommendations", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(), // معرف المستخدم في Discord
  contextPattern: text("context_pattern").notNull(), // نمط سياق استخدام الأمر
  commandId: integer("command_id").notNull(), // معرف الأمر الموصى به
  weight: integer("weight").default(10).notNull(), // وزن الأهمية (يزداد مع الاستخدام)
  usageCount: integer("usage_count").default(1).notNull(), // عدد مرات الاستخدام
  lastUsed: timestamp("last_used").defaultNow().notNull(), // آخر استخدام
  isPersonalized: boolean("is_personalized").default(false).notNull(), // هل التوصية مخصصة لهذا المستخدم فقط
  metadata: jsonb("metadata"), // بيانات إضافية مثل نتائج التعلم الآلي
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// مخططات Zod للإدخال
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertCommandSchema = createInsertSchema(commands).omit({ id: true });
export const insertLogSchema = createInsertSchema(logs).omit({ id: true });
export const insertStatsSchema = createInsertSchema(stats).omit({ id: true });
export const insertTaskSchema = createInsertSchema(tasks).omit({ id: true, completedAt: true });
export const insertClanSchema = createInsertSchema(clans).omit({ id: true });
export const insertClanMemberSchema = createInsertSchema(clanMembers).omit({ id: true });
export const insertClanDonationSchema = createInsertSchema(clanDonations).omit({ id: true });
export const insertPromotionRequestSchema = createInsertSchema(promotionRequests).omit({ id: true, reviewTimestamp: true });
export const insertClanChallengeSchema = createInsertSchema(clanChallenges).omit({ id: true, completedAt: true });
export const insertProductivityStatsSchema = createInsertSchema(productivityStats).omit({ id: true });
export const insertAchievementSchema = createInsertSchema(achievements).omit({ id: true });
export const insertUserAchievementSchema = createInsertSchema(userAchievements).omit({ id: true });
export const insertAiConversationSchema = createInsertSchema(aiConversations).omit({ id: true });
export const insertGeneratedImageSchema = createInsertSchema(generatedImages).omit({ id: true });
export const insertImprovedCodeSchema = createInsertSchema(improvedCodes).omit({ id: true });
export const insertCommandRecommendationSchema = createInsertSchema(commandRecommendations).omit({ id: true });

// أنواع الإدخال
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertCommand = z.infer<typeof insertCommandSchema>;
export type InsertLog = z.infer<typeof insertLogSchema>;
export type InsertStats = z.infer<typeof insertStatsSchema>;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type InsertClan = z.infer<typeof insertClanSchema>;
export type InsertClanMember = z.infer<typeof insertClanMemberSchema>;
export type InsertClanDonation = z.infer<typeof insertClanDonationSchema>;
export type InsertPromotionRequest = z.infer<typeof insertPromotionRequestSchema>;
export type InsertClanChallenge = z.infer<typeof insertClanChallengeSchema>;
export type InsertProductivityStats = z.infer<typeof insertProductivityStatsSchema>;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;
export type InsertAiConversation = z.infer<typeof insertAiConversationSchema>;
export type InsertGeneratedImage = z.infer<typeof insertGeneratedImageSchema>;
export type InsertImprovedCode = z.infer<typeof insertImprovedCodeSchema>;

// أنواع الاختيار
export type User = typeof users.$inferSelect;
export type Command = typeof commands.$inferSelect;
export type Log = typeof logs.$inferSelect;
export type Stats = typeof stats.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type Clan = typeof clans.$inferSelect;
export type ClanMember = typeof clanMembers.$inferSelect;
export type ClanDonation = typeof clanDonations.$inferSelect;
export type PromotionRequest = typeof promotionRequests.$inferSelect;
export type ClanChallenge = typeof clanChallenges.$inferSelect;
export type ProductivityStats = typeof productivityStats.$inferSelect;
export type Achievement = typeof achievements.$inferSelect;
export type UserAchievement = typeof userAchievements.$inferSelect;
export type AiConversation = typeof aiConversations.$inferSelect;
export type GeneratedImage = typeof generatedImages.$inferSelect;
export type ImprovedCode = typeof improvedCodes.$inferSelect;
export type CommandRecommendation = typeof commandRecommendations.$inferSelect;
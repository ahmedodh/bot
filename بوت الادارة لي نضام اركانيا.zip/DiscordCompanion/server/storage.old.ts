import { 
  users, type User, type InsertUser,
  commands, type Command, type InsertCommand,
  logs, type Log, type InsertLog,
  stats, type Stats, type InsertStats
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

// واجهة التخزين لإدارة التعامل مع قاعدة البيانات
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Command methods
  getCommand(id: number): Promise<Command | undefined>;
  getCommandByName(name: string): Promise<Command | undefined>;
  getAllCommands(): Promise<Command[]>;
  createCommand(command: InsertCommand): Promise<Command>;
  updateCommand(id: number, command: Partial<InsertCommand>): Promise<Command | undefined>;
  deleteCommand(id: number): Promise<boolean>;

  // Log methods
  createLog(log: InsertLog): Promise<Log>;
  getLogs(limit?: number): Promise<Log[]>;
  clearLogs(): Promise<void>;

  // Stats methods
  getStats(): Promise<Stats | undefined>;
  updateStats(stats: Partial<InsertStats>): Promise<Stats | undefined>;
  
  // إذا كانت الفئة هي DatabaseStorage، قم بإضافة وظيفة التهيئة
  initializeDatabase?(): Promise<void>;
}

// فئة التخزين في قاعدة البيانات
export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Command methods
  async getCommand(id: number): Promise<Command | undefined> {
    const [command] = await db.select().from(commands).where(eq(commands.id, id));
    return command || undefined;
  }

  async getCommandByName(name: string): Promise<Command | undefined> {
    const [command] = await db.select().from(commands).where(eq(commands.name, name));
    return command || undefined;
  }

  async getAllCommands(): Promise<Command[]> {
    return await db.select().from(commands);
  }

  async createCommand(insertCommand: InsertCommand): Promise<Command> {
    const [command] = await db
      .insert(commands)
      .values(insertCommand)
      .returning();
    return command;
  }

  async updateCommand(id: number, commandUpdate: Partial<InsertCommand>): Promise<Command | undefined> {
    const [updatedCommand] = await db
      .update(commands)
      .set(commandUpdate)
      .where(eq(commands.id, id))
      .returning();
    return updatedCommand || undefined;
  }

  async deleteCommand(id: number): Promise<boolean> {
    const result = await db.delete(commands).where(eq(commands.id, id));
    // تحويل النتيجة إلى قيمة منطقية
    return !!result;
  }

  // Log methods
  async createLog(insertLog: InsertLog): Promise<Log> {
    const [log] = await db
      .insert(logs)
      .values(insertLog)
      .returning();
    return log;
  }

  async getLogs(limit: number = 50): Promise<Log[]> {
    return await db
      .select()
      .from(logs)
      .orderBy(desc(logs.timestamp))
      .limit(limit);
  }

  async clearLogs(): Promise<void> {
    await db.delete(logs);
  }

  // Stats methods
  async getStats(): Promise<Stats | undefined> {
    const [stat] = await db.select().from(stats);
    return stat || undefined;
  }

  async updateStats(statsUpdate: Partial<InsertStats>): Promise<Stats | undefined> {
    const currentStats = await this.getStats();
    
    if (!currentStats) {
      // إذا لم تكن هناك إحصائيات موجودة، قم بإنشاء سجل جديد
      const [newStats] = await db
        .insert(stats)
        .values({
          uptime: statsUpdate.uptime || 0,
          commandsUsed: statsUpdate.commandsUsed || 0,
          serverCount: statsUpdate.serverCount || 0,
          memoryUsage: statsUpdate.memoryUsage || 0,
          latency: statsUpdate.latency || 0,
          apiCalls: statsUpdate.apiCalls || 0,
        })
        .returning();
      return newStats;
    } else {
      // تحديث السجل الموجود
      const [updatedStats] = await db
        .update(stats)
        .set({
          ...statsUpdate,
          lastUpdated: sql`NOW()`,
        })
        .where(eq(stats.id, currentStats.id))
        .returning();
      return updatedStats;
    }
  }

  // تهيئة قاعدة البيانات بالبيانات الافتراضية
  async initializeDatabase(): Promise<void> {
    // التحقق من وجود الأوامر الافتراضية
    const existingCommands = await this.getAllCommands();
    
    if (existingCommands.length === 0) {
      // إضافة الأوامر الافتراضية
      const defaultCommands: InsertCommand[] = [
        { name: "!help", description: "Shows all commands", enabled: true },
        { name: "!ping", description: "Check bot latency", enabled: true },
        { name: "!play", description: "Play music from URL", enabled: true },
        { name: "!kick", description: "Kick a user", enabled: true }
      ];

      for (const cmd of defaultCommands) {
        await this.createCommand(cmd);
      }
    }

    // التحقق من وجود الإحصائيات الافتراضية
    const existingStats = await this.getStats();
    
    if (!existingStats) {
      // إنشاء إحصائيات افتراضية
      await db.insert(stats).values({
        uptime: 0,
        commandsUsed: 0,
        serverCount: 0,
        memoryUsage: 0,
        latency: 0,
        apiCalls: 0,
      });
    }
  }
}

// استخدام التخزين في قاعدة البيانات
export const storage = new DatabaseStorage();
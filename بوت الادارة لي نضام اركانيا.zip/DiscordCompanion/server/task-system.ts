/**
 * نظام المهام والإنتاجية
 * 
 * هذا الملف يحتوي على المنطق الخاص بنظام المهام وتحفيز الإنتاجية
 * وفقًا للمواصفات المطلوبة للنظام
 */

import { db } from "./db";
import { tasks, productivityStats, achievements, userAchievements, taskTypeEnum } from "@shared/schema";
import { eq, and, gte, lte, desc, sql } from "drizzle-orm";

/**
 * حساب النقاط لمهمة معينة بناءً على نوعها والوقت المستغرق
 * @param taskType نوع المهمة (يومية، جماعية، مهارة)
 * @param timeSpent الوقت المستغرق بالدقائق
 * @param expectedTime الوقت المتوقع للإنجاز
 * @returns عدد النقاط المكتسبة
 */
export function calculatePoints(
  taskType: "daily" | "group" | "skill",
  timeSpent: number,
  expectedTime: number,
  repetitionFactor: number = 1
): number {
  // القيم الأساسية للنقاط حسب نوع المهمة
  const basePoints = {
    daily: 10,
    group: 50,
    skill: 30
  };

  // خصم نقاط إذا تجاوز الوقت المطلوب
  const timePenalty = timeSpent > expectedTime ? Math.min(Math.floor((timeSpent - expectedTime) / 15), 5) : 0;
  
  // حساب النقاط النهائية مع مراعاة عامل التكرار
  const finalPoints = Math.max(
    Math.floor(basePoints[taskType] * (1 - (repetitionFactor - 1) * 0.2) - timePenalty),
    1 // الحد الأدنى للنقاط هو 1
  );
  
  return finalPoints;
}

/**
 * إنشاء مهمة جديدة
 * @param userId معرف المستخدم
 * @param serverId معرف السيرفر
 * @param description وصف المهمة
 * @param type نوع المهمة
 * @param expectedTime الوقت المتوقع للإنجاز (بالدقائق)
 * @param deadline موعد الانتهاء (اختياري)
 */
export async function createTask(
  userId: number,
  serverId: string,
  description: string,
  type: "daily" | "group" | "skill",
  expectedTime: number,
  deadline?: Date
) {
  try {
    // التحقق من عدد المهام اليومية (لا يمكن تجاوز 5 مهام يوميًا لكل مستخدم)
    if (type === "daily") {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      
      const dailyTasksCount = await db
        .select({ count: sql<number>`count(*)` })
        .from(tasks)
        .where(
          and(
            eq(tasks.userId, userId),
            eq(tasks.type, "daily"),
            gte(tasks.createdAt, today),
            lte(tasks.createdAt, tomorrow)
          )
        );
      
      if (dailyTasksCount[0].count >= 5) {
        throw new Error("لقد وصلت إلى الحد الأقصى من المهام اليومية (5 مهام)");
      }
    }
    
    // حساب عدد المهام المماثلة لمعرفة عامل التكرار
    const similarTasksCount = await db
      .select({ count: sql<number>`count(*)` })
      .from(tasks)
      .where(
        and(
          eq(tasks.userId, userId),
          eq(tasks.description, description)
        )
      );
    
    const repetitionFactor = Math.min(similarTasksCount[0].count + 1, 5);
    
    // حساب النقاط المتوقعة
    const points = calculatePoints(type, 0, expectedTime, repetitionFactor);
    
    // إنشاء المهمة
    const [newTask] = await db
      .insert(tasks)
      .values({
        userId,
        serverId,
        description,
        type,
        points,
        expectedTime,
        deadline: deadline || null,
        completed: false,
        timeSpent: null,
        completedAt: null
      })
      .returning();
    
    return newTask;
  } catch (error) {
    console.error("خطأ في إنشاء المهمة:", error);
    throw error;
  }
}

/**
 * إكمال مهمة
 * @param taskId معرف المهمة
 * @param timeSpent الوقت المستغرق (بالدقائق)
 */
export async function completeTask(taskId: number, timeSpent: number) {
  try {
    // الحصول على المهمة
    const [task] = await db
      .select()
      .from(tasks)
      .where(eq(tasks.id, taskId));
    
    if (!task) {
      throw new Error("المهمة غير موجودة");
    }
    
    if (task.completed) {
      throw new Error("تم إكمال هذه المهمة بالفعل");
    }
    
    // حساب النقاط النهائية بناءً على الوقت المستغرق
    const finalPoints = calculatePoints(
      task.type as "daily" | "group" | "skill", 
      timeSpent, 
      task.expectedTime
    );
    
    // تحديث المهمة
    const [updatedTask] = await db
      .update(tasks)
      .set({
        completed: true,
        timeSpent,
        completedAt: new Date(),
        points: finalPoints // تحديث النقاط بناءً على الوقت المستغرق
      })
      .where(eq(tasks.id, taskId))
      .returning();
    
    // تحديث إحصائيات الإنتاجية للمستخدم
    await updateProductivityStats(task.userId, task.type as "daily" | "group" | "skill", finalPoints, timeSpent);
    
    // التحقق من الإنجازات
    await checkAchievements(task.userId);
    
    return updatedTask;
  } catch (error) {
    console.error("خطأ في إكمال المهمة:", error);
    throw error;
  }
}

/**
 * تحديث إحصائيات الإنتاجية للمستخدم
 * @param userId معرف المستخدم
 * @param taskType نوع المهمة
 * @param points النقاط المكتسبة
 * @param timeSpent الوقت المستغرق
 */
async function updateProductivityStats(
  userId: number,
  taskType: "daily" | "group" | "skill",
  points: number,
  timeSpent: number
) {
  try {
    // التحقق مما إذا كان لدى المستخدم إحصائيات سابقة
    const userStats = await db
      .select()
      .from(productivityStats)
      .where(eq(productivityStats.userId, userId));
    
    if (userStats.length === 0) {
      // إنشاء إحصائيات جديدة
      await db.insert(productivityStats).values({
        userId,
        dailyTasksCompleted: taskType === "daily" ? 1 : 0,
        groupTasksCompleted: taskType === "group" ? 1 : 0,
        skillTasksCompleted: taskType === "skill" ? 1 : 0,
        totalPointsEarned: points,
        averageCompletionTime: timeSpent,
        streak: 1,
        lastActiveDate: new Date()
      });
    } else {
      const stats = userStats[0];
      
      // التحقق من التتابع (السلسلة)
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const lastActiveDate = new Date(stats.lastActiveDate);
      lastActiveDate.setHours(0, 0, 0, 0);
      
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      
      // تحديث التتابع
      let newStreak = stats.streak;
      if (lastActiveDate.getTime() === yesterday.getTime()) {
        // اليوم الماضي نشط، زيادة التتابع
        newStreak += 1;
      } else if (lastActiveDate.getTime() < yesterday.getTime()) {
        // انقطع التتابع، إعادة ضبط
        newStreak = 1;
      }
      // إذا كان نشطًا اليوم، لا تغيير في التتابع
      
      // حساب متوسط وقت الإكمال الجديد
      const totalTasks = stats.dailyTasksCompleted + stats.groupTasksCompleted + stats.skillTasksCompleted;
      const newAverageCompletionTime = Math.round(
        (stats.averageCompletionTime * totalTasks + timeSpent) / (totalTasks + 1)
      );
      
      // تحديث الإحصائيات
      await db.update(productivityStats)
        .set({
          dailyTasksCompleted: taskType === "daily" ? stats.dailyTasksCompleted + 1 : stats.dailyTasksCompleted,
          groupTasksCompleted: taskType === "group" ? stats.groupTasksCompleted + 1 : stats.groupTasksCompleted,
          skillTasksCompleted: taskType === "skill" ? stats.skillTasksCompleted + 1 : stats.skillTasksCompleted,
          totalPointsEarned: stats.totalPointsEarned + points,
          averageCompletionTime: newAverageCompletionTime,
          streak: newStreak,
          lastActiveDate: new Date(),
          updatedAt: new Date()
        })
        .where(eq(productivityStats.userId, userId));
    }
  } catch (error) {
    console.error("خطأ في تحديث إحصائيات الإنتاجية:", error);
    throw error;
  }
}

/**
 * التحقق من الإنجازات وتحديثها
 * @param userId معرف المستخدم
 */
async function checkAchievements(userId: number) {
  try {
    // الحصول على إحصائيات المستخدم
    const [stats] = await db
      .select()
      .from(productivityStats)
      .where(eq(productivityStats.userId, userId));
    
    if (!stats) {
      return; // لا توجد إحصائيات بعد
    }
    
    // الحصول على جميع الإنجازات المتاحة
    const allAchievements = await db.select().from(achievements);
    
    // الحصول على إنجازات المستخدم الحالية
    const userCurrentAchievements = await db
      .select({
        achievementId: userAchievements.achievementId
      })
      .from(userAchievements)
      .where(eq(userAchievements.userId, userId));
    
    const currentAchievementIds = userCurrentAchievements.map(a => a.achievementId);
    
    // التحقق من الإنجازات الجديدة
    const newAchievements: typeof allAchievements = [];
    
    for (const achievement of allAchievements) {
      if (currentAchievementIds.includes(achievement.id)) {
        continue; // المستخدم لديه هذا الإنجاز بالفعل
      }
      
      let achieved = false;
      
      // التحقق من شروط الإنجاز حسب النوع
      switch (achievement.type) {
        case 'morning_star':
          // نجم الصباح - إكمال 3 مهام قبل الظهر
          if (stats.dailyTasksCompleted >= 3) {
            // للتبسيط، نفترض أنه إذا أكمل 3 مهام على الأقل، فسيحصل على الإنجاز
            achieved = true;
          }
          break;
          
        case 'efficiency_expert':
          // خبير الكفاءة - جمع 200 نقطة أسبوعيًا
          if (stats.totalPointsEarned >= 200) {
            achieved = true;
          }
          break;
          
        case 'productivity_leader':
          // قائد الإنتاجية - تتطلب منطقًا إضافيًا يتعلق بترتيب العشيرة
          // سنقوم بتنفيذ ذلك لاحقًا
          break;
          
        case 'focus_master':
          // سيد التركيز - إكمال مهمة بدون انحراف عن الوقت المخطط
          // نستخدم متوسط وقت الإكمال كمؤشر
          if (stats.averageCompletionTime <= 45) {
            achieved = true;
          }
          break;
          
        case 'streak_keeper':
          // الحفاظ على التتابع - استمرار في إكمال المهام لعدة أيام متتالية
          if (stats.streak >= 7) {
            achieved = true;
          }
          break;
          
        // يمكن إضافة المزيد من أنواع الإنجازات هنا
      }
      
      // إذا تم تحقيق الإنجاز، أضفه إلى القائمة
      if (achieved) {
        newAchievements.push(achievement);
      }
    }
    
    // إضافة الإنجازات الجديدة للمستخدم
    for (const achievement of newAchievements) {
      await db.insert(userAchievements).values({
        userId,
        achievementId: achievement.id,
        earnedAt: new Date()
      });
    }
    
    return newAchievements;
  } catch (error) {
    console.error("خطأ في التحقق من الإنجازات:", error);
    throw error;
  }
}

/**
 * تنفيذ "نظام الإجازات" - إذا لم يكمل المستخدم أي مهمة لمدة 3 أيام
 * @param userId معرف المستخدم
 */
export async function checkUserInactivity(userId: number) {
  try {
    // الحصول على آخر إحصائيات المستخدم
    const [stats] = await db
      .select()
      .from(productivityStats)
      .where(eq(productivityStats.userId, userId));
    
    if (!stats) {
      return null; // لا توجد إحصائيات بعد
    }
    
    const lastActiveDate = new Date(stats.lastActiveDate);
    const today = new Date();
    
    // حساب الفرق بالأيام
    const diffTime = Math.abs(today.getTime() - lastActiveDate.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays >= 3) {
      // المستخدم غير نشط لمدة 3 أيام أو أكثر
      return {
        inactiveFor: diffDays,
        message: "هل تحتاج إلى استراحة؟ اختر إجازة لمدة 24 ساعة دون خسارة النقاط! 🍃"
      };
    }
    
    return null; // المستخدم نشط
  } catch (error) {
    console.error("خطأ في التحقق من عدم نشاط المستخدم:", error);
    throw error;
  }
}

/**
 * إنشاء مهمة مقترحة بناءً على عادات المستخدم
 * @param userId معرف المستخدم
 */
export async function generateSuggestedTask(userId: number) {
  try {
    // الحصول على إحصائيات المستخدم
    const [stats] = await db
      .select()
      .from(productivityStats)
      .where(eq(productivityStats.userId, userId));
    
    if (!stats) {
      // إذا لم تكن هناك إحصائيات، تقديم اقتراح عام
      return {
        description: "أكمل مهمة صغيرة في 15 دقيقة",
        type: "daily",
        expectedTime: 15
      };
    }
    
    // تحديد ما إذا كان المستخدم أبطأ في الصباح أو المساء
    // للتبسيط، نستخدم متوسط وقت الإكمال
    const isSlowInMorning = stats.averageCompletionTime > 45;
    
    if (isSlowInMorning) {
      return {
        description: "أنهِ 3 مهام مسائية",
        type: "daily",
        expectedTime: 45
      };
    } else {
      return {
        description: "أنهِ مهمتين قبل الظهر",
        type: "daily",
        expectedTime: 30
      };
    }
  } catch (error) {
    console.error("خطأ في إنشاء مهمة مقترحة:", error);
    throw error;
  }
}

/**
 * الحصول على ترتيب المستخدمين حسب النقاط
 * @param limit عدد المستخدمين المراد إظهارهم
 */
export async function getUsersLeaderboard(limit: number = 10) {
  try {
    const leaderboard = await db
      .select({
        userId: productivityStats.userId,
        totalPoints: productivityStats.totalPointsEarned,
        streak: productivityStats.streak,
        tasksCompleted: sql<number>`(${productivityStats.dailyTasksCompleted} + ${productivityStats.groupTasksCompleted} + ${productivityStats.skillTasksCompleted})`
      })
      .from(productivityStats)
      .orderBy(desc(productivityStats.totalPointsEarned))
      .limit(limit);
    
    return leaderboard;
  } catch (error) {
    console.error("خطأ في الحصول على ترتيب المستخدمين:", error);
    throw error;
  }
}

/**
 * تعديل صعوبة المهام ديناميكيًا بناءً على أداء المستخدم
 * @param userId معرف المستخدم
 */
export async function adjustTaskDifficulty(userId: number) {
  try {
    // الحصول على إحصائيات المستخدم
    const [stats] = await db
      .select()
      .from(productivityStats)
      .where(eq(productivityStats.userId, userId));
    
    if (!stats) {
      return false; // لا توجد إحصائيات بعد
    }
    
    // الحصول على مهام المستخدم في الأسبوع الماضي
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    
    const recentTasks = await db
      .select()
      .from(tasks)
      .where(
        and(
          eq(tasks.userId, userId),
          gte(tasks.createdAt, oneWeekAgo)
        )
      );
    
    // حساب نسبة الإنجاز (المهام المكتملة / إجمالي المهام)
    const totalTasks = recentTasks.length;
    if (totalTasks === 0) {
      return false; // لا توجد مهام في الأسبوع الماضي
    }
    
    const completedTasks = recentTasks.filter(task => task.completed).length;
    const completionRate = completedTasks / totalTasks;
    
    // إذا كانت نسبة الإنجاز عالية (90% أو أكثر)، زيادة الصعوبة
    if (completionRate >= 0.9) {
      return {
        increaseDifficulty: true,
        completionRate,
        message: "أداؤك ممتاز! سنزيد تدريجيًا من صعوبة المهام القادمة بنسبة 10% لمساعدتك على التطور."
      };
    }
    
    // إذا كانت نسبة الإنجاز منخفضة (أقل من 50%)، تقليل الصعوبة
    if (completionRate < 0.5) {
      return {
        increaseDifficulty: false,
        completionRate,
        message: "نلاحظ بعض التحديات في إكمال المهام. سنقلل قليلاً من صعوبة المهام القادمة لمساعدتك على التقدم."
      };
    }
    
    return {
      increaseDifficulty: null,
      completionRate,
      message: "أنت تسير بوتيرة جيدة. استمر في العمل الجيد!"
    };
  } catch (error) {
    console.error("خطأ في تعديل صعوبة المهام:", error);
    throw error;
  }
}
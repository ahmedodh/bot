import { Client, Events } from 'discord.js';
import { storage } from '../storage';

// Setup event handlers for the bot
export function setupEvents(client: Client) {
  // When the bot is ready
  client.once(Events.ClientReady, async () => {
    console.log(`Logged in as ${client.user?.tag}`);
    
    // Log the bot startup
    await storage.createLog({
      type: 'info',
      message: `Bot started and ready as ${client.user?.tag}`
    });
    
    // Update stats with server count
    const stats = await storage.getStats();
    if (stats) {
      await storage.updateStats({
        serverCount: client.guilds.cache.size
      });
    }
  });
  
  // When the bot joins a server
  client.on(Events.GuildCreate, async (guild) => {
    console.log(`Joined a new guild: ${guild.name}`);
    
    // Log the event
    await storage.createLog({
      type: 'info',
      message: `Bot joined server '${guild.name}'`
    });
    
    // Update server count
    const stats = await storage.getStats();
    if (stats) {
      await storage.updateStats({
        serverCount: client.guilds.cache.size
      });
    }
  });
  
  // When the bot leaves a server
  client.on(Events.GuildDelete, async (guild) => {
    console.log(`Left a guild: ${guild.name}`);
    
    // Log the event
    await storage.createLog({
      type: 'info',
      message: `Bot left server '${guild.name}'`
    });
    
    // Update server count
    const stats = await storage.getStats();
    if (stats) {
      await storage.updateStats({
        serverCount: client.guilds.cache.size
      });
    }
  });
  
  // Error handling
  client.on(Events.Error, async (error) => {
    console.error('Discord client error:', error);
    
    // Log the error
    await storage.createLog({
      type: 'error',
      message: `Discord client error: ${error.message}`
    });
  });
  
  // When a member joins a server
  client.on(Events.GuildMemberAdd, async (member) => {
    // Log the event
    await storage.createLog({
      type: 'info',
      message: `User '${member.user.tag}' joined server '${member.guild.name}'`
    });
    
    // You could implement welcome messages here
    const welcomeChannel = member.guild.systemChannel;
    if (welcomeChannel) {
      try {
        await welcomeChannel.send(`Welcome to the server, ${member}!`);
      } catch (error) {
        console.error('Error sending welcome message:', error);
        
        // Log the error
        await storage.createLog({
          type: 'error',
          message: `Error sending welcome message: ${error}`
        });
      }
    }
  });
  
  // Rate limit warnings
  client.on(Events.RateLimit, async (rateLimitData) => {
    console.warn('Rate limit hit:', rateLimitData);
    
    // Log the warning
    await storage.createLog({
      type: 'warning',
      message: `Rate limit approaching for Discord API (${rateLimitData.timeout}ms timeout, route: ${rateLimitData.route})`
    });
  });
}

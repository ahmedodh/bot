import { Client, Collection, Message } from 'discord.js';
import { storage } from '../storage';

// Command type definition
type BotCommand = {
  name: string;
  description: string;
  execute: (message: Message, args: string[]) => Promise<void>;
};

// Setup commands for the bot
export function setupCommands(client: Client) {
  client.commands = new Collection<string, BotCommand>();
  
  // Define commands
  const helpCommand: BotCommand = {
    name: 'help',
    description: 'Shows all commands',
    execute: async (message, args) => {
      try {
        const commands = await storage.getAllCommands();
        const enabledCommands = commands.filter(cmd => cmd.enabled);
        
        let helpMessage = '**Available Commands:**\n';
        enabledCommands.forEach(cmd => {
          helpMessage += `\`${cmd.name}\` - ${cmd.description}\n`;
        });
        
        await message.reply(helpMessage);
        
        // Log command usage
        await storage.createLog({
          type: 'command',
          message: `Command '!help' used in ${message.channel.name}`
        });
      } catch (error) {
        console.error('Error executing help command:', error);
        await message.reply('There was an error trying to execute that command!');
        
        // Log error
        await storage.createLog({
          type: 'error',
          message: `Error executing help command: ${error}`
        });
      }
    }
  };
  
  const pingCommand: BotCommand = {
    name: 'ping',
    description: 'Check bot latency',
    execute: async (message, args) => {
      try {
        const sentMessage = await message.channel.send('Pinging...');
        const pingTime = sentMessage.createdTimestamp - message.createdTimestamp;
        
        await sentMessage.edit(`Pong! Bot Latency: ${pingTime}ms | API Latency: ${client.ws.ping}ms`);
        
        // Log command usage
        await storage.createLog({
          type: 'command',
          message: `Command '!ping' used in ${message.channel.name}`
        });
      } catch (error) {
        console.error('Error executing ping command:', error);
        await message.reply('There was an error trying to execute that command!');
        
        // Log error
        await storage.createLog({
          type: 'error',
          message: `Error executing ping command: ${error}`
        });
      }
    }
  };
  
  const kickCommand: BotCommand = {
    name: 'kick',
    description: 'Kick a user',
    execute: async (message, args) => {
      try {
        // Check if the user has permission
        if (!message.member?.permissions.has('KickMembers')) {
          await message.reply('You do not have permission to use this command.');
          return;
        }
        
        // Check if a user was mentioned
        const user = message.mentions.users.first();
        if (!user) {
          await message.reply('You need to mention a user to kick them.');
          return;
        }
        
        // Get the member
        const member = message.guild?.members.cache.get(user.id);
        if (!member) {
          await message.reply('That user is not in this server.');
          return;
        }
        
        // Check if the bot can kick the member
        if (!member.kickable) {
          await message.reply('I cannot kick this user. Do I have the proper permissions?');
          return;
        }
        
        // Kick the member
        const reason = args.slice(1).join(' ') || 'No reason provided';
        await member.kick(reason);
        await message.reply(`Successfully kicked ${user.tag} for reason: ${reason}`);
        
        // Log command usage
        await storage.createLog({
          type: 'command',
          message: `Command '!kick' used in ${message.channel.name} to kick ${user.tag}`
        });
      } catch (error) {
        console.error('Error executing kick command:', error);
        await message.reply('There was an error trying to execute that command!');
        
        // Log error
        await storage.createLog({
          type: 'error',
          message: `Error executing kick command: ${error}`
        });
      }
    }
  };
  
  const playCommand: BotCommand = {
    name: 'play',
    description: 'Play music from URL',
    execute: async (message, args) => {
      try {
        // This is a simplified version since actual music playing would require additional libraries
        if (!args.length) {
          await message.reply('Please provide a URL to play music.');
          return;
        }
        
        const voiceChannel = message.member?.voice.channel;
        if (!voiceChannel) {
          await message.reply('You need to be in a voice channel to use this command.');
          
          // Log error
          await storage.createLog({
            type: 'error',
            message: `Failed to execute command '!play': No voice channel available.`
          });
          return;
        }
        
        await message.reply(`Would play music from ${args[0]} if this was fully implemented.`);
        
        // Log command usage
        await storage.createLog({
          type: 'command',
          message: `Command '!play' used in ${message.channel.name}`
        });
      } catch (error) {
        console.error('Error executing play command:', error);
        await message.reply('There was an error trying to execute that command!');
        
        // Log error
        await storage.createLog({
          type: 'error',
          message: `Error executing play command: ${error}`
        });
      }
    }
  };
  
  // Add commands to the collection
  client.commands.set('help', helpCommand);
  client.commands.set('ping', pingCommand);
  client.commands.set('kick', kickCommand);
  client.commands.set('play', playCommand);
  
  // Process commands from messages
  client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    
    const prefix = '!';
    if (!message.content.startsWith(prefix)) return;
    
    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift()?.toLowerCase();
    
    if (!commandName) return;
    
    const command = client.commands.get(commandName);
    if (!command) return;
    
    try {
      await command.execute(message, args);
    } catch (error) {
      console.error(`Error executing ${commandName} command:`, error);
      message.reply('There was an error trying to execute that command!');
      
      // Log error
      await storage.createLog({
        type: 'error',
        message: `Error executing ${commandName} command: ${error}`
      });
    }
  });
}

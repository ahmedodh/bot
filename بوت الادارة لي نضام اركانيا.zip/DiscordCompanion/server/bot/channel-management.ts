/**
 * نظام إدارة قنوات الديسكورد
 * - تنظيف القنوات
 * - تثبيت الرسائل
 * - عرض قوائم المساعدة
 */

import { 
  Client, 
  TextChannel, 
  EmbedBuilder, 
  Colors,
  MessageCreateOptions,
  Message,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ButtonInteraction
} from 'discord.js';
import { setTimeout } from 'timers/promises';

// معرف قناة الأوامر التي سيتم تنظيفها
let commandChannelId: string = '';

// الوقت بالدقائق بين كل عملية تنظيف
const CLEANUP_INTERVAL_MINUTES = 10;

// مدة تشغيل المهمة (بالمللي ثانية)
const CLEANUP_INTERVAL_MS = CLEANUP_INTERVAL_MINUTES * 60 * 1000;

// اسم القناة المراد تعيينه
const COMMAND_CHANNEL_NAME = 'اوامر النظام';

/**
 * تهيئة نظام إدارة القنوات
 */
export async function initializeChannelManagement(client: Client): Promise<void> {
  try {
    console.log('جاري تهيئة نظام إدارة القنوات...');
    
    // البحث عن القناة التي تحتوي على "commands" أو "أوامر" في اسمها
    await findCommandChannel(client);
    
    // بدء مهمة التنظيف الدوري
    if (commandChannelId) {
      // تغيير اسم القناة إلى "اوامر النظام"
      try {
        const channel = await client.channels.fetch(commandChannelId) as TextChannel;
        if (channel && channel.isTextBased() && channel.name !== COMMAND_CHANNEL_NAME) {
          await channel.setName(COMMAND_CHANNEL_NAME);
          console.log(`تم تغيير اسم القناة إلى: ${COMMAND_CHANNEL_NAME}`);
        }
      } catch (renameError) {
        console.error('حدث خطأ أثناء تغيير اسم القناة:', renameError);
      }
      
      // بدء مهمة التنظيف الدوري
      startPeriodicCleanup(client);
      console.log(`تم تهيئة نظام التنظيف الدوري للقناة: ${commandChannelId}`);
    } else {
      console.warn('لم يتم العثور على قناة أوامر مناسبة. يرجى تحديد القناة يدوياً.');
    }
  } catch (error) {
    console.error('حدث خطأ أثناء تهيئة نظام إدارة القنوات:', error);
  }
}

/**
 * البحث عن قناة الأوامر
 */
async function findCommandChannel(client: Client): Promise<void> {
  // الحصول على جميع السيرفرات
  const guilds = client.guilds.cache;
  
  // البحث في كل سيرفر
  for (const guild of Array.from(guilds.values())) {
    try {
      // تحديث قائمة القنوات
      await guild.channels.fetch();
      
      // البحث عن قناة نصية تحتوي على "commands" أو "أوامر" في اسمها
      const commandChannel = guild.channels.cache.find(
        (channel: any) => 
          channel.isTextBased() && 
          (
            channel.name.includes('commands') || 
            channel.name.includes('أوامر') || 
            channel.name.includes('اوامر') ||
            channel.name.includes('bot') ||
            channel.name.includes('بوت')
          )
      );
      
      if (commandChannel) {
        commandChannelId = commandChannel.id;
        console.log(`تم العثور على قناة الأوامر: ${commandChannel.name} (${commandChannelId})`);
        break;
      }
    } catch (error) {
      console.error(`حدث خطأ أثناء البحث عن قناة الأوامر في السيرفر ${guild.name}:`, error);
    }
  }
}

/**
 * تعيين قناة الأوامر يدوياً
 */
export function setCommandChannel(channelId: string): void {
  commandChannelId = channelId;
  console.log(`تم تعيين قناة الأوامر يدوياً: ${channelId}`);
}

/**
 * بدء مهمة التنظيف الدوري
 */
async function startPeriodicCleanup(client: Client): Promise<void> {
  try {
    console.log(`بدء مهمة التنظيف الدوري كل ${CLEANUP_INTERVAL_MINUTES} دقائق`);
    
    // تشغيل المهمة لأول مرة
    await cleanupCommandChannel(client);
    
    // ثم تشغيلها بشكل دوري
    setInterval(async () => {
      try {
        await cleanupCommandChannel(client);
      } catch (error) {
        console.error('حدث خطأ أثناء التنظيف الدوري:', error);
      }
    }, CLEANUP_INTERVAL_MS);
    
  } catch (error) {
    console.error('حدث خطأ أثناء بدء مهمة التنظيف الدوري:', error);
  }
}

/**
 * تنظيف قناة الأوامر
 */
export async function cleanupCommandChannel(client: Client): Promise<void> {
  if (!commandChannelId) {
    console.warn('لم يتم تعيين قناة الأوامر بعد.');
    return;
  }
  
  try {
    // الحصول على القناة
    const channel = await client.channels.fetch(commandChannelId) as TextChannel;
    if (!channel || !channel.isTextBased()) {
      console.warn('قناة الأوامر غير موجودة أو ليست قناة نصية.');
      return;
    }
    
    console.log(`بدء تنظيف قناة: ${channel.name}`);
    
    // إلغاء تثبيت جميع الرسائل المثبتة القديمة قبل التنظيف
    try {
      const pinnedMessages = await channel.messages.fetchPinned();
      for (const pinnedMessage of Array.from(pinnedMessages.values())) {
        await pinnedMessage.unpin();
      }
      console.log(`تم إلغاء تثبيت ${pinnedMessages.size} رسالة في قناة ${channel.name}`);
    } catch (unpinError) {
      console.error('حدث خطأ أثناء إلغاء تثبيت الرسائل:', unpinError);
    }
    
    // إرسال إشعار قبل الحذف
    const notificationMessage = await channel.send({
      content: '**⚠️ جاري تنظيف قناة الأوامر...**\nسيتم حذف جميع الرسائل السابقة خلال لحظات.'
    });
    
    // انتظار بضع ثوانٍ ليتمكن المستخدمون من رؤية الإشعار
    await setTimeout(3000);
    
    // حذف الرسائل
    try {
      // استخدام bulkDelete إذا كان متاحاً (يمكن حذف حتى 100 رسالة في المرة الواحدة)
      const messagesToDelete = await channel.messages.fetch({ limit: 100 });
      if (messagesToDelete.size > 1) {
        await channel.bulkDelete(messagesToDelete);
        console.log(`تم حذف ${messagesToDelete.size} رسالة من قناة ${channel.name}`);
      } else {
        console.log('لا توجد رسائل لحذفها.');
      }
    } catch (deleteError) {
      console.error('حدث خطأ أثناء حذف الرسائل:', deleteError);
      
      // محاولة الحذف رسالة تلو الأخرى إذا فشل الحذف الجماعي
      try {
        const messagesToDelete = await channel.messages.fetch({ limit: 50 });
        for (const message of Array.from(messagesToDelete.values())) {
          await message.delete();
        }
        console.log('تم حذف الرسائل بالطريقة الفردية.');
      } catch (individualDeleteError) {
        console.error('حدث خطأ أثناء الحذف الفردي للرسائل:', individualDeleteError);
      }
    }
    
    // إرسال رسالة المساعدة الجديدة
    const helpMessage = await sendHelpMessage(channel);
    
    // تثبيت رسالة المساعدة
    try {
      await helpMessage.pin();
      console.log('تم تثبيت رسالة المساعدة');
      
      // إزالة إشعار النظام الخاص بالتثبيت
      const pinnedMessages = await channel.messages.fetchPinned();
      const systemPinMessage = (await channel.messages.fetch({ limit: 10 }))
        .find(msg => msg.type === 6); // النوع 6 هو رسالة نظام "تم تثبيت رسالة"
      
      if (systemPinMessage) {
        await systemPinMessage.delete();
      }
    } catch (pinError) {
      console.error('حدث خطأ أثناء تثبيت رسالة المساعدة:', pinError);
    }
    
  } catch (error) {
    console.error('حدث خطأ أثناء تنظيف قناة الأوامر:', error);
  }
}

/**
 * إرسال رسالة المساعدة الشاملة
 */
async function sendHelpMessage(channel: TextChannel): Promise<Message> {
  // إنشاء رسالة مساعدة شاملة
  const helpEmbed = new EmbedBuilder()
    .setColor(Colors.Gold)
    .setTitle('✨ مرحباً بك في نظام أركانيا ✨')
    .setDescription('هذه القناة مخصصة لاستخدام الأوامر والتفاعل مع البوت. تمسح جميع الرسائل بشكل دوري كل 10 دقائق للحفاظ على نظافة القناة. استخدم الأزرار أدناه للوصول إلى المساعدة في كل قسم بسهولة.')
    .addFields(
      { 
        name: '📋 الأوامر الأساسية', 
        value: '```\n/menu - فتح القائمة الرئيسية التفاعلية\n/profile - عرض ملفك الشخصي\n/shop - فتح المتجر\n/clan - إدارة العشائر\n/ai-ask - سؤال الذكاء الاصطناعي\n!addxp <amount> - إضافة XP لنفسك (الحد الأقصى 500)\n!addxp_admin <member> <amount> - إضافة XP لعضو (للمشرفين فقط)\n```',
        inline: false 
      },
      { 
        name: '👤 نظام الملف الشخصي', 
        value: 'يمكنك عرض ملفك الشخصي، حقيبتك، المستوى الحالي، وإجمالي الخبرة والعملات من خلال القائمة التفاعلية أو أمر `profile/`',
        inline: false 
      },
      { 
        name: '💰 نظام الاقتصاد والمتجر', 
        value: 'اكسب العملات بإكمال المهام والتحديات، ثم استخدمها لشراء ألوان مميزة، عناصر، وميزات خاصة من المتجر',
        inline: false 
      },
      { 
        name: '👑 نظام العشائر المبسط', 
        value: 'انشئ عشيرة خاصة بك أو انضم لعشيرة موجودة، وتنافس مع العشائر الأخرى. استخدم أمر `clan/` للوصول إلى جميع خيارات العشائر بسهولة',
        inline: false 
      },
      { 
        name: '🧠 الذكاء الاصطناعي', 
        value: 'استخدم أمر `ai-ask/` لطرح أسئلة على الذكاء الاصطناعي المدعوم بـ ChatGPT-4o، أو استخدم `ai-generate-image/` لإنشاء صور',
        inline: false 
      },
      { 
        name: '❓ مساعدة', 
        value: 'إذا كنت بحاجة إلى مساعدة إضافية، يمكنك استخدام أمر `ai-ask/` وسؤال البوت عن أي شيء تريد معرفته حول النظام',
        inline: false 
      }
    )
    .setFooter({ 
      text: `✦ تنظف هذه القناة تلقائياً كل ${CLEANUP_INTERVAL_MINUTES} دقائق ✦ آخر تحديث: ${new Date().toLocaleString('ar-AE')}`,
      iconURL: 'https://i.imgur.com/XTtmMSQ.png'
    });
    
  // إنشاء صف الأزرار الأول - الأقسام الرئيسية
  const row1 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('help_profile')
        .setLabel('الملف الشخصي')
        .setEmoji('👤')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('help_economy')
        .setLabel('الاقتصاد')
        .setEmoji('💰')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('help_shop')
        .setLabel('المتجر')
        .setEmoji('🛒')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('help_clan')
        .setLabel('العشائر')
        .setEmoji('👑')
        .setStyle(ButtonStyle.Primary)
    );

  // إنشاء صف الأزرار الثاني - أقسام إضافية
  const row2 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('help_colors')
        .setLabel('الألوان')
        .setEmoji('🎨')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('help_quotes')
        .setLabel('الاقتباسات')
        .setEmoji('📜')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('help_ai')
        .setLabel('الذكاء الاصطناعي')
        .setEmoji('🧠')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('help_admin')
        .setLabel('إدارة')
        .setEmoji('⚙️')
        .setStyle(ButtonStyle.Danger)
    );
  
  // إرسال الرسالة التفاعلية مع الأزرار
  const helpMessageOptions: MessageCreateOptions = {
    embeds: [helpEmbed],
    content: '**⭐ رسالة المساعدة المثبتة ⭐**\nاستخدم الأوامر في هذه القناة للتفاعل مع البوت أو اضغط على الأزرار أدناه للحصول على مساعدة مفصلة لكل قسم.',
    components: [row1, row2]
  };
  
  const helpMessage = await channel.send(helpMessageOptions);
  
  // إضافة معالج الأحداث للأزرار
  setupHelpButtonHandlers(helpMessage, channel);
  
  return helpMessage;
}

/**
 * إعداد معالجات أحداث أزرار المساعدة
 */
function setupHelpButtonHandlers(helpMessage: Message, channel: TextChannel): void {
  const client = helpMessage.client;
  
  // إنشاء معالج للأزرار
  const collector = helpMessage.createMessageComponentCollector({ 
    filter: i => i.message.id === helpMessage.id && i.isButton(),
    time: 1000 * 60 * 60 * 24 // يستمر لمدة 24 ساعة
  });
  
  collector.on('collect', async (interaction: ButtonInteraction) => {
    try {
      // الحصول على القسم المطلوب عرضه أو التحقق من أنه زر العودة
      const customId = interaction.customId;
      
      // إذا كان زر العودة
      if (customId === 'back_to_main') {
        // إنشاء رسالة المساعدة الرئيسية من جديد
        const mainEmbed = new EmbedBuilder()
          .setColor(Colors.Gold)
          .setTitle('✨ مرحباً بك في نظام أركانيا ✨')
          .setDescription('هذه القناة مخصصة لاستخدام الأوامر والتفاعل مع البوت. تمسح جميع الرسائل بشكل دوري كل 10 دقائق للحفاظ على نظافة القناة. استخدم الأزرار أدناه للوصول إلى المساعدة في كل قسم بسهولة.')
          .addFields(
            { 
              name: '📋 الأوامر الأساسية', 
              value: '```\n/menu - فتح القائمة الرئيسية التفاعلية\n/profile - عرض ملفك الشخصي\n/shop - فتح المتجر\n/clan - إدارة العشائر\n/ai-ask - سؤال الذكاء الاصطناعي\n!addxp <amount> - إضافة XP لنفسك (الحد الأقصى 500)\n!addxp_admin <member> <amount> - إضافة XP لعضو (للمشرفين فقط)\n```',
              inline: false 
            },
            { 
              name: '👤 نظام الملف الشخصي', 
              value: 'يمكنك عرض ملفك الشخصي، حقيبتك، المستوى الحالي، وإجمالي الخبرة والعملات من خلال القائمة التفاعلية أو أمر `profile/`',
              inline: false 
            },
            { 
              name: '💰 نظام الاقتصاد والمتجر', 
              value: 'اكسب العملات بإكمال المهام والتحديات، ثم استخدمها لشراء ألوان مميزة، عناصر، وميزات خاصة من المتجر',
              inline: false 
            },
            { 
              name: '👑 نظام العشائر المبسط', 
              value: 'انشئ عشيرة خاصة بك أو انضم لعشيرة موجودة، وتنافس مع العشائر الأخرى. استخدم أمر `clan/` للوصول إلى جميع خيارات العشائر بسهولة',
              inline: false 
            },
            { 
              name: '🧠 الذكاء الاصطناعي', 
              value: 'استخدم أمر `ai-ask/` لطرح أسئلة على الذكاء الاصطناعي المدعوم بـ ChatGPT-4o، أو استخدم `ai-generate-image/` لإنشاء صور',
              inline: false 
            }
          )
          .setFooter({ 
            text: `✦ تنظف هذه القناة تلقائياً كل ${CLEANUP_INTERVAL_MINUTES} دقائق ✦ آخر تحديث: ${new Date().toLocaleString('ar-AE')}`,
            iconURL: 'https://i.imgur.com/XTtmMSQ.png'
          });
          
        // إنشاء صفوف الأزرار نفسها الموجودة في الرسالة الرئيسية
        const row1 = new ActionRowBuilder<ButtonBuilder>()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('help_profile')
              .setLabel('الملف الشخصي')
              .setEmoji('👤')
              .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
              .setCustomId('help_economy')
              .setLabel('الاقتصاد')
              .setEmoji('💰')
              .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
              .setCustomId('help_shop')
              .setLabel('المتجر')
              .setEmoji('🛒')
              .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
              .setCustomId('help_clan')
              .setLabel('العشائر')
              .setEmoji('👑')
              .setStyle(ButtonStyle.Primary)
          );

        const row2 = new ActionRowBuilder<ButtonBuilder>()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('help_colors')
              .setLabel('الألوان')
              .setEmoji('🎨')
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId('help_quotes')
              .setLabel('الاقتباسات')
              .setEmoji('📜')
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId('help_ai')
              .setLabel('الذكاء الاصطناعي')
              .setEmoji('🧠')
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId('help_admin')
              .setLabel('إدارة')
              .setEmoji('⚙️')
              .setStyle(ButtonStyle.Danger)
          );
        
        await interaction.update({ 
          embeds: [mainEmbed], 
          components: [row1, row2] 
        });
        return;
      }
      
      // تجاهل الـ "help_" من بداية customId للحصول على القسم
      const section = customId.replace('help_', '');
      
      // إنشاء رسالة مساعدة للقسم المحدد
      const sectionEmbed = new EmbedBuilder()
        .setColor(Colors.Blue);
      
      // تخصيص المحتوى حسب القسم
      switch (section) {
        case 'profile':
          sectionEmbed
            .setTitle('👤 مساعدة نظام الملف الشخصي')
            .setDescription('أوامر ومعلومات حول نظام الملف الشخصي والمستويات')
            .addFields(
              { 
                name: 'الأوامر المتاحة', 
                value: (
                  "**!profile** أو **/profile** - عرض ملفك الشخصي\n" +
                  "**!rank <member>** - عرض مستوى ورتبة شخص آخر\n" +
                  "**!addxp <amount>** - إضافة XP لنفسك (الحد الأقصى 500)\n" +
                  "**!addxp_admin <member> <amount>** - إضافة XP لعضو (للمشرفين فقط)\n" +
                  "**!leaderboard** - عرض قائمة المتصدرين\n" +
                  "**!next_level** - عرض متطلبات الوصول للمستوى التالي"
                )
              },
              { 
                name: 'ميزات نظام المستويات', 
                value: (
                  "• تكسب XP من خلال إكمال المهام والتحديات\n" +
                  "• كل 1000 نقطة XP ترفع مستواك\n" +
                  "• الترقية تمنحك عملات إضافية وميزات جديدة\n" +
                  "• الرتب تتحسن مع تقدم المستوى\n" +
                  "• عضوية VIP تزيد معدل اكتساب XP بنسبة 20%"
                )
              }
            );
          break;
          
        case 'economy':
          sectionEmbed
            .setTitle('💰 مساعدة نظام الاقتصاد')
            .setDescription('أوامر ومعلومات حول نظام الاقتصاد والعملات')
            .addFields(
              { 
                name: 'الأوامر المتاحة', 
                value: (
                  "**!محفظتي** - عرض رصيدك من العملات\n" +
                  "**!تحويل <member> <amount>** - تحويل عملات لعضو آخر\n" +
                  "**!daily** - الحصول على المكافأة اليومية\n" +
                  "**!bank** - عرض معلومات بنك العملات الخاص بك"
                )
              },
              { 
                name: 'معلومات النظام الاقتصادي', 
                value: (
                  "• تكسب عملة واحدة مقابل كل 10 نقاط XP\n" +
                  "• ترقية المستوى تمنحك 50 عملة إضافية\n" +
                  "• يمكنك كسب عملات إضافية من المهام والتحديات\n" +
                  "• تحتاج إلى عملات لشراء العناصر من المتجر\n" +
                  "• عضوية VIP تزيد العملات المكتسبة بنسبة 10%"
                )
              }
            );
          break;
          
        case 'shop':
          sectionEmbed
            .setTitle('🛒 مساعدة نظام المتجر')
            .setDescription('أوامر ومعلومات حول نظام المتجر والتسوق')
            .addFields(
              { 
                name: 'الأوامر المتاحة', 
                value: (
                  "**!متجر** - عرض المتجر وقائمة العناصر للشراء\n" +
                  "**!شراء <item_id>** - شراء عنصر من المتجر\n" +
                  "**!كوبون <code>** - استخدام كوبون خصم في المتجر\n" +
                  "**!صندوق <box_id>** - شراء وفتح صندوق حظ عشوائي\n" +
                  "**!عروض** - عرض العروض الخاصة والخصومات الحالية"
                )
              },
              { 
                name: 'أنواع العناصر', 
                value: (
                  "• عناصر تجميلية: ألوان مخصصة للملف الشخصي\n" +
                  "• عناصر وظيفية: اقتباسات، عضوية VIP\n" +
                  "• عناصر مؤقتة: تنتهي صلاحيتها بعد فترة محددة\n" +
                  "• عناصر دائمة: تبقى في حسابك للأبد\n" +
                  "• صناديق عشوائية: تحتوي على مفاجآت وعناصر نادرة"
                )
              }
            );
          break;
          
        case 'clan':
          sectionEmbed
            .setTitle('👑 مساعدة نظام العشائر')
            .setDescription('أوامر ومعلومات حول نظام العشائر والحروب')
            .addFields(
              { 
                name: 'الأوامر الأساسية', 
                value: (
                  "**!clan create <name>** - إنشاء عشيرة جديدة\n" +
                  "**!clan info** - عرض معلومات عشيرتك\n" +
                  "**!clan join <id>** - الانضمام إلى عشيرة\n" +
                  "**!clan leave** - مغادرة العشيرة الحالية\n" +
                  "**!clan members** - عرض أعضاء العشيرة\n" +
                  "**!clan rank** - عرض تصنيف العشائر"
                )
              },
              { 
                name: 'ميزات نظام العشائر', 
                value: (
                  "• التعاون مع أعضاء آخرين لبناء عشيرة قوية\n" +
                  "• كسب مكافآت حصرية للعشيرة\n" +
                  "• خوض حروب العشائر للتنافس على الموارد\n" +
                  "• ترقية مقر العشيرة وتحسين قدراتها\n" +
                  "• رتب متعددة داخل العشيرة (قائد، مساعد، عضو)"
                )
              }
            );
          break;
          
        case 'colors':
          sectionEmbed
            .setTitle('🎨 مساعدة نظام الألوان')
            .setDescription('أوامر ومعلومات حول نظام الألوان وتخصيص المظهر')
            .addFields(
              { 
                name: 'الأوامر المتاحة', 
                value: (
                  "**!colors** - عرض الألوان المتاحة حاليًا\n" +
                  "**!set_profile_color <color_id>** - تغيير لون الملف الشخصي\n" +
                  "**!set_text_color <color_id>** - تغيير لون النص في الملف الشخصي\n" +
                  "**!preview_color <color_id>** - معاينة شكل اللون قبل الشراء\n" +
                  "**!latest_colors** - عرض أحدث الألوان الأسبوعية"
                )
              },
              { 
                name: 'معلومات نظام الألوان', 
                value: (
                  "• يتم تحديث الألوان الأسبوعية كل يوم سبت\n" +
                  "• ألوان خاصة متاحة للمستويات العالية (50+)\n" +
                  "• ألوان حصرية متاحة لأعضاء VIP\n" +
                  "• يمكنك معاينة اللون قبل الشراء\n" +
                  "• يمكنك استخدام الألوان للملف الشخصي والاقتباسات"
                )
              }
            );
          break;
          
        case 'quotes':
          sectionEmbed
            .setTitle('📜 مساعدة نظام الاقتباسات')
            .setDescription('أوامر ومعلومات حول نظام الاقتباسات')
            .addFields(
              { 
                name: 'الأوامر المتاحة', 
                value: (
                  "**!اقتباس** - عرض اقتباس عشوائي من مكتبة الاقتباسات\n" +
                  "**!اقتباس_جديد <نص الاقتباس>** - إضافة اقتباس جديد إلى مكتبتك\n" +
                  "**!اقتباساتي** - عرض قائمة الاقتباسات الخاصة بك\n" +
                  "**!احذف_اقتباس <id>** - حذف اقتباس من مكتبتك\n" +
                  "**!اقتباسات_السيرفر** - عرض أفضل اقتباسات السيرفر"
                )
              },
              { 
                name: 'معلومات نظام الاقتباسات', 
                value: (
                  "• يجب شراء 'اقتباس' من المتجر قبل إضافة اقتباس جديد\n" +
                  "• يمكنك تزيين اقتباساتك بألوان مختلفة\n" +
                  "• الاقتباسات المميزة تظهر بشكل أكبر في قائمة اقتباسات السيرفر\n" +
                  "• يمكنك التصويت لاقتباسات الآخرين\n" +
                  "• الاقتباسات الأكثر شعبية تظهر بشكل عشوائي في السيرفر"
                )
              }
            );
          break;
          
        case 'ai':
          sectionEmbed
            .setTitle('🧠 مساعدة نظام الذكاء الاصطناعي')
            .setDescription('أوامر ومعلومات حول نظام الذكاء الاصطناعي')
            .addFields(
              { 
                name: 'الأوامر المتاحة', 
                value: (
                  "**!ai-ask <سؤال>** أو **/ai-ask** - طرح سؤال على الذكاء الاصطناعي\n" +
                  "**!ai-generate-image <وصف>** أو **/ai-generate-image** - إنشاء صورة\n" +
                  "**!ai-improve-code <كود>** - تحسين وتصحيح كود برمجي\n" +
                  "**!ai-analyze <نص>** - تحليل نص وتقديم ملاحظات\n" +
                  "**!ai-suggestions** - الحصول على اقتراحات للأوامر"
                )
              },
              { 
                name: 'معلومات نظام الذكاء الاصطناعي', 
                value: (
                  "• يستخدم النظام ChatGPT-4o للإجابة على الأسئلة\n" +
                  "• يتعلم النظام من تفاعلاتك لتقديم نتائج أفضل\n" +
                  "• يمكنه إنشاء صور باستخدام DALL·E 3\n" +
                  "• يمكنه تحليل النصوص والكود وتقديم تحسينات\n" +
                  "• يقترح أوامر بناءً على نشاطك واهتماماتك"
                )
              }
            );
          break;
          
        case 'admin':
          // فحص ما إذا كان للمستخدم صلاحيات إدارية
          const member = await channel.guild.members.fetch(interaction.user.id).catch(() => null);
          if (!member || !member.permissions.has('Administrator')) {
            await interaction.reply({ 
              content: '⛔ عذراً، أنت لا تملك صلاحيات للوصول إلى قسم أوامر الإدارة!',
              ephemeral: true 
            });
            return;
          }
          
          sectionEmbed
            .setTitle('⚙️ مساعدة أوامر الإدارة')
            .setDescription('أوامر ومعلومات للمشرفين والإداريين')
            .addFields(
              { 
                name: 'أوامر إدارة المستويات', 
                value: (
                  "**!add_xp <member> <amount>** - إضافة XP لعضو\n" +
                  "**!remove_xp <member> <amount>** - إزالة XP من عضو\n" +
                  "**!reset_xp <member>** - إعادة تعيين XP لعضو\n" +
                  "**!set_level <member> <level>** - تعيين مستوى محدد لعضو"
                )
              },
              { 
                name: 'أوامر إدارة الاقتصاد', 
                value: (
                  "**!add_coins <member> <amount>** - إضافة عملات لعضو\n" +
                  "**!remove_coins <member> <amount>** - إزالة عملات من عضو\n" +
                  "**!create_coupon <code> <discount> <uses>** - إنشاء كوبون خصم\n" +
                  "**!delete_coupon <code>** - حذف كوبون خصم"
                )
              },
              { 
                name: 'أوامر إدارة النظام', 
                value: (
                  "**!reset_weekly_colors** - تحديث الألوان الأسبوعية يدويًا\n" +
                  "**!add_shop_item** - إضافة عنصر جديد للمتجر\n" +
                  "**!remove_shop_item <item_id>** - إزالة عنصر من المتجر\n" +
                  "**!backup_data** - عمل نسخة احتياطية من بيانات النظام\n" +
                  "**!channel cleanup** - تنظيف القناة الحالية وتثبيت أمر المساعدة"
                )
              }
            );
          break;
          
        default:
          // في حالة زر غير معروف
          await interaction.reply({ 
            content: '❓ عذراً، القسم المطلوب غير متوفر!',
            ephemeral: true 
          });
          return;
      }
      
      // إضافة زر الرجوع
      const returnButton = new ActionRowBuilder<ButtonBuilder>()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('back_to_main')
            .setLabel('العودة للقائمة الرئيسية')
            .setEmoji('🔙')
            .setStyle(ButtonStyle.Success)
        );
        
      // استجابة مؤقتة فقط للمستخدم الذي ضغط على الزر
      await interaction.reply({ 
        embeds: [sectionEmbed],
        components: [returnButton],
        ephemeral: true // عرض الرسالة للمستخدم فقط
      });
      
    } catch (error) {
      console.error('حدث خطأ في معالجة زر المساعدة:', error);
      await interaction.reply({ 
        content: '❌ حدث خطأ أثناء معالجة طلبك. الرجاء المحاولة مرة أخرى.',
        ephemeral: true 
      });
    }
  });
  
  collector.on('end', () => {
    console.log(`انتهت صلاحية معالج أزرار المساعدة للرسالة: ${helpMessage.id}`);
  });
}

/**
 * وظيفة الاختبار - يمكن استدعاؤها من واجهة API
 */
export async function testCleanupChannel(client: Client, channelId?: string): Promise<{ success: boolean, message: string }> {
  try {
    if (channelId) {
      setCommandChannel(channelId);
    }
    
    await cleanupCommandChannel(client);
    return { 
      success: true, 
      message: `تم تنظيف قناة الأوامر ${commandChannelId} بنجاح` 
    };
  } catch (error) {
    return { 
      success: false, 
      message: `حدث خطأ أثناء اختبار تنظيف القناة: ${error instanceof Error ? error.message : String(error)}` 
    };
  }
}
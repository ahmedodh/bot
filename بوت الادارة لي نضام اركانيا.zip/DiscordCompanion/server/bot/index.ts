import { Client, GatewayIntentBits, Events, Collection, Interaction, InteractionType } from 'discord.js';
import { setupCommands } from './commands';
import { setupEvents } from './events';
import { storage } from '../storage';
import { registerSlashCommands, handleSlashCommand, handleAiFeedback } from './slash-commands';
import { schedulePeriodicAnalysis } from './self-learning';
import { handleButtonInteraction } from './interactive-buttons';
import { initializeChannelManagement } from './channel-management';

// Discord client with intents
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessageReactions, // إضافة للتفاعلات
    GatewayIntentBits.DirectMessages, // دعم الرسائل المباشرة
  ]
});

// Bot metrics
let botStartTime = Date.now();
let commandsUsed = 0;
let apiCallCount = 0;
let slashCommandsUsed = 0;
let aiInteractionsCount = 0;

// Store the commands in memory
client.commands = new Collection();

// تتبع جلسات المحادثة النشطة
const activeConversations = new Map<string, Array<{ role: string; content: string }>>();

// Update stats in storage every minute
function updateStats() {
  const uptimeSeconds = Math.floor((Date.now() - botStartTime) / 1000);
  const memoryUsage = Math.round(process.memoryUsage().heapUsed / 1024 / 1024); // MB
  
  storage.updateStats({
    uptime: uptimeSeconds,
    commandsUsed: commandsUsed + slashCommandsUsed,
    serverCount: client.guilds.cache.size,
    memoryUsage,
    latency: client.ws.ping,
    apiCalls: apiCallCount,
    aiInteractions: aiInteractionsCount
  });
}

// Initialize the Discord bot
export async function initializeBot() {
  try {
    // Setup traditional commands and events
    setupCommands(client);
    setupEvents(client);

    // Set up a listener to track command usage
    client.on(Events.MessageCreate, async (message) => {
      // Increment API call counter
      apiCallCount++;

      if (message.author.bot) return;
      
      const prefix = '!';
      if (!message.content.startsWith(prefix)) return;
      
      const args = message.content.slice(prefix.length).trim().split(/ +/);
      const commandName = args.shift()?.toLowerCase();
      
      if (!commandName) return;
      
      const command = client.commands.get(commandName);
      if (command) {
        commandsUsed++;
        updateStats();
      }
    });

    // معالجة أوامر الشرطة المائلة
    client.on(Events.InteractionCreate, async (interaction: Interaction) => {
      try {
        // معالجة أوامر الشرطة المائلة
        if (interaction.isChatInputCommand()) {
          slashCommandsUsed++;
          await handleSlashCommand(interaction);
          updateStats();
        }
        // معالجة تفاعلات الأزرار
        else if (interaction.isButton()) {
          const { customId } = interaction;
          
          // معالجة تقييمات الذكاء الاصطناعي
          if (customId.startsWith('ai_feedback_')) {
            await handleAiFeedback(customId, interaction);
          }
          // معالجة نظام الأزرار التفاعلية
          else if (customId.startsWith('menu_') || 
                  customId.startsWith('profile_') || 
                  customId.startsWith('shop_') || 
                  customId.startsWith('levels_') || 
                  customId.startsWith('colors_') || 
                  customId.startsWith('quotes_') || 
                  customId.startsWith('clans_')) {
            await handleButtonInteraction(interaction);
          }
        }
        // معالجة تفاعلات القوائم المنسدلة
        else if (interaction.isStringSelectMenu()) {
          // سيتم إضافة معالجات القوائم المنسدلة هنا
        }
        // معالجة النماذج
        else if (interaction.type === InteractionType.ModalSubmit) {
          // سيتم إضافة معالجات النماذج هنا
        }
      } catch (error) {
        console.error('Error handling interaction:', error);
      }
    });

    // Set up periodic stats updates
    setInterval(updateStats, 60000); // Update every minute
    
    // جدولة التحليل الدوري لنظام التعلم الذاتي
    schedulePeriodicAnalysis();

    // Return the client but don't login yet
    return client;
  } catch (error) {
    console.error('Failed to initialize the bot:', error);
    throw error;
  }
}

// Start the bot with the token
export async function startBot(token: string) {
  if (!token) {
    throw new Error('No Discord token provided. Set DISCORD_TOKEN environment variable.');
  }
  
  try {
    botStartTime = Date.now();
    await client.login(token);
    console.log(`Bot logged in as ${client.user?.tag}`);
    
    // تسجيل أوامر الشرطة المائلة بعد تسجيل الدخول
    console.log('جاري تسجيل أوامر الشرطة المائلة...');
    try {
      await registerSlashCommands(client);
      console.log('Logged in as', client.user?.tag);
    } catch (slashError) {
      console.error('فشل في تسجيل أوامر الشرطة المائلة:', slashError);
    }
    
    // تهيئة نظام إدارة القنوات وتنظيفها
    await initializeChannelManagement(client);
    
    // Create initial stats
    updateStats();
    
    return client;
  } catch (error) {
    console.error('Failed to start the bot:', error);
    throw error;
  }
}

// Stop the bot
export async function stopBot() {
  if (client) {
    client.destroy();
    console.log('Bot has been stopped');
  }
}

// Restart the bot
export async function restartBot(token: string) {
  await stopBot();
  return startBot(token);
}

/**
 * زيادة عداد تفاعلات الذكاء الاصطناعي
 */
export function incrementAiInteractions() {
  aiInteractionsCount++;
  updateStats();
}

/**
 * إدارة جلسات المحادثة
 */
export function getConversationHistory(userId: string): Array<{ role: string; content: string }> {
  if (!activeConversations.has(userId)) {
    activeConversations.set(userId, []);
  }
  return activeConversations.get(userId) || [];
}

export function addToConversationHistory(userId: string, role: 'user' | 'assistant', content: string) {
  const history = getConversationHistory(userId);
  history.push({ role, content });
  
  // حفظ آخر 10 رسائل فقط للحفاظ على الأداء
  if (history.length > 10) {
    activeConversations.set(userId, history.slice(-10));
  } else {
    activeConversations.set(userId, history);
  }
}

export function clearConversationHistory(userId: string) {
  activeConversations.delete(userId);
}

// For TypeScript support
declare module 'discord.js' {
  interface Client {
    commands: Collection<string, any>;
  }
}

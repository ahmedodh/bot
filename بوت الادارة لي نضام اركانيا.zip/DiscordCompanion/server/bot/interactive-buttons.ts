/**
 * نظام الأزرار التفاعلية للبوت
 * 
 * يوفر هذا النظام واجهة أزرار متكاملة للتنقل بين الأوامر المختلفة في الديسكورد
 * ويسمح للمستخدمين بالتفاعل مع البوت بطريقة أكثر سهولة
 */

import { 
  ButtonInteraction, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle, 
  EmbedBuilder, 
  Colors, 
  StringSelectMenuBuilder,
  StringSelectMenuInteraction,
  User,
  MessageActionRowComponentBuilder,
  InteractionResponse,
  Message
} from 'discord.js';

// ===== القائمة الرئيسية =====

/**
 * إنشاء قائمة الأزرار الرئيسية
 */
export function createMainMenuButtons(): ActionRowBuilder<ButtonBuilder>[] {
  const row1 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('menu_profile')
        .setLabel('👤 الملف الشخصي')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('menu_shop')
        .setLabel('🛒 المتجر')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('menu_levels')
        .setLabel('📊 المستويات')
        .setStyle(ButtonStyle.Primary)
    );
    
  const row2 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('menu_colors')
        .setLabel('🎨 الألوان')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('menu_quotes')
        .setLabel('💬 الاقتباسات')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('menu_clans')
        .setLabel('👑 العشائر')
        .setStyle(ButtonStyle.Secondary)
    );
    
  return [row1, row2];
}

/**
 * إنشاء زر العودة للقائمة الرئيسية
 */
export function createBackToMainMenuButton(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('menu_main')
        .setLabel('🏠 العودة للقائمة الرئيسية')
        .setStyle(ButtonStyle.Danger)
    );
}

// ===== قسم الملف الشخصي =====

/**
 * إنشاء أزرار قسم الملف الشخصي
 */
export function createProfileButtons(): ActionRowBuilder<ButtonBuilder>[] {
  const row1 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('profile_view')
        .setLabel('👁️ عرض الملف')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('profile_wallet')
        .setLabel('💰 المحفظة')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('profile_inventory')
        .setLabel('🎒 الحقيبة')
        .setStyle(ButtonStyle.Primary)
    );
    
  const row2 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('profile_color')
        .setLabel('🎨 تغيير اللون')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('profile_transfer')
        .setLabel('↗️ تحويل عملات')
        .setStyle(ButtonStyle.Secondary)
    );
    
  const backButton = createBackToMainMenuButton();
  
  return [row1, row2, backButton];
}

// ===== قسم المتجر =====

/**
 * إنشاء أزرار قسم المتجر
 */
export function createShopButtons(): ActionRowBuilder<ButtonBuilder>[] {
  const row1 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('shop_view')
        .setLabel('🛒 عرض المتجر')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('shop_colors')
        .setLabel('🎨 متجر الألوان')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('shop_items')
        .setLabel('🧩 متجر العناصر')
        .setStyle(ButtonStyle.Primary)
    );
    
  const row2 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('shop_boxes')
        .setLabel('📦 صناديق الحظ')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('shop_coupon')
        .setLabel('🎟️ استخدام كوبون')
        .setStyle(ButtonStyle.Secondary)
    );
    
  const backButton = createBackToMainMenuButton();
  
  return [row1, row2, backButton];
}

// ===== قسم المستويات =====

/**
 * إنشاء أزرار قسم المستويات
 */
export function createLevelsButtons(): ActionRowBuilder<ButtonBuilder>[] {
  const row1 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('levels_leaderboard')
        .setLabel('🏆 المتصدرين')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('levels_next')
        .setLabel('⏭️ المستوى التالي')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('levels_challenges')
        .setLabel('🎯 التحديات')
        .setStyle(ButtonStyle.Primary)
    );
    
  const backButton = createBackToMainMenuButton();
  
  return [row1, backButton];
}

// ===== قسم الألوان =====

/**
 * إنشاء أزرار قسم الألوان
 */
export function createColorsButtons(): ActionRowBuilder<ButtonBuilder>[] {
  const row1 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('colors_view')
        .setLabel('👁️ عرض الألوان')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('colors_preview')
        .setLabel('🔍 معاينة لون')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('colors_set')
        .setLabel('✅ تعيين لون')
        .setStyle(ButtonStyle.Primary)
    );
    
  const row2 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('colors_weekly')
        .setLabel('📅 الألوان الأسبوعية')
        .setStyle(ButtonStyle.Secondary)
    );
    
  const backButton = createBackToMainMenuButton();
  
  return [row1, row2, backButton];
}

// ===== قسم الاقتباسات =====

/**
 * إنشاء أزرار قسم الاقتباسات
 */
export function createQuotesButtons(): ActionRowBuilder<ButtonBuilder>[] {
  const row1 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('quotes_view')
        .setLabel('👁️ عرض الاقتباسات')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('quotes_add')
        .setLabel('➕ إضافة اقتباس')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('quotes_random')
        .setLabel('🎲 اقتباس عشوائي')
        .setStyle(ButtonStyle.Primary)
    );
    
  const backButton = createBackToMainMenuButton();
  
  return [row1, backButton];
}

// ===== قسم العشائر =====

/**
 * إنشاء أزرار قسم العشائر
 */
export function createClansButtons(): ActionRowBuilder<ButtonBuilder>[] {
  const row1 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('clans_list')
        .setLabel('👁️ قائمة العشائر')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('clans_myclan')
        .setLabel('👑 عشيرتي')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('clans_join')
        .setLabel('➕ انضمام لعشيرة')
        .setStyle(ButtonStyle.Success)
    );
    
  const row2 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('clans_create')
        .setLabel('🛠️ إنشاء عشيرة')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('clans_donate')
        .setLabel('💰 التبرع للعشيرة')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('clans_leave')
        .setLabel('❌ مغادرة العشيرة')
        .setStyle(ButtonStyle.Danger)
    );
    
  const backButton = createBackToMainMenuButton();
  
  return [row1, row2, backButton];
}

// ===== معالجة تفاعلات الأزرار =====

/**
 * معالجة تفاعلات الأزرار الرئيسية
 */
export async function handleButtonInteraction(
  interaction: ButtonInteraction
): Promise<void> {
  const { customId } = interaction;
  const userId = interaction.user.id;
  
  try {
    // معالجة أزرار الوصول السريع الجديدة
    if (customId.startsWith('quick_')) {
      await handleQuickAccessButton(interaction, customId);
      return;
    }
    
    // معالجة أزرار المساعدة
    if (customId.startsWith('help_')) {
      // استيراد معالج أزرار المساعدة من ملف slash-commands
      const { handleHelpButton } = await import('./slash-commands');
      await handleHelpButton(customId, interaction);
      return;
    }
    
    // تحقق مما إذا كان الزر للعودة إلى القائمة الرئيسية
    if (customId === 'menu_main') {
      await showMainMenu(interaction);
      return;
    }
    
    // معالجة أزرار القائمة الرئيسية
    if (customId.startsWith('menu_')) {
      await handleMainMenuButton(interaction, customId);
      return;
    }
    
    // معالجة أزرار الملف الشخصي
    if (customId.startsWith('profile_')) {
      await handleProfileButton(interaction, customId);
      return;
    }
    
    // معالجة أزرار المتجر
    if (customId.startsWith('shop_')) {
      await handleShopButton(interaction, customId);
      return;
    }
    
    // معالجة أزرار المستويات
    if (customId.startsWith('levels_')) {
      await handleLevelsButton(interaction, customId);
      return;
    }
    
    // معالجة أزرار الألوان
    if (customId.startsWith('colors_')) {
      await handleColorsButton(interaction, customId);
      return;
    }
    
    // معالجة أزرار الاقتباسات
    if (customId.startsWith('quotes_')) {
      await handleQuotesButton(interaction, customId);
      return;
    }
    
    // معالجة أزرار العشائر
    if (customId.startsWith('clans_')) {
      await handleClansButton(interaction, customId);
      return;
    }
    
    // إذا وصلنا إلى هنا، فإن الزر غير معروف
    await interaction.reply({
      content: 'عذراً، هذا الزر غير مدعوم حالياً',
      ephemeral: true
    });
    
  } catch (error) {
    console.error('خطأ في معالجة تفاعل الأزرار:', error);
    try {
      await interaction.reply({
        content: 'عذراً، حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى لاحقاً.',
        ephemeral: true
      });
    } catch (replyError) {
      console.error('خطأ في إرسال رد الخطأ:', replyError);
    }
  }
}

/**
 * معالجة أزرار الوصول السريع
 */
async function handleQuickAccessButton(
  interaction: ButtonInteraction,
  customId: string
): Promise<void> {
  // إنشاء دالة تأخير للرد للواجهة المستخدم
  await interaction.deferReply();
  
  // إنشاء زر العودة للقائمة الرئيسية - نستخدمه في عدة أماكن
  const backButtonRow = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('menu_main')
        .setLabel('🏠 العودة للقائمة الرئيسية')
        .setStyle(ButtonStyle.Primary)
    );
  
  try {
    switch (customId) {
      case 'quick_profile':
        // عرض الملف الشخصي السريع
        const userEmbed = new EmbedBuilder()
          .setColor('#3498db')
          .setTitle(`👤 الملف الشخصي | ${interaction.user.username}`)
          .setThumbnail(interaction.user.displayAvatarURL({ size: 256 }))
          .setDescription('💫 إليك معلومات ملفك الشخصي بطريقة سريعة ومختصرة')
          .addFields(
            { name: '🆔 معرف المستخدم', value: `\`${interaction.user.id}\``, inline: true },
            { name: '📅 تاريخ الانضمام', value: `<t:${Math.floor(interaction.user.createdTimestamp / 1000)}:R>`, inline: true },
            { name: '📊 المستوى', value: '``قريباً..``', inline: true },
            { name: '✨ الخبرة', value: '``قريباً..``', inline: true },
            { name: '💰 العملات', value: '``قريباً..``', inline: true },
            { name: '🏆 الرتبة', value: '``قريباً..``', inline: true }
          )
          .setFooter({ text: 'لعرض ملف تفصيلي، استخدم قائمة الملف الشخصي من القائمة الرئيسية' });
        
        await interaction.editReply({
          embeds: [userEmbed],
          components: [backButtonRow]
        });
        break;
      
      case 'quick_leaderboard':
        // عرض قائمة المتصدرين السريعة
        const leaderboardEmbed = new EmbedBuilder()
          .setColor('#f1c40f')
          .setTitle('🏆 قائمة المتصدرين')
          .setDescription('📊 أفضل المستخدمين من حيث المستوى والخبرة')
          .addFields(
            { name: '🥇 المركز الأول', value: '``قريباً..``', inline: false },
            { name: '🥈 المركز الثاني', value: '``قريباً..``', inline: false },
            { name: '🥉 المركز الثالث', value: '``قريباً..``', inline: false }
          )
          .setFooter({ text: 'لعرض قائمة كاملة، استخدم قائمة المستويات من القائمة الرئيسية' });
        
        await interaction.editReply({
          embeds: [leaderboardEmbed],
          components: [backButtonRow]
        });
        break;
      
      case 'quick_help':
        // عرض مساعدة سريعة للتنقل
        const helpEmbed = new EmbedBuilder()
          .setColor('#9b59b6')
          .setTitle('❓ مساعدة التنقل')
          .setDescription('دليل سريع لاستخدام نظام الأزرار التفاعلية')
          .addFields(
            { 
              name: '🔵 الوصول للقوائم', 
              value: 'استخدم أزرار القائمة الرئيسية للوصول إلى قوائم مختلفة مثل الملف الشخصي، المتجر، المستويات، إلخ.', 
              inline: false 
            },
            { 
              name: '🟢 الوصول السريع', 
              value: 'تتيح لك أزرار الوصول السريع الوصول المباشر إلى الميزات الأكثر استخداماً مثل الملف الشخصي والمتصدرين.', 
              inline: false 
            },
            { 
              name: '🔴 العودة للقائمة الرئيسية', 
              value: 'يمكنك في أي وقت استخدام زر العودة للقائمة الرئيسية للرجوع إلى البداية.', 
              inline: false 
            },
            { 
              name: '⭐ نصائح مفيدة', 
              value: '- استخدم أمر `/menu` في أي وقت لعرض القائمة الرئيسية\n- يمكنك استخدام الأزرار بدلاً من كتابة الأوامر\n- تأكد من تفعيل الإشعارات لتلقي التحديثات الجديدة', 
              inline: false 
            }
          )
          .setImage('https://i.imgur.com/XSVUYyz.png')
          .setFooter({ text: 'تم تطوير نظام التنقل التفاعلي لتسهيل استخدام البوت' });
        
        // أزرار إضافية للمساعدة
        const helpButtonsRow = new ActionRowBuilder<ButtonBuilder>()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('menu_main')
              .setLabel('🏠 العودة للقائمة الرئيسية')
              .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
              .setCustomId('help_commands')
              .setLabel('📋 قائمة الأوامر')
              .setStyle(ButtonStyle.Secondary)
              .setEmoji('📋'),
            new ButtonBuilder()
              .setCustomId('help_faq')
              .setLabel('❓ الأسئلة الشائعة')
              .setStyle(ButtonStyle.Secondary)
              .setEmoji('❓')
          );
        
        await interaction.editReply({
          embeds: [helpEmbed],
          components: [helpButtonsRow]
        });
        break;
      
      default:
        // زر غير معروف
        await interaction.editReply({
          content: '❌ هذه الميزة غير متوفرة حالياً. يرجى المحاولة لاحقاً.',
          components: [backButtonRow]
        });
    }
  } catch (error) {
    console.error('خطأ في معالجة زر الوصول السريع:', error);
    await interaction.editReply('❌ عذراً، حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى لاحقاً.');
  }
}

/**
 * عرض القائمة الرئيسية
 */
export async function showMainMenu(interaction: ButtonInteraction): Promise<void> {
  // إنشاء الإطار الأساسي
  const embed = new EmbedBuilder()
    .setColor(Colors.Blurple)
    .setTitle('🌟 نظام أركانيا - القائمة الرئيسية')
    .setDescription('اختر أحد الخيارات أدناه للتنقل بين ميزات البوت المختلفة.')
    .addFields(
      { name: '👤 الملف الشخصي', value: 'عرض ملفك الشخصي ومعلوماتك وحقيبتك', inline: true },
      { name: '🛒 المتجر', value: 'شراء العناصر والألوان واستخدام الكوبونات', inline: true },
      { name: '📊 المستويات', value: 'عرض المتصدرين والتحديات', inline: true },
      { name: '🎨 الألوان', value: 'عرض وتغيير ألوان الملف الشخصي', inline: true },
      { name: '💬 الاقتباسات', value: 'إضافة وعرض الاقتباسات', inline: true },
      { name: '👑 العشائر', value: 'إدارة وعرض العشائر ومعاركها', inline: true }
    )
    .setFooter({ text: 'ملاحظة: يمكنك العودة إلى هذه القائمة في أي وقت باستخدام زر العودة' });
  
  // إنشاء الأزرار
  const buttons = createMainMenuButtons();
  
  // الرد على التفاعل
  if (interaction.replied || interaction.deferred) {
    await interaction.editReply({ embeds: [embed], components: buttons });
  } else {
    await interaction.reply({ embeds: [embed], components: buttons });
  }
}

/**
 * معالجة أزرار القائمة الرئيسية
 */
async function handleMainMenuButton(
  interaction: ButtonInteraction,
  customId: string
): Promise<void> {
  switch (customId) {
    case 'menu_profile':
      await showProfileMenu(interaction);
      break;
    case 'menu_shop':
      await showShopMenu(interaction);
      break;
    case 'menu_levels':
      await showLevelsMenu(interaction);
      break;
    case 'menu_colors':
      await showColorsMenu(interaction);
      break;
    case 'menu_quotes':
      await showQuotesMenu(interaction);
      break;
    case 'menu_clans':
      await showClansMenu(interaction);
      break;
    default:
      await interaction.reply({
        content: 'عذراً، هذا الخيار غير متاح حالياً',
        ephemeral: true
      });
  }
}

/**
 * عرض قائمة الملف الشخصي
 */
async function showProfileMenu(interaction: ButtonInteraction): Promise<void> {
  const embed = new EmbedBuilder()
    .setColor(Colors.Green)
    .setTitle('👤 قائمة الملف الشخصي')
    .setDescription('اختر أحد الخيارات أدناه لإدارة ملفك الشخصي.')
    .addFields(
      { name: '👁️ عرض الملف', value: 'عرض ملفك الشخصي والمستوى والخبرة', inline: true },
      { name: '💰 المحفظة', value: 'عرض رصيدك من العملات', inline: true },
      { name: '🎒 الحقيبة', value: 'عرض العناصر التي تمتلكها', inline: true },
      { name: '🎨 تغيير اللون', value: 'تغيير لون الملف الشخصي', inline: true },
      { name: '↗️ تحويل عملات', value: 'تحويل عملات إلى مستخدم آخر', inline: true }
    );
  
  const buttons = createProfileButtons();
  
  await interaction.reply({ embeds: [embed], components: buttons });
}

/**
 * عرض قائمة المتجر
 */
async function showShopMenu(interaction: ButtonInteraction): Promise<void> {
  const embed = new EmbedBuilder()
    .setColor(Colors.Gold)
    .setTitle('🛒 قائمة المتجر')
    .setDescription('اختر أحد الخيارات أدناه للتسوق وشراء العناصر.')
    .addFields(
      { name: '🛒 عرض المتجر', value: 'عرض جميع العناصر المتاحة للشراء', inline: true },
      { name: '🎨 متجر الألوان', value: 'عرض الألوان المتاحة للشراء', inline: true },
      { name: '🧩 متجر العناصر', value: 'عرض العناصر والمزايا المتاحة للشراء', inline: true },
      { name: '📦 صناديق الحظ', value: 'فتح صناديق للحصول على جوائز عشوائية', inline: true },
      { name: '🎟️ استخدام كوبون', value: 'استخدام كوبون خصم أو هدية', inline: true }
    );
  
  const buttons = createShopButtons();
  
  await interaction.reply({ embeds: [embed], components: buttons });
}

/**
 * عرض قائمة المستويات
 */
async function showLevelsMenu(interaction: ButtonInteraction): Promise<void> {
  const embed = new EmbedBuilder()
    .setColor(Colors.Blue)
    .setTitle('📊 قائمة المستويات')
    .setDescription('اختر أحد الخيارات أدناه لعرض المستويات والتحديات.')
    .addFields(
      { name: '🏆 المتصدرين', value: 'عرض قائمة المستخدمين الأعلى مستوى', inline: true },
      { name: '⏭️ المستوى التالي', value: 'عرض متطلبات المستوى التالي', inline: true },
      { name: '🎯 التحديات', value: 'عرض التحديات المتاحة حالياً', inline: true }
    );
  
  const buttons = createLevelsButtons();
  
  await interaction.reply({ embeds: [embed], components: buttons });
}

/**
 * عرض قائمة الألوان
 */
async function showColorsMenu(interaction: ButtonInteraction): Promise<void> {
  const embed = new EmbedBuilder()
    .setColor(Colors.Purple)
    .setTitle('🎨 قائمة الألوان')
    .setDescription('اختر أحد الخيارات أدناه لإدارة ألوان الملف الشخصي.')
    .addFields(
      { name: '👁️ عرض الألوان', value: 'عرض جميع الألوان المتاحة', inline: true },
      { name: '🔍 معاينة لون', value: 'معاينة لون قبل الشراء أو الاستخدام', inline: true },
      { name: '✅ تعيين لون', value: 'تعيين لون للملف الشخصي', inline: true },
      { name: '📅 الألوان الأسبوعية', value: 'عرض الألوان الأسبوعية الجديدة', inline: true }
    );
  
  const buttons = createColorsButtons();
  
  await interaction.reply({ embeds: [embed], components: buttons });
}

/**
 * عرض قائمة الاقتباسات
 */
async function showQuotesMenu(interaction: ButtonInteraction): Promise<void> {
  const embed = new EmbedBuilder()
    .setColor(Colors.White)
    .setTitle('💬 قائمة الاقتباسات')
    .setDescription('اختر أحد الخيارات أدناه لإدارة الاقتباسات.')
    .addFields(
      { name: '👁️ عرض الاقتباسات', value: 'عرض جميع اقتباساتك المحفوظة', inline: true },
      { name: '➕ إضافة اقتباس', value: 'إضافة اقتباس جديد إلى قائمتك', inline: true },
      { name: '🎲 اقتباس عشوائي', value: 'عرض اقتباس عشوائي من قائمة الاقتباسات', inline: true }
    );
  
  const buttons = createQuotesButtons();
  
  await interaction.reply({ embeds: [embed], components: buttons });
}

/**
 * عرض قائمة العشائر
 */
async function showClansMenu(interaction: ButtonInteraction): Promise<void> {
  const embed = new EmbedBuilder()
    .setColor(Colors.Red)
    .setTitle('👑 قائمة العشائر')
    .setDescription('اختر أحد الخيارات أدناه لإدارة وعرض العشائر.')
    .addFields(
      { name: '👁️ قائمة العشائر', value: 'عرض جميع العشائر المتاحة', inline: true },
      { name: '👑 عشيرتي', value: 'عرض معلومات عشيرتك الحالية', inline: true },
      { name: '➕ انضمام لعشيرة', value: 'الانضمام إلى عشيرة موجودة', inline: true },
      { name: '🛠️ إنشاء عشيرة', value: 'إنشاء عشيرة جديدة', inline: true },
      { name: '💰 التبرع للعشيرة', value: 'تقديم تبرع لعشيرتك', inline: true },
      { name: '❌ مغادرة العشيرة', value: 'مغادرة عشيرتك الحالية', inline: true }
    );
  
  const buttons = createClansButtons();
  
  await interaction.reply({ embeds: [embed], components: buttons });
}

// ===== معالجة أزرار الأقسام الفرعية =====

/**
 * معالجة أزرار قسم الملف الشخصي
 */
async function handleProfileButton(
  interaction: ButtonInteraction,
  customId: string
): Promise<void> {
  // هنا سنقوم باستدعاء الأوامر المناسبة على النظام الحالي
  // سنستخدم رسائل مؤقتة للإشارة إلى عمل الوظائف
  
  switch (customId) {
    case 'profile_view':
      await interaction.reply({ 
        content: 'جاري عرض الملف الشخصي... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
    
    case 'profile_wallet':
      await interaction.reply({ 
        content: 'جاري عرض المحفظة... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    case 'profile_inventory':
      await interaction.reply({ 
        content: 'جاري عرض الحقيبة... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    case 'profile_color':
      await interaction.reply({ 
        content: 'جاري فتح قائمة تغيير اللون... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    case 'profile_transfer':
      await interaction.reply({ 
        content: 'جاري فتح نافذة تحويل العملات... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    default:
      await interaction.reply({
        content: 'عذراً، هذا الخيار غير متاح حالياً',
        ephemeral: true
      });
  }
}

/**
 * معالجة أزرار قسم المتجر
 */
async function handleShopButton(
  interaction: ButtonInteraction,
  customId: string
): Promise<void> {
  switch (customId) {
    case 'shop_view':
      await interaction.reply({ 
        content: 'جاري عرض المتجر... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
    
    case 'shop_colors':
      await interaction.reply({ 
        content: 'جاري عرض متجر الألوان... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    case 'shop_items':
      await interaction.reply({ 
        content: 'جاري عرض متجر العناصر... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    case 'shop_boxes':
      await interaction.reply({ 
        content: 'جاري عرض صناديق الحظ... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    case 'shop_coupon':
      await interaction.reply({ 
        content: 'جاري فتح نافذة استخدام الكوبونات... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    default:
      await interaction.reply({
        content: 'عذراً، هذا الخيار غير متاح حالياً',
        ephemeral: true
      });
  }
}

/**
 * معالجة أزرار قسم المستويات
 */
async function handleLevelsButton(
  interaction: ButtonInteraction,
  customId: string
): Promise<void> {
  switch (customId) {
    case 'levels_leaderboard':
      await interaction.reply({ 
        content: 'جاري عرض المتصدرين... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
    
    case 'levels_next':
      await interaction.reply({ 
        content: 'جاري عرض متطلبات المستوى التالي... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    case 'levels_challenges':
      await interaction.reply({ 
        content: 'جاري عرض التحديات... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    default:
      await interaction.reply({
        content: 'عذراً، هذا الخيار غير متاح حالياً',
        ephemeral: true
      });
  }
}

/**
 * معالجة أزرار قسم الألوان
 */
async function handleColorsButton(
  interaction: ButtonInteraction,
  customId: string
): Promise<void> {
  switch (customId) {
    case 'colors_view':
      await interaction.reply({ 
        content: 'جاري عرض الألوان المتاحة... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
    
    case 'colors_preview':
      await interaction.reply({ 
        content: 'جاري فتح نافذة معاينة الألوان... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    case 'colors_set':
      await interaction.reply({ 
        content: 'جاري فتح نافذة تعيين اللون... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    case 'colors_weekly':
      await interaction.reply({ 
        content: 'جاري عرض الألوان الأسبوعية... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    default:
      await interaction.reply({
        content: 'عذراً، هذا الخيار غير متاح حالياً',
        ephemeral: true
      });
  }
}

/**
 * معالجة أزرار قسم الاقتباسات
 */
async function handleQuotesButton(
  interaction: ButtonInteraction,
  customId: string
): Promise<void> {
  switch (customId) {
    case 'quotes_view':
      await interaction.reply({ 
        content: 'جاري عرض الاقتباسات... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
    
    case 'quotes_add':
      await interaction.reply({ 
        content: 'جاري فتح نافذة إضافة اقتباس... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    case 'quotes_random':
      await interaction.reply({ 
        content: 'جاري عرض اقتباس عشوائي... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    default:
      await interaction.reply({
        content: 'عذراً، هذا الخيار غير متاح حالياً',
        ephemeral: true
      });
  }
}

/**
 * معالجة أزرار قسم العشائر
 */
async function handleClansButton(
  interaction: ButtonInteraction,
  customId: string
): Promise<void> {
  switch (customId) {
    case 'clans_list':
      await interaction.reply({ 
        content: 'جاري عرض قائمة العشائر المتاحة... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
    
    case 'clans_myclan':
      await interaction.reply({ 
        content: 'جاري عرض معلومات عشيرتك الحالية... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    case 'clans_join':
      await interaction.reply({ 
        content: 'جاري فتح نافذة الانضمام للعشيرة... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    case 'clans_create':
      await interaction.reply({ 
        content: 'جاري فتح نافذة إنشاء عشيرة... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    case 'clans_donate':
      await interaction.reply({ 
        content: 'جاري فتح نافذة التبرع للعشيرة... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    case 'clans_leave':
      await interaction.reply({ 
        content: 'جاري مغادرة العشيرة الحالية... سيتم تنفيذ هذا من خلال نظام الـ Python',
        ephemeral: true 
      });
      break;
      
    default:
      await interaction.reply({
        content: 'عذراً، هذا الخيار غير متاح حالياً',
        ephemeral: true
      });
  }
}

// ===== أمر عرض القائمة الرئيسية =====

/**
 * أمر لعرض القائمة الرئيسية التفاعلية
 */
export async function executeInteractiveMenuCommand(interaction: any): Promise<void> {
  try {
    const user = interaction.user;
    
    // إنشاء الإطار الأساسي مع تصميم أكثر جاذبية
    const embed = new EmbedBuilder()
      .setColor('#9B59B6') // لون أكثر جاذبية
      .setTitle('✨ نظام أركانيا - القائمة التفاعلية ✨')
      .setDescription(`مرحباً ${user.username}! 👋 استخدم الأزرار أدناه للتنقل بين ميزات النظام بطريقة سهلة ومرئية.`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { 
          name: '👤 الملف الشخصي', 
          value: '```عرض معلوماتك الشخصية، المستوى، الخبرة، والحقيبة```', 
          inline: false 
        },
        { 
          name: '🛒 المتجر', 
          value: '```شراء ألوان، عناصر، وصناديق حظ وتفعيل الكوبونات```', 
          inline: false 
        },
        { 
          name: '📊 المستويات والتحديات', 
          value: '```عرض المتصدرين، متطلبات المستوى التالي، والتحديات المتاحة```', 
          inline: false 
        },
        { 
          name: '🎨 الألوان والتخصيص', 
          value: '```تخصيص مظهرك باستخدام مجموعة متنوعة من الألوان```', 
          inline: false 
        },
        { 
          name: '💬 الاقتباسات', 
          value: '```إضافة وعرض اقتباساتك المفضلة```', 
          inline: false 
        },
        { 
          name: '👑 نظام العشائر', 
          value: '```إنشاء وإدارة العشائر، حروب عشائر، وتفاعلات العشيرة```', 
          inline: false 
        }
      )
      .setImage('https://i.imgur.com/XSVUYyz.png') // صورة توضيحية عامة
      .setFooter({ 
        text: `استخدم الأزرار للتنقل بين الميزات • ${new Date().toLocaleDateString('ar-AE')}`,
        iconURL: 'https://i.imgur.com/XTtmMSQ.png'
      });
    
    // إنشاء الأزرار مع تصميم محسن
    const buttons = createMainMenuButtons();
    
    // إضافة صف أزرار إضافي للوصول السريع
    const quickAccessRow = new ActionRowBuilder<ButtonBuilder>()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('quick_profile')
          .setLabel('الملف الشخصي السريع')
          .setStyle(ButtonStyle.Success)
          .setEmoji('👤'),
        new ButtonBuilder()
          .setCustomId('quick_leaderboard')
          .setLabel('المتصدرين')
          .setStyle(ButtonStyle.Success)
          .setEmoji('🏆'),
        new ButtonBuilder()
          .setCustomId('quick_help')
          .setLabel('مساعدة')
          .setStyle(ButtonStyle.Primary)
          .setEmoji('❓')
      );
    
    // إضافة جميع صفوف الأزرار
    const allComponents = [...buttons, quickAccessRow];
    
    // الرد على التفاعل مع رسالة تنبيه
    await interaction.reply({ 
      embeds: [embed], 
      components: allComponents,
      content: '**📢 نظام التنقل الجديد للبوت!** استخدم الأزرار للوصول إلى جميع الميزات بسهولة ودون الحاجة لكتابة أوامر.'
    });
    
    console.log(`تم تنفيذ أمر القائمة التفاعلية بواسطة المستخدم: ${interaction.user.tag}`);
  } catch (error) {
    console.error('خطأ في تنفيذ أمر القائمة التفاعلية:', error);
    // محاولة الرد مع رسالة خطأ
    try {
      await interaction.reply({ 
        content: '❌ عذراً، حدث خطأ أثناء تحميل القائمة التفاعلية. يرجى المحاولة مرة أخرى.', 
        ephemeral: true 
      });
    } catch (replyError) {
      console.error('خطأ في إرسال رسالة الخطأ:', replyError);
    }
  }
}
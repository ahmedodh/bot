import { 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle, 
  StringSelectMenuBuilder, 
  StringSelectMenuOptionBuilder,
  EmbedBuilder,
  Colors,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} from 'discord.js';

/**
 * إنشاء عرض ملف شخصي تفاعلي مع أزرار
 * @param userId معرف المستخدم
 * @param username اسم المستخدم
 * @param level المستوى الحالي
 * @param xp نقاط الخبرة
 * @param coins العملات
 * @param rank الرتبة
 * @param color لون الملف الشخصي
 * @param isVip حالة الـ VIP
 */
export function createProfileView(
  userId: string,
  username: string,
  level: number,
  xp: number,
  coins: number,
  rank: string,
  color: string = '#3498db',
  isVip: boolean = false
): { embed: EmbedBuilder, components: ActionRowBuilder<ButtonBuilder>[] } {
  // إنشاء شريط التقدم
  const currentLevelXp = (level - 1) * 1000;
  const nextLevelXp = level * 1000;
  const progress = Math.min(1, (xp - currentLevelXp) / 1000);
  const progressBar = createProgressBar(progress, 15, color);
  
  // إنشاء Embed
  const embed = new EmbedBuilder()
    .setColor(color as `#${string}`)
    .setTitle(`ملف ${username} الشخصي`)
    .setThumbnail('attachment://profile.png') // يجب إنشاء وإرسال الصورة مع الـ embed
    .addFields(
      { name: '🏆 المستوى', value: level.toString(), inline: true },
      { name: '⭐ العملات', value: coins.toString(), inline: true },
      { name: '👑 الرتبة', value: rank, inline: true },
      { name: '📊 التقدم', value: `${progressBar} (${xp % 1000}/1000)` },
    )
    .setFooter({ text: isVip ? '🌟 عضو VIP 🌟' : 'عضو عادي' })
    .setTimestamp();
  
  // إنشاء أزرار التفاعل
  const row1 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId(`profile_shop_${userId}`)
        .setLabel('المتجر')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('🛒'),
      new ButtonBuilder()
        .setCustomId(`profile_inventory_${userId}`)
        .setLabel('حقيبتي')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('🎒'),
      new ButtonBuilder()
        .setCustomId(`profile_leaderboard_${userId}`)
        .setLabel('المتصدرون')
        .setStyle(ButtonStyle.Success)
        .setEmoji('🏆')
    );
    
  const row2 = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId(`profile_quotes_${userId}`)
        .setLabel('اقتباساتي')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('📜'),
      new ButtonBuilder()
        .setCustomId(`profile_color_${userId}`)
        .setLabel('تغيير اللون')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('🎨'),
      new ButtonBuilder()
        .setCustomId(`profile_transfer_${userId}`)
        .setLabel('تحويل عملات')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('💸')
    );
  
  return { embed, components: [row1, row2] };
}

/**
 * إنشاء متجر تفاعلي مع قائمة منسدلة وأزرار
 * @param items قائمة العناصر المتاحة
 * @param userCoins عملات المستخدم الحالية
 */
export function createShopView(
  items: Array<{ id: number, name: string, description: string, price: number, type: string }>,
  userCoins: number
): { embed: EmbedBuilder, components: Array<ActionRowBuilder<any>> } {
  // تصنيف العناصر حسب النوع
  const itemsByType: Record<string, typeof items> = {};
  items.forEach(item => {
    if (!itemsByType[item.type]) {
      itemsByType[item.type] = [];
    }
    itemsByType[item.type].push(item);
  });
  
  // إنشاء Embed
  const embed = new EmbedBuilder()
    .setColor(Colors.Gold)
    .setTitle('🛒 متجر العناصر')
    .setDescription(`رصيدك الحالي: ${userCoins} عملة`)
    .setFooter({ text: 'اختر التصنيف ثم اضغط على عنصر للشراء' })
    .setTimestamp();
  
  // إضافة تفاصيل العناصر (الفئة الافتراضية الأولى)
  const defaultType = Object.keys(itemsByType)[0];
  if (defaultType && itemsByType[defaultType].length > 0) {
    itemsByType[defaultType].forEach(item => {
      embed.addFields({
        name: `${item.name} (${item.price} عملة)`,
        value: item.description
      });
    });
  }
  
  // إنشاء القائمة المنسدلة للتصنيفات
  const categorySelect = new ActionRowBuilder<StringSelectMenuBuilder>()
    .addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('shop_category_select')
        .setPlaceholder('اختر التصنيف')
        .addOptions(
          Object.keys(itemsByType).map(type => 
            new StringSelectMenuOptionBuilder()
              .setLabel(getCategoryLabel(type))
              .setValue(type)
              .setDescription(`عناصر ${getCategoryLabel(type)}`)
              .setDefault(type === defaultType)
          )
        )
    );
  
  // إنشاء أزرار الشراء
  const buttonsRow = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('shop_refresh')
        .setLabel('تحديث')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('🔄'),
      new ButtonBuilder()
        .setCustomId('shop_redeem_coupon')
        .setLabel('استخدام كوبون')
        .setStyle(ButtonStyle.Success)
        .setEmoji('🎟️'),
      new ButtonBuilder()
        .setCustomId('shop_random_box')
        .setLabel('صناديق الحظ')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('🎁')
    );
  
  return { embed, components: [categorySelect, buttonsRow] };
}

/**
 * إنشاء نافذة لإضافة اقتباس جديد
 */
export function createAddQuoteModal(): ModalBuilder {
  return new ModalBuilder()
    .setCustomId('add_quote_modal')
    .setTitle('إضافة اقتباس جديد')
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>()
        .addComponents(
          new TextInputBuilder()
            .setCustomId('quote_text')
            .setLabel('نص الاقتباس')
            .setStyle(TextInputStyle.Paragraph)
            .setMinLength(3)
            .setMaxLength(200)
            .setPlaceholder('أدخل اقتباسك هنا...')
            .setRequired(true)
        ),
      new ActionRowBuilder<TextInputBuilder>()
        .addComponents(
          new TextInputBuilder()
            .setCustomId('quote_author')
            .setLabel('المؤلف (اختياري)')
            .setStyle(TextInputStyle.Short)
            .setMaxLength(50)
            .setPlaceholder('من قال هذا الاقتباس؟')
            .setRequired(false)
        )
    );
}

/**
 * إنشاء شريط تقدم نصي
 */
function createProgressBar(progress: number, length: number = 10, color: string = '#3498db'): string {
  const filledLength = Math.round(progress * length);
  const emptyLength = length - filledLength;
  
  // استخدام رموز مختلفة حسب اللون
  let filledChar = '█';
  if (color.toLowerCase() === '#ff0000' || color.toLowerCase() === 'red') {
    filledChar = '🔴';
  } else if (color.toLowerCase() === '#00ff00' || color.toLowerCase() === 'green') {
    filledChar = '🟢';
  } else if (color.toLowerCase() === '#ffff00' || color.toLowerCase() === 'yellow') {
    filledChar = '🟡';
  } else if (color.toLowerCase() === '#9932cc' || color.toLowerCase() === 'purple') {
    filledChar = '🟣';
  }
  
  return filledChar.repeat(filledLength) + '⬜'.repeat(emptyLength);
}

/**
 * الحصول على اسم التصنيف المناسب
 */
function getCategoryLabel(type: string): string {
  const labels: Record<string, string> = {
    'VIP': 'العضويات المميزة',
    'COLOR': 'الألوان المخصصة',
    'QUOTE': 'الاقتباسات',
    'RANDOM': 'صناديق الحظ',
    'SPECIAL': 'عناصر خاصة',
    'BACKGROUND': 'خلفيات الملف الشخصي'
  };
  
  return labels[type] || type;
}

/**
 * إنشاء عرض للألوان المتاحة
 */
export function createColorsView(
  permanentColors: Array<{ code: string, name: string, price: number }>,
  weeklyColors: Array<{ code: string, name: string, price: number }>,
  resetDate: Date
): { embed: EmbedBuilder, components: ActionRowBuilder<ButtonBuilder>[] } {
  // إنشاء Embed
  const embed = new EmbedBuilder()
    .setColor(Colors.Blue)
    .setTitle('🎨 الألوان المتاحة')
    .setDescription(`الألوان الأسبوعية ستتجدد في: ${resetDate.toLocaleDateString('ar-SA')}`)
    .addFields(
      { name: '🔷 الألوان الدائمة', value: permanentColors.length > 0 ? 
        permanentColors.map(c => `• ${c.name} (${c.code}) - ${c.price} عملة`).join('\n') : 
        'لا توجد ألوان دائمة حالياً' 
      },
      { name: '🔶 الألوان الأسبوعية', value: weeklyColors.length > 0 ? 
        weeklyColors.map(c => `• ${c.name} (${c.code}) - ${c.price} عملة`).join('\n') : 
        'لا توجد ألوان أسبوعية حالياً' 
      }
    )
    .setFooter({ text: 'استخدم /preview-color لمعاينة لون معين' });
  
  // إنشاء أزرار الشراء
  const row = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('colors_permanent')
        .setLabel('شراء لون دائم')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('colors_weekly')
        .setLabel('شراء لون أسبوعي')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('colors_preview')
        .setLabel('معاينة لون')
        .setStyle(ButtonStyle.Secondary)
    );
  
  return { embed, components: [row] };
}

/**
 * إنشاء عنصر تفاعلي لتحويل العملات
 */
export function createTransferCoinsModal(userId: string): ModalBuilder {
  return new ModalBuilder()
    .setCustomId(`transfer_coins_modal_${userId}`)
    .setTitle('تحويل العملات')
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>()
        .addComponents(
          new TextInputBuilder()
            .setCustomId('recipient_id')
            .setLabel('معرف المستلم')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('أدخل معرف المستخدم المستلم')
            .setRequired(true)
        ),
      new ActionRowBuilder<TextInputBuilder>()
        .addComponents(
          new TextInputBuilder()
            .setCustomId('amount')
            .setLabel('المبلغ')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('أدخل عدد العملات للتحويل')
            .setRequired(true)
        )
    );
}
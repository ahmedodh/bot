import { db } from "../db";
import { commands, commandRecommendations } from "@shared/schema";
import { eq, and, desc, sql, or } from "drizzle-orm";
import { analyzeTextContent } from "../ai/chatgpt";

// أقصى عدد للتوصيات
const MAX_RECOMMENDATIONS = 5;

/**
 * تحليل نص الرسالة واقتراح الأوامر المناسبة
 * @param messageContent محتوى الرسالة
 * @param userId معرف مستخدم ديسكورد
 */
export async function getRecommendedCommands(
  messageContent: string,
  userId: string
): Promise<Array<{ id: number; name: string; description: string; weight: number }>> {
  try {
    // 1. استخراج الكلمات الأساسية والنية من محتوى الرسالة
    const context = await extractContextFromMessage(messageContent);
    
    // 2. البحث عن التوصيات المخصصة للمستخدم أولاً
    let recommendations = await findPersonalizedRecommendations(userId, context);
    
    // 3. إذا لم يتم العثور على توصيات شخصية كافية، ابحث عن التوصيات العامة
    if (recommendations.length < MAX_RECOMMENDATIONS) {
      const generalRecs = await findGeneralRecommendations(context, recommendations.map(r => r.id));
      recommendations = [...recommendations, ...generalRecs].slice(0, MAX_RECOMMENDATIONS);
    }
    
    return recommendations;
  } catch (error) {
    console.error("خطأ في الحصول على الأوامر الموصى بها:", error);
    return [];
  }
}

/**
 * استخراج السياق من محتوى الرسالة
 */
async function extractContextFromMessage(messageContent: string): Promise<string[]> {
  try {
    // استخدام التحليل البسيط لاستخراج الكلمات الرئيسية
    // عدم استخدام toLowerCase() للغة العربية لأنها لا تعتمد على الأحرف الكبيرة والصغيرة
    const words = messageContent.split(/\s+/);
    
    // قائمة كلمات مهمة للبحث عنها مباشرة
    const importantWords = [
      // كلمات الملف الشخصي
      'ملف', 'شخصي', 'مستوى', 'نقاط', 'خبرة', 'رتبة', 'بروفايل', 'بطاقة',
      
      // كلمات اللون
      'لون', 'الوان', 'ألوان', 'تلوين', 'تغيير', 'هيكس',
      
      // كلمات المتجر
      'شراء', 'متجر', 'عناصر', 'بضائع', 'سلع', 'دكان', 'سوق', 'بيع',
      
      // كلمات المتصدرين
      'متصدر', 'تصدر', 'قائمة', 'ترتيب', 'افضل', 'تصنيف', 'اعلى', 'أعلى',
      'مراكز', 'أفضل', 'قمة', 'لائحة', 'ليدربورد'
    ];
    
    // البحث في عبارات متكاملة (أكثر من كلمة)
    const phrases = [
      ['ملف', 'شخصي'],
      ['تغيير', 'لون'],
      ['شراء', 'لون'],
      ['شراء', 'عنصر'],
      ['لائحة', 'المتصدرين'],
      ['قائمة', 'المتصدرين'],
      ['المراكز', 'الأولى'],
      ['أفضل', 'لاعبين'],
      ['أعلى', 'مستوى']
    ];
    
    // فحص العبارات المتكاملة
    const foundPhrases = [];
    for (const phrase of phrases) {
      const phraseStr = phrase.join(' ');
      if (messageContent.includes(phraseStr)) {
        foundPhrases.push(phraseStr);
      }
    }
    
    // معالجة الأسئلة الاستفهامية الشائعة
    const commonQuestions = {
      'كيف': ['طريقة', 'استخدام', 'كيفية'],
      'اريد': ['أريد', 'ابغى', 'أبغى', 'ابي', 'أبي', 'عايز'],
      'وين': ['أين', 'فين', 'وين'],
      'ما هو': ['ماهو', 'إيه', 'ايه', 'شنو']
    };
    
    // معالجة كلمات الاستفهام
    for (const [base, variations] of Object.entries(commonQuestions)) {
      for (const variation of variations) {
        if (messageContent.includes(variation)) {
          words.push(base); // إضافة الكلمة الأساسية
          break;
        }
      }
    }
    
    // دمج الكلمات المهمة التي وجدت مع الكلمات المستخرجة من النص
    const foundWords = importantWords.filter(word => messageContent.includes(word));
    const extractedKeywords = words.filter(word => word.length > 2).slice(0, 3);
    
    // دمج القوائم وإزالة التكرار
    const allKeywords = [...foundPhrases, ...foundWords, ...extractedKeywords];
    const keywords = Array.from(new Set(allKeywords)).slice(0, 7);
    
    // استخدام تحليل بسيط فقط دون OpenAI لتجنب تجاوز الحصة
  // في الإصدار الإنتاجي يمكن استخدام OpenAI عند الحاجة
  /*
  if (messageContent.length > 30) {
    try {
      const aiAnalysis = await analyzeTextContent(messageContent);
      if (aiAnalysis && aiAnalysis.keywords && aiAnalysis.keywords.length > 0) {
        return aiAnalysis.keywords;
      }
    } catch {
      console.log("تعذر استخدام OpenAI للتحليل، سيتم استخدام التحليل البسيط");
    }
  }
  */

    return keywords;
  } catch (error) {
    console.error("خطأ في استخراج السياق من الرسالة:", error);
    return [];
  }
}

/**
 * البحث عن التوصيات المخصصة للمستخدم
 */
async function findPersonalizedRecommendations(
  userId: string,
  contextKeywords: string[]
): Promise<Array<{ id: number; name: string; description: string; weight: number }>> {
  try {
    // بناء شرط البحث للكلمات المفتاحية
    const contextConditions = contextKeywords.map(keyword => 
      sql`${commandRecommendations.contextPattern} LIKE ${`%${keyword}%`}`
    );
    
    // الحصول على التوصيات المخصصة للمستخدم
    const userRecommendations = await db
      .select({
        id: commands.id,
        name: commands.name,
        description: commands.description,
        weight: commandRecommendations.weight,
      })
      .from(commandRecommendations)
      .innerJoin(commands, eq(commandRecommendations.commandId, commands.id))
      .where(
        and(
          eq(commandRecommendations.userId, userId),
          eq(commandRecommendations.isPersonalized, true),
          eq(commands.enabled, true),
          contextKeywords.length > 0 
            ? (contextConditions.length === 1 ? contextConditions[0] : or(...contextConditions))
            : sql`1=1`
        )
      )
      .orderBy(desc(commandRecommendations.weight))
      .limit(MAX_RECOMMENDATIONS);
      
    return userRecommendations;
  } catch (error) {
    console.error("خطأ في البحث عن التوصيات المخصصة:", error);
    return [];
  }
}

/**
 * البحث عن التوصيات العامة
 */
async function findGeneralRecommendations(
  contextKeywords: string[],
  excludeIds: number[] = []
): Promise<Array<{ id: number; name: string; description: string; weight: number }>> {
  try {
    // بناء شرط البحث للكلمات المفتاحية
    const contextConditions = contextKeywords.map(keyword => 
      sql`${commandRecommendations.contextPattern} LIKE ${`%${keyword}%`}`
    );
    
    // بناء شرط استبعاد الأوامر المكررة
    const exclusionCondition = excludeIds.length > 0 
      ? sql`${commands.id} NOT IN (${excludeIds.join(',')})` 
      : sql`1=1`;
    
    // الحصول على التوصيات العامة
    const generalRecommendations = await db
      .select({
        id: commands.id,
        name: commands.name,
        description: commands.description,
        weight: commandRecommendations.weight,
      })
      .from(commandRecommendations)
      .innerJoin(commands, eq(commandRecommendations.commandId, commands.id))
      .where(
        and(
          eq(commandRecommendations.isPersonalized, false),
          eq(commands.enabled, true),
          exclusionCondition,
          contextKeywords.length > 0 
            ? (contextConditions.length === 1 ? contextConditions[0] : or(...contextConditions))
            : sql`1=1`
        )
      )
      .orderBy(desc(commandRecommendations.weight))
      .limit(MAX_RECOMMENDATIONS);
      
    return generalRecommendations;
  } catch (error) {
    console.error("خطأ في البحث عن التوصيات العامة:", error);
    return [];
  }
}

/**
 * تحديث وزن التوصية عند استخدام الأمر
 */
export async function incrementCommandWeight(
  userId: string, 
  commandId: number, 
  contextPattern: string
): Promise<void> {
  try {
    // البحث عن توصية موجودة
    const existingRec = await db
      .select()
      .from(commandRecommendations)
      .where(
        and(
          eq(commandRecommendations.userId, userId),
          eq(commandRecommendations.commandId, commandId),
          eq(commandRecommendations.contextPattern, contextPattern)
        )
      )
      .limit(1);
    
    if (existingRec.length > 0) {
      // تحديث وزن وعدد مرات الاستخدام للتوصية الموجودة
      await db
        .update(commandRecommendations)
        .set({
          weight: existingRec[0].weight + 1,
          usageCount: existingRec[0].usageCount + 1,
          lastUsed: new Date(),
        })
        .where(eq(commandRecommendations.id, existingRec[0].id));
    } else {
      // إنشاء توصية جديدة
      await db.insert(commandRecommendations).values({
        userId,
        commandId,
        contextPattern,
        weight: 10, // القيمة الافتراضية
        isPersonalized: true,
        usageCount: 1,
        lastUsed: new Date(),
      });
    }
  } catch (error) {
    console.error("خطأ في تحديث وزن الأمر:", error);
  }
}

/**
 * إنشاء توصيات أوامر عامة للجميع
 * يمكن استخدامها من قبل المسؤول لإضافة توصيات مفيدة
 */
export async function createGlobalRecommendation(
  commandId: number, 
  contextPatterns: string[]
): Promise<void> {
  try {
    for (const pattern of contextPatterns) {
      await db.insert(commandRecommendations).values({
        userId: "global", // استخدام قيمة خاصة للإشارة إلى أنها توصية عامة
        commandId,
        contextPattern: pattern,
        weight: 50, // وزن أعلى للتوصيات العامة
        isPersonalized: false,
        usageCount: 1,
        lastUsed: new Date(),
      });
    }
  } catch (error) {
    console.error("خطأ في إنشاء توصية عامة:", error);
  }
}

/**
 * تحليل تاريخ استخدام المستخدم للأوامر وإنشاء توصيات مخصصة
 */
export async function generatePersonalizedRecommendations(userId: string): Promise<void> {
  // هنا يمكن إضافة منطق لتحليل أنماط استخدام المستخدم وإنشاء توصيات شخصية
  // يمكن استخدامها في جدولة دورية لتحديث التوصيات الشخصية
}
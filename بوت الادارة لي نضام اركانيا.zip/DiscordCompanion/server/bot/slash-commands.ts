import { 
  Client, 
  SlashCommandBuilder, 
  REST, 
  Routes, 
  ChatInputCommandInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  EmbedBuilder,
  Colors,
  AttachmentBuilder,
  ButtonInteraction
} from 'discord.js';
import * as fs from 'fs';
import { join } from 'path';
import { askChatGPT, generateImage } from '../ai/chatgpt';
import { addInteraction } from './self-learning';
import { executeInteractiveMenuCommand } from './interactive-buttons';

// مجموعة الأوامر (slash commands) المتاحة
const commands = [
  new SlashCommandBuilder()
    .setName('menu')
    .setDescription('عرض القائمة التفاعلية الرئيسية'),
  
  new SlashCommandBuilder()
    .setName('ai-ask')
    .setDescription('اطرح سؤالاً على الذكاء الاصطناعي')
    .addStringOption(option => 
      option.setName('سؤال')
        .setDescription('السؤال الذي تريد طرحه على الذكاء الاصطناعي')
        .setRequired(true)),
  
  new SlashCommandBuilder()
    .setName('ai-generate-image')
    .setDescription('توليد صورة باستخدام الذكاء الاصطناعي')
    .addStringOption(option => 
      option.setName('وصف')
        .setDescription('وصف الصورة التي تريد إنشاءها')
        .setRequired(true)),
  
  new SlashCommandBuilder()
    .setName('profile')
    .setDescription('عرض ملفك الشخصي أو ملف شخص آخر')
    .addUserOption(option => 
      option.setName('user')
        .setDescription('المستخدم المراد عرض ملفه')
        .setRequired(false)),
        
  new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('عرض قائمة المتصدرين'),
    
  new SlashCommandBuilder()
    .setName('shop')
    .setDescription('عرض متجر العناصر والألوان'),
    
  new SlashCommandBuilder()
    .setName('colors')
    .setDescription('عرض الألوان المتاحة حاليًا في النظام'),
    
  new SlashCommandBuilder()
    .setName('preview-color')
    .setDescription('معاينة لون قبل الشراء')
    .addStringOption(option => 
      option.setName('color')
        .setDescription('كود اللون الذي تريد معاينته')
        .setRequired(true)),
        
  new SlashCommandBuilder()
    .setName('set-profile-color')
    .setDescription('تعيين لون الملف الشخصي')
    .addStringOption(option => 
      option.setName('color')
        .setDescription('كود اللون (مثال: #ff0000)')
        .setRequired(true)),
        
  new SlashCommandBuilder()
    .setName('quote')
    .setDescription('إضافة أو عرض اقتباس')
    .addSubcommand(subcommand =>
      subcommand
        .setName('add')
        .setDescription('إضافة اقتباس جديد')
        .addStringOption(option => 
          option.setName('text')
            .setDescription('نص الاقتباس')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('list')
        .setDescription('عرض الاقتباسات الخاصة بك'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('random')
        .setDescription('عرض اقتباس عشوائي')),
        
  new SlashCommandBuilder()
    .setName('transfer')
    .setDescription('تحويل عملات إلى مستخدم آخر')
    .addUserOption(option => 
      option.setName('user')
        .setDescription('المستخدم الذي تريد التحويل إليه')
        .setRequired(true))
    .addIntegerOption(option => 
      option.setName('amount')
        .setDescription('عدد العملات')
        .setRequired(true)),
        
  new SlashCommandBuilder()
    .setName('clan')
    .setDescription('نظام العشائر - عرض وإدارة العشائر بسهولة')
    .addSubcommand(subcommand =>
      subcommand
        .setName('list')
        .setDescription('عرض قائمة بجميع العشائر المتاحة'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('myclan')
        .setDescription('عرض معلومات عشيرتك الحالية'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('create')
        .setDescription('إنشاء عشيرة جديدة')
        .addStringOption(option => 
          option.setName('name')
            .setDescription('اسم العشيرة')
            .setRequired(true))
        .addStringOption(option => 
          option.setName('description')
            .setDescription('وصف العشيرة')
            .setRequired(false)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('join')
        .setDescription('الانضمام إلى عشيرة')
        .addStringOption(option => 
          option.setName('name')
            .setDescription('اسم العشيرة')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('leave')
        .setDescription('مغادرة العشيرة الحالية'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('donate')
        .setDescription('التبرع بعملات لخزينة العشيرة')
        .addIntegerOption(option => 
          option.setName('amount')
            .setDescription('المبلغ المراد التبرع به')
            .setRequired(true)))
];

/**
 * تسجيل أوامر الشرطة المائلة في Discord API
 * مع تحسين آلية التعامل مع الأخطاء وتجاوز مشاكل التخزين المؤقت
 */
export async function registerSlashCommands(client: Client): Promise<void> {
  try {
    console.log('جاري تسجيل أوامر الشرطة المائلة...');
    
    // تأكد من وجود الرمز (token) وهوية التطبيق (client id)
    const token = process.env.DISCORD_TOKEN;
    const clientId = client.user?.id;
    
    if (!token) {
      throw new Error('لم يتم العثور على DISCORD_TOKEN في متغيرات البيئة');
    }
    
    if (!clientId) {
      throw new Error('لم يتم العثور على معرّف العميل (client.user.id) - تأكد من تسجيل الدخول أولاً');
    }
    
    console.log(`تسجيل الأوامر باستخدام معرّف التطبيق: ${clientId}`);
    
    // استخدام إصدار أحدث من REST API
    const rest = new REST({ version: '10' }).setToken(token);
    
    // محاولة مسح الكاش المحتمل أولاً عن طريق جلب الأوامر الحالية
    try {
      console.log('جاري التحقق من الأوامر الحالية...');
      const currentCommands = await rest.get(
        Routes.applicationCommands(clientId)
      ) as any[];
      
      if (currentCommands && currentCommands.length > 0) {
        console.log(`تم العثور على ${currentCommands.length} أمر مسجل مسبقاً.`);
        
        // التحقق من التغييرات لتجنب إعادة التسجيل غير الضرورية
        const currentCommandNames = currentCommands.map(cmd => cmd.name).sort().join(',');
        const newCommandNames = commands.map((cmd: any) => cmd.name).sort().join(',');
        
        if (currentCommandNames === newCommandNames && currentCommands.length === commands.length) {
          console.log('لا توجد تغييرات في الأوامر. تخطي إعادة التسجيل.');
          // رغم ذلك سنعيد التسجيل للتأكد
        }
      }
    } catch (fetchError) {
      console.warn('لم نتمكن من جلب الأوامر الحالية، سنستمر بالتسجيل:', fetchError);
    }
    
    // طباعة معلومات الأوامر التي سيتم تسجيلها
    console.log(`عدد الأوامر المراد تسجيلها: ${commands.length}`);
    console.log('أسماء الأوامر:', commands.map((cmd: any) => cmd.name).join(', '));
    
    // تسجيل الأوامر
    console.log('جاري تسجيل الأوامر الجديدة...');
    const data = await rest.put(
      Routes.applicationCommands(clientId),
      { body: commands }
    );
    
    // طباعة النتيجة
    console.log(`تم تسجيل ${Array.isArray(data) ? data.length : 0} أمر بنجاح`);
    console.log('تم تسجيل أوامر الشرطة المائلة بنجاح');

  } catch (error) {
    console.error('خطأ في تسجيل أوامر الشرطة المائلة:', error);
    // محاولة ثانية مع تأخير في حالة حدوث مشاكل في الاتصال
    console.log('جاري محاولة إعادة التسجيل بعد 5 ثواني...');
    
    setTimeout(async () => {
      try {
        if (!client.user?.id) return;
        const retryRest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN || '');
        await retryRest.put(
          Routes.applicationCommands(client.user.id),
          { body: commands }
        );
        console.log('تمت إعادة تسجيل الأوامر بنجاح في المحاولة الثانية');
      } catch (retryError) {
        console.error('فشلت المحاولة الثانية لتسجيل الأوامر:', retryError);
      }
    }, 5000);
    
    // إضافة معلومات أكثر تفصيلاً حول الخطأ
    if (error instanceof Error) {
      console.error('تفاصيل الخطأ:', error.message);
      console.error('Stack trace:', error.stack);
    }
  }
}

/**
 * التعامل مع أمر ai-ask
 */
export async function handleAiAskCommand(interaction: ChatInputCommandInteraction): Promise<void> {
  const question = interaction.options.getString('سؤال');
  
  if (!question) {
    await interaction.reply({ content: 'يرجى تقديم سؤال صالح', ephemeral: true });
    return;
  }
  
  // الرد الأولي لإظهار أن البوت يعمل
  await interaction.deferReply();
  
  try {
    // استدعاء ChatGPT للحصول على إجابة
    const answer = await askChatGPT(question);
    
    // إنشاء رد منسق
    const embed = new EmbedBuilder()
      .setColor(Colors.Blue)
      .setTitle('إجابة الذكاء الاصطناعي')
      .setDescription(answer)
      .setFooter({ text: 'مدعوم بواسطة GPT-4o' })
      .setTimestamp();
    
    // إضافة أزرار للتقييم
    const row = new ActionRowBuilder<ButtonBuilder>()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('ai_feedback_good')
          .setLabel('👍 جيد')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('ai_feedback_bad')
          .setLabel('👎 سيء')
          .setStyle(ButtonStyle.Danger),
      );
    
    await interaction.editReply({ embeds: [embed], components: [row] });
    
    // تسجيل التفاعل في نظام التعلم الذاتي
    addInteraction(interaction.user.id, question, answer);
  } catch (error) {
    console.error('خطأ في معالجة أمر ai-ask:', error);
    await interaction.editReply('عذراً، حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى لاحقاً.');
  }
}

/**
 * التعامل مع أمر ai-generate-image
 */
export async function handleAiGenerateImageCommand(interaction: ChatInputCommandInteraction): Promise<void> {
  const description = interaction.options.getString('وصف');
  
  if (!description) {
    await interaction.reply({ content: 'يرجى تقديم وصف للصورة', ephemeral: true });
    return;
  }
  
  // الرد الأولي لإظهار أن البوت يعمل
  await interaction.deferReply();
  
  try {
    // توليد صورة باستخدام DALL·E
    const result = await generateImage(description);
    
    // تنزيل الصورة محلياً
    const response = await fetch(result.url);
    const buffer = Buffer.from(await response.arrayBuffer());
    
    const filename = `ai_image_${Date.now()}.png`;
    const filepath = join(process.cwd(), 'generated_images', filename);
    
    // التأكد من وجود المجلد
    if (!fs.existsSync(join(process.cwd(), 'generated_images'))) {
      fs.mkdirSync(join(process.cwd(), 'generated_images'), { recursive: true });
    }
    
    fs.writeFileSync(filepath, buffer);
    
    // إنشاء مرفق
    const attachment = new AttachmentBuilder(buffer, { name: filename });
    
    // إنشاء رد منسق
    const embed = new EmbedBuilder()
      .setColor(Colors.Purple)
      .setTitle('صورة مولدة بالذكاء الاصطناعي')
      .setDescription(`**الوصف:** ${description}`)
      .setImage(`attachment://${filename}`)
      .setFooter({ text: 'مدعوم بواسطة DALL·E 3' })
      .setTimestamp();
    
    await interaction.editReply({ embeds: [embed], files: [attachment] });
    
    // تسجيل التفاعل
    addInteraction(interaction.user.id, `Generate image: ${description}`, result.url);
  } catch (error) {
    console.error('خطأ في معالجة أمر ai-generate-image:', error);
    await interaction.editReply('عذراً، حدث خطأ أثناء توليد الصورة. يرجى المحاولة مرة أخرى لاحقاً.');
  }
}

/**
 * التعامل مع التقييم (ردود الفعل على الإجابات)
 */
export async function handleAiFeedback(customId: string, interaction: any): Promise<void> {
  const isGood = customId === 'ai_feedback_good';
  
  // يمكن هنا تسجيل التقييم في نظام التعلم الذاتي
  
  await interaction.reply({ 
    content: `شكراً على تقييمك! ${isGood ? '👍' : '👎'}`, 
    ephemeral: true 
  });
}

/**
 * معالجة أزرار قسم المساعدة
 */
export async function handleHelpButton(customId: string, interaction: ButtonInteraction): Promise<void> {
  switch (customId) {
    case 'help_commands':
      await showCommandList(interaction);
      break;
    case 'help_faq':
      await showFAQ(interaction);
      break;
    default:
      await interaction.reply({
        content: 'عذراً، هذا القسم قيد التطوير حالياً.',
        ephemeral: true
      });
  }
}

/**
 * عرض قائمة الأوامر المتاحة
 */
async function showCommandList(interaction: ButtonInteraction): Promise<void> {
  await interaction.deferReply();

  // إنشاء قائمة الأوامر بتنسيق منظم
  const embed = new EmbedBuilder()
    .setColor('#2ecc71')
    .setTitle('📋 قائمة أوامر البوت')
    .setDescription('فيما يلي قائمة بجميع الأوامر المتاحة في نظام أركانيا. استخدم `/` قبل كل أمر للتفاعل مع البوت.')
    .addFields(
      { 
        name: '🌟 الأوامر العامة', 
        value: '```\n/menu - عرض القائمة التفاعلية الرئيسية\n/profile - عرض ملفك الشخصي\n/leaderboard - قائمة المتصدرين\n```',
        inline: false 
      },
      { 
        name: '🛒 أوامر المتجر والاقتصاد', 
        value: '```\n/shop - عرض متجر العناصر والألوان\n/transfer - تحويل عملات لمستخدم آخر\n/colors - عرض الألوان المتاحة\n```',
        inline: false
      },
      { 
        name: '🧠 أوامر الذكاء الاصطناعي', 
        value: '```\n/ai-ask - اطرح سؤالاً على الذكاء الاصطناعي\n/ai-generate-image - توليد صورة باستخدام الذكاء الاصطناعي\n```',
        inline: false
      },
      { 
        name: '💬 أوامر الاقتباسات', 
        value: '```\n/quote add - إضافة اقتباس جديد\n/quote list - عرض الاقتباسات الخاصة بك\n/quote random - عرض اقتباس عشوائي\n```',
        inline: false
      },
      { 
        name: '👑 أوامر العشائر', 
        value: '```\n/clan list - عرض قائمة العشائر المتاحة\n/clan myclan - عرض عشيرتك الحالية\n/clan create - إنشاء عشيرة جديدة\n/clan join - الانضمام إلى عشيرة\n/clan leave - مغادرة العشيرة\n/clan donate - التبرع للعشيرة\n```',
        inline: false
      }
    )
    .setFooter({ 
      text: 'يمكنك استخدام نظام الأزرار التفاعلية بدلاً من كتابة الأوامر', 
      iconURL: 'https://i.imgur.com/XTtmMSQ.png'
    });

  // إضافة أزرار التنقل
  const navigationRow = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('menu_main')
        .setLabel('العودة للقائمة الرئيسية')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('🏠'),
      new ButtonBuilder()
        .setCustomId('help_faq')
        .setLabel('الأسئلة الشائعة')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('❓')
    );

  await interaction.editReply({
    embeds: [embed],
    components: [navigationRow]
  });
}

/**
 * عرض الأسئلة الشائعة
 */
async function showFAQ(interaction: ButtonInteraction): Promise<void> {
  await interaction.deferReply();

  const embed = new EmbedBuilder()
    .setColor('#3498db')
    .setTitle('❓ الأسئلة الشائعة')
    .setDescription('إليك إجابات عن الأسئلة الأكثر شيوعاً حول نظام أركانيا:')
    .addFields(
      { 
        name: '🔹 كيف أكسب المزيد من الخبرة (XP)؟', 
        value: 'يمكنك كسب الخبرة عن طريق إكمال المهام والتحديات اليومية. نظام الخبرة لا يعتمد على المحادثة العادية بل على إنجاز المهام.',
        inline: false 
      },
      { 
        name: '🔹 ما هي العملات وكيف يمكنني الحصول عليها؟', 
        value: 'العملات هي العملة الرئيسية في النظام. يمكنك كسبها عن طريق الترقية للمستويات الأعلى، وإكمال التحديات والمهام.',
        inline: false 
      },
      { 
        name: '🔹 كيف يعمل نظام العشائر؟', 
        value: 'نظام العشائر بسيط وسهل الاستخدام: استخدم `/clan list` لمشاهدة العشائر المتاحة، ثم `/clan join` للانضمام للعشيرة التي تعجبك. يمكنك أيضاً إنشاء عشيرة خاصة بك عبر `/clan create` (تحتاج مستوى 10 ودفع 1000 عملة). الأزرار التفاعلية تظهر لك كل خيارات العشيرة بشكل واضح ومرتب.',
        inline: false 
      },
      { 
        name: '🔹 ما هي الألوان الأسبوعية؟', 
        value: 'الألوان الأسبوعية هي مجموعة من الألوان المميزة التي تتغير كل يوم سبت. هذه الألوان متاحة للشراء لمدة أسبوع فقط.',
        inline: false 
      },
      { 
        name: '🔹 هل يمكنني تغيير اسم العشيرة؟', 
        value: 'لا يمكن تغيير اسم العشيرة بعد إنشائها، لذا اختر اسماً مناسباً من البداية.',
        inline: false 
      },
      { 
        name: '🔹 كيف أستخدم نظام الأزرار التفاعلية؟', 
        value: 'ببساطة اكتب `/menu` في أي قناة واضغط على الأزرار للتنقل بين الأقسام المختلفة.',
        inline: false 
      }
    )
    .setFooter({ 
      text: 'إذا كان لديك المزيد من الأسئلة، يمكنك استخدام أمر /ai-ask للاستفسار', 
      iconURL: 'https://i.imgur.com/XTtmMSQ.png'
    });

  // إضافة أزرار التنقل
  const navigationRow = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('menu_main')
        .setLabel('العودة للقائمة الرئيسية')
        .setStyle(ButtonStyle.Primary)
        .setEmoji('🏠'),
      new ButtonBuilder()
        .setCustomId('help_commands')
        .setLabel('قائمة الأوامر')
        .setStyle(ButtonStyle.Secondary)
        .setEmoji('📋')
    );

  await interaction.editReply({
    embeds: [embed],
    components: [navigationRow]
  });
}

/**
 * صورة لمعالجة جميع التفاعلات مع أوامر الشرطة المائلة
 */
export async function handleSlashCommand(interaction: ChatInputCommandInteraction): Promise<void> {
  const commandName = interaction.commandName;
  
  try {
    // تسجيل استخدام الأمر في السجل
    console.log(`استخدام أمر: ${commandName} بواسطة المستخدم: ${interaction.user.tag}`);
    
    switch (commandName) {
      case 'ai-ask':
        await handleAiAskCommand(interaction);
        break;
      case 'ai-generate-image':
        await handleAiGenerateImageCommand(interaction);
        break;
      case 'menu':
        await executeInteractiveMenuCommand(interaction);
        break;
        
      // معالجة أوامر الملف الشخصي
      case 'profile':
        // إعادة توجيه إلى نظام الأزرار التفاعلية
        const profileEmbed = new EmbedBuilder()
          .setColor('#3498db')
          .setTitle('📝 نظام الأزرار التفاعلية')
          .setDescription('نحن نستخدم الآن نظام الأزرار التفاعلية لعرض الملف الشخصي بطريقة أفضل!')
          .addFields(
            { name: '👉 كيفية الاستخدام', value: 'اضغط على الزر أدناه لعرض الملف الشخصي بالطريقة الجديدة.' }
          );
          
        const profileRow = new ActionRowBuilder<ButtonBuilder>()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('quick_profile')
              .setLabel('عرض الملف الشخصي')
              .setStyle(ButtonStyle.Primary)
              .setEmoji('👤')
          );
          
        await interaction.reply({ embeds: [profileEmbed], components: [profileRow] });
        break;
        
      // معالجة أمر المتصدرين
      case 'leaderboard':
        // إعادة توجيه إلى نظام الأزرار التفاعلية
        const leaderboardEmbed = new EmbedBuilder()
          .setColor('#f1c40f')
          .setTitle('📝 نظام الأزرار التفاعلية')
          .setDescription('نحن نستخدم الآن نظام الأزرار التفاعلية لعرض المتصدرين بطريقة أفضل!')
          .addFields(
            { name: '👉 كيفية الاستخدام', value: 'اضغط على الزر أدناه لعرض قائمة المتصدرين بالطريقة الجديدة.' }
          );
          
        const leaderboardRow = new ActionRowBuilder<ButtonBuilder>()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('quick_leaderboard')
              .setLabel('عرض المتصدرين')
              .setStyle(ButtonStyle.Primary)
              .setEmoji('🏆')
          );
          
        await interaction.reply({ embeds: [leaderboardEmbed], components: [leaderboardRow] });
        break;
        
      // معالجة أوامر المتجر
      case 'shop':
        // إعادة توجيه إلى نظام الأزرار التفاعلية
        const shopEmbed = new EmbedBuilder()
          .setColor('#e74c3c')
          .setTitle('📝 نظام الأزرار التفاعلية')
          .setDescription('نحن نستخدم الآن نظام الأزرار التفاعلية لعرض المتجر بطريقة أفضل!')
          .addFields(
            { name: '👉 كيفية الاستخدام', value: 'اضغط على أحد الأزرار أدناه للوصول للمتجر والألوان.' }
          );
          
        const shopRows = [
          new ActionRowBuilder<ButtonBuilder>()
            .addComponents(
              new ButtonBuilder()
                .setCustomId('menu_shop')
                .setLabel('فتح المتجر')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('🛒'),
              new ButtonBuilder()
                .setCustomId('menu_colors')
                .setLabel('متجر الألوان')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('🎨')
            )
        ];
          
        await interaction.reply({ embeds: [shopEmbed], components: shopRows });
        break;

      // معالجة أمر الألوان
      case 'colors':
        // إعادة توجيه إلى نظام الأزرار التفاعلية للألوان
        const colorsEmbed = new EmbedBuilder()
          .setColor('#9b59b6')
          .setTitle('📝 نظام الأزرار التفاعلية')
          .setDescription('نحن نستخدم الآن نظام الأزرار التفاعلية لإدارة الألوان بطريقة أفضل!')
          .addFields(
            { name: '👉 كيفية الاستخدام', value: 'اضغط على الزر أدناه للوصول إلى قائمة الألوان والتخصيص.' }
          );
          
        const colorsRow = new ActionRowBuilder<ButtonBuilder>()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('menu_colors')
              .setLabel('فتح قائمة الألوان')
              .setStyle(ButtonStyle.Primary)
              .setEmoji('🎨')
          );
          
        await interaction.reply({ embeds: [colorsEmbed], components: [colorsRow] });
        break;
      
      // معالجة أوامر أخرى من نظام الشرطة المائلة
      default:
        // إرشاد المستخدم للقائمة التفاعلية الجديدة
        const helpEmbed = new EmbedBuilder()
          .setColor('#2ecc71')
          .setTitle('📝 نظام الأزرار التفاعلية الجديد')
          .setDescription('نحن نستخدم الآن نظام الأزرار التفاعلية لجميع الأوامر!')
          .addFields(
            { name: '👉 كيفية الاستخدام', value: 'اضغط على الزر أدناه لفتح القائمة الرئيسية والتنقل بين الميزات المختلفة.' },
            { name: '📚 تغييرات هامة', value: 'الكثير من الأوامر القديمة تم استبدالها بواجهة أزرار سهلة الاستخدام. جربها الآن!' }
          );
          
        const helpRows = [
          new ActionRowBuilder<ButtonBuilder>()
            .addComponents(
              new ButtonBuilder()
                .setCustomId('menu_main')
                .setLabel('فتح القائمة الرئيسية')
                .setStyle(ButtonStyle.Success)
                .setEmoji('🏠'),
              new ButtonBuilder()
                .setCustomId('quick_help')
                .setLabel('عرض المساعدة')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('❓')
            )
        ];
          
        await interaction.reply({ embeds: [helpEmbed], components: helpRows });
    }
  } catch (error) {
    console.error(`خطأ في معالجة الأمر ${commandName}:`, error);
    try {
      const replyMethod = interaction.deferred ? interaction.editReply : interaction.reply;
      await replyMethod.call(interaction, {
        content: 'حدث خطأ أثناء معالجة الأمر، يرجى المحاولة مرة أخرى لاحقاً',
        ephemeral: true
      });
    } catch (e) {
      console.error('خطأ في إرسال رد الخطأ:', e);
    }
  }
}
import { join } from 'path';
import fs from 'fs';
import { analyzeInteractions, suggestCodeImprovements } from '../ai/chatgpt';

// واجهة للتفاعلات المخزنة
interface Interaction {
  userId: string;
  prompt: string;
  response: string;
  timestamp: string;
  feedback?: number; // تقييم من 1-5 أو بلا تقييم
}

// واجهة لنظام التعلم الذاتي
interface SelfLearningSystem {
  interactions: Interaction[];
  insights: {
    lastUpdated: string;
    patterns: string;
    suggestions: string[];
  };
  improvements: {
    lastApplied: string;
    codeChanges: Array<{
      file: string;
      beforeCode: string;
      afterCode: string;
      reason: string;
    }>;
  };
}

// مسار ملف نظام التعلم الذاتي
const SELF_LEARNING_FILE = join(process.cwd(), 'self_learning_data.json');

/**
 * تهيئة نظام التعلم الذاتي
 */
export function initSelfLearningSystem(): void {
  if (!fs.existsSync(SELF_LEARNING_FILE)) {
    const initialData: SelfLearningSystem = {
      interactions: [],
      insights: {
        lastUpdated: new Date().toISOString(),
        patterns: '',
        suggestions: [],
      },
      improvements: {
        lastApplied: new Date().toISOString(),
        codeChanges: [],
      },
    };
    fs.writeFileSync(SELF_LEARNING_FILE, JSON.stringify(initialData, null, 2));
    console.log('تم تهيئة نظام التعلم الذاتي');
  }
}

/**
 * إضافة تفاعل جديد إلى نظام التعلم
 */
export function addInteraction(
  userId: string,
  prompt: string,
  response: string
): void {
  try {
    // قراءة البيانات الحالية
    const data: SelfLearningSystem = JSON.parse(
      fs.readFileSync(SELF_LEARNING_FILE, 'utf8')
    );

    // إضافة التفاعل الجديد
    data.interactions.push({
      userId,
      prompt,
      response,
      timestamp: new Date().toISOString(),
    });

    // حفظ أحدث 1000 تفاعل فقط للحفاظ على أداء النظام
    if (data.interactions.length > 1000) {
      data.interactions = data.interactions.slice(-1000);
    }

    // حفظ البيانات المحدثة
    fs.writeFileSync(SELF_LEARNING_FILE, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('خطأ في إضافة تفاعل جديد:', error);
  }
}

/**
 * إضافة تقييم لتفاعل سابق
 */
export function addFeedback(
  userId: string,
  timestamp: string,
  rating: number
): boolean {
  try {
    // قراءة البيانات الحالية
    const data: SelfLearningSystem = JSON.parse(
      fs.readFileSync(SELF_LEARNING_FILE, 'utf8')
    );

    // البحث عن التفاعل المطلوب
    const interaction = data.interactions.find(
      (i) => i.userId === userId && i.timestamp === timestamp
    );

    if (!interaction) return false;

    // إضافة التقييم
    interaction.feedback = Math.max(1, Math.min(5, rating)); // قيم من 1 إلى 5 فقط

    // حفظ البيانات المحدثة
    fs.writeFileSync(SELF_LEARNING_FILE, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('خطأ في إضافة تقييم:', error);
    return false;
  }
}

/**
 * تحليل التفاعلات وتحديث الرؤى
 */
export async function analyzeAndUpdateInsights(): Promise<void> {
  try {
    // قراءة البيانات الحالية
    const data: SelfLearningSystem = JSON.parse(
      fs.readFileSync(SELF_LEARNING_FILE, 'utf8')
    );

    // تحليل آخر 200 تفاعل للحصول على رؤى جديدة
    const recentInteractions = data.interactions.slice(-200).map((i) => ({
      prompt: i.prompt,
      response: i.response,
      feedback: i.feedback,
    }));

    if (recentInteractions.length < 10) {
      console.log('عدد التفاعلات غير كافٍ للتحليل (أقل من 10)');
      return;
    }

    // استخدام OpenAI لتحليل التفاعلات
    const analysis = await analyzeInteractions(recentInteractions);

    // تحديث الرؤى
    data.insights = {
      lastUpdated: new Date().toISOString(),
      patterns: analysis.insights,
      suggestions: analysis.improvements,
    };

    // حفظ البيانات المحدثة
    fs.writeFileSync(SELF_LEARNING_FILE, JSON.stringify(data, null, 2));
    console.log('تم تحديث رؤى التعلم الذاتي');
  } catch (error) {
    console.error('خطأ في تحليل التفاعلات:', error);
  }
}

/**
 * الحصول على اقتراحات التحسين
 */
export function getSuggestions(): string[] {
  try {
    const data: SelfLearningSystem = JSON.parse(
      fs.readFileSync(SELF_LEARNING_FILE, 'utf8')
    );
    return data.insights.suggestions;
  } catch (error) {
    console.error('خطأ في الحصول على الاقتراحات:', error);
    return [];
  }
}

/**
 * اقتراح تحسينات للكود
 */
export async function suggestImprovements(
  filePath: string,
  context: string
): Promise<{ suggestions: string[]; improvedCode: string } | null> {
  try {
    if (!fs.existsSync(filePath)) {
      console.error('الملف غير موجود:', filePath);
      return null;
    }

    const currentCode = fs.readFileSync(filePath, 'utf8');
    return await suggestCodeImprovements(currentCode, context);
  } catch (error) {
    console.error('خطأ في اقتراح تحسينات للكود:', error);
    return null;
  }
}

/**
 * تطبيق تحسين تلقائي للكود (مع الحذر)
 */
export function applyImprovement(
  filePath: string,
  improvedCode: string,
  reason: string
): boolean {
  try {
    if (!fs.existsSync(filePath)) {
      console.error('الملف غير موجود:', filePath);
      return false;
    }

    // النسخ الاحتياطي للكود الحالي
    const currentCode = fs.readFileSync(filePath, 'utf8');
    const backupPath = `${filePath}.backup.${Date.now()}`;
    fs.writeFileSync(backupPath, currentCode);

    // تحديث الكود
    fs.writeFileSync(filePath, improvedCode);

    // تسجيل التغيير
    const data: SelfLearningSystem = JSON.parse(
      fs.readFileSync(SELF_LEARNING_FILE, 'utf8')
    );

    data.improvements.lastApplied = new Date().toISOString();
    data.improvements.codeChanges.push({
      file: filePath,
      beforeCode: currentCode,
      afterCode: improvedCode,
      reason,
    });

    fs.writeFileSync(SELF_LEARNING_FILE, JSON.stringify(data, null, 2));
    console.log(`تم تطبيق تحسين على الملف: ${filePath}`);
    return true;
  } catch (error) {
    console.error('خطأ في تطبيق التحسين:', error);
    return false;
  }
}

/**
 * جدولة التحليل الدوري (يمكن تشغيله في مهمة خلفية)
 */
export function schedulePeriodicAnalysis(): NodeJS.Timeout {
  // تحليل كل 24 ساعة
  const analysisInterval = 24 * 60 * 60 * 1000;
  console.log('تم جدولة التحليل الدوري للتفاعلات');
  
  return setInterval(async () => {
    console.log('بدء التحليل الدوري للتفاعلات...');
    await analyzeAndUpdateInsights();
  }, analysisInterval);
}

// تهيئة النظام عند تشغيل التطبيق
initSelfLearningSystem();
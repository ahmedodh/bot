import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// تحليل التصميم وتقديم توصيات
export async function analyzeDesign(designDescription: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "أنت خبير في تصميم واجهات المستخدم والتجربة المستخدم. قم بتحليل التصميم المقدم وتقديم توصيات لتحسينه بناءً على المعايير العالمية في التصميم."
        },
        {
          role: "user",
          content: designDescription
        }
      ],
      max_tokens: 1000,
    });

    return response.choices[0].message.content;
  } catch (error) {
    console.error("Error analyzing design:", error);
    throw new Error(`فشل في تحليل التصميم: ${error.message}`);
  }
}

// تحسين محتوى النص
export async function enhanceContent(content: string, context: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `أنت خبير في تحسين المحتوى وتطويره. قم بتحسين المحتوى المقدم ليكون أكثر جاذبية ووضوحاً مع الحفاظ على المعنى الأصلي. السياق: ${context}`
        },
        {
          role: "user",
          content
        }
      ],
      max_tokens: 1000,
    });

    return response.choices[0].message.content;
  } catch (error) {
    console.error("Error enhancing content:", error);
    throw new Error(`فشل في تحسين المحتوى: ${error.message}`);
  }
}

// توليد أفكار مبتكرة
export async function generateIdeas(topic: string, count: number = 5): Promise<string[]> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `أنت خبير في توليد الأفكار المبتكرة. قدم ${count} أفكار إبداعية حول الموضوع المطلوب.`
        },
        {
          role: "user",
          content: topic
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 1000,
    });

    const result = JSON.parse(response.choices[0].message.content);
    return result.ideas || [];
  } catch (error) {
    console.error("Error generating ideas:", error);
    throw new Error(`فشل في توليد أفكار: ${error.message}`);
  }
}

// تحليل وتصحيح الأخطاء في الكود
export async function analyzeAndFixCode(code: string, language: string, problem: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `أنت مبرمج خبير في ${language}. قم بتحليل الكود المقدم وتحديد المشاكل وتقديم حل لها. المشكلة المحددة: ${problem}`
        },
        {
          role: "user",
          content: code
        }
      ],
      max_tokens: 1500,
    });

    return response.choices[0].message.content;
  } catch (error) {
    console.error("Error analyzing code:", error);
    throw new Error(`فشل في تحليل الكود: ${error.message}`);
  }
}

// إنشاء محتوى خاص بحرب العشائر
export async function generateClanWarsContent(prompt: string): Promise<{
  title: string;
  description: string;
  rules: string[];
  rewards: string[];
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "أنت خبير في إنشاء محتوى ألعاب متعلق بحروب العشائر والتحديات الجماعية. قم بإنشاء محتوى شامل يتضمن: عنوانًا، وصفًا، قواعد (كقائمة)، ومكافآت (كقائمة)."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 1000,
    });

    const result = JSON.parse(response.choices[0].message.content);
    return {
      title: result.title || "حرب العشائر",
      description: result.description || "تنافس مع العشائر الأخرى للفوز بجوائز مميزة!",
      rules: result.rules || ["قاعدة 1", "قاعدة 2"],
      rewards: result.rewards || ["مكافأة 1", "مكافأة 2"]
    };
  } catch (error) {
    console.error("Error generating clan wars content:", error);
    throw new Error(`فشل في إنشاء محتوى حرب العشائر: ${error.message}`);
  }
}

// توليد صورة للاستخدام في واجهة التطبيق
export async function generateImage(prompt: string): Promise<string> {
  try {
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt: `${prompt}. High-quality, professional UI element for a Discord bot dashboard. Digital art style.`,
      n: 1,
      size: "1024x1024",
      quality: "standard",
    });

    return response.data[0].url;
  } catch (error) {
    console.error("Error generating image:", error);
    throw new Error(`فشل في إنشاء الصورة: ${error.message}`);
  }
}

// اقتراح تحسينات بناءً على بيانات المستخدم
export async function suggestImprovements(userData: any, systemType: string): Promise<string[]> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `أنت مستشار خبير في تحسين أنظمة ${systemType}. استنادًا إلى بيانات المستخدم المقدمة، قدم اقتراحات لتحسين النظام وتجربة المستخدم.`
        },
        {
          role: "user",
          content: JSON.stringify(userData)
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 1000,
    });

    const result = JSON.parse(response.choices[0].message.content);
    return result.suggestions || [];
  } catch (error) {
    console.error("Error suggesting improvements:", error);
    throw new Error(`فشل في اقتراح تحسينات: ${error.message}`);
  }
}
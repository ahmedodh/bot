import OpenAI from "openai";

// استخدم gpt-4o الذي هو أحدث نموذج من أوبن إيه آي (تم إطلاقه في 13 مايو 2024)
// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user

// واجهة لنتائج تحليل النص
export interface TextAnalysisResult {
  keywords: string[];
  intent: string;
  sentiment: string;
  topics: string[];
}
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

/**
 * طلب إجابة من ChatGPT-4o
 * @param prompt النص المراد إرساله لنموذج الذكاء الاصطناعي
 * @param systemPrompt رسالة النظام الاختيارية
 * @param jsonResponse تحديد ما إذا كان المطلوب استجابة بصيغة JSON
 */
export async function askChatGPT(
  prompt: string,
  systemPrompt?: string,
  jsonResponse: boolean = false
): Promise<string> {
  try {
    const messages = [
      ...(systemPrompt
        ? [{ role: "system" as const, content: systemPrompt }]
        : []),
      { role: "user" as const, content: prompt }
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages,
      ...(jsonResponse ? { response_format: { type: "json_object" } } : {}),
      temperature: 0.7,
    });

    return response.choices[0].message.content || "";
  } catch (error: any) {
    console.error("خطأ في استدعاء ChatGPT:", error.message);
    throw new Error(`فشل في الحصول على رد من الذكاء الاصطناعي: ${error.message}`);
  }
}

/**
 * تحليل المشاعر من نص معين
 * @param text النص المراد تحليله
 */
export async function analyzeSentiment(text: string): Promise<{
  rating: number;
  confidence: number;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content:
            "أنت خبير في تحليل المشاعر. قم بتحليل مشاعر النص وتوفير تقييم من 1 إلى 5 نجوم ودرجة ثقة بين 0 و 1. الرد بصيغة JSON بهذا الشكل: { 'rating': number, 'confidence': number }",
        },
        {
          role: "user",
          content: text,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    return {
      rating: Math.max(1, Math.min(5, Math.round(result.rating || 3))),
      confidence: Math.max(0, Math.min(1, result.confidence || 0.5)),
    };
  } catch (error: any) {
    console.error("خطأ في تحليل المشاعر:", error.message);
    // إرجاع قيمة افتراضية في حالة الخطأ
    return { rating: 3, confidence: 0.5 };
  }
}

/**
 * توليد صورة باستخدام DALL·E 3
 * @param prompt وصف الصورة المطلوبة
 */
export async function generateImage(prompt: string): Promise<{ url: string }> {
  try {
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt,
      n: 1,
      size: "1024x1024",
      quality: "standard",
    });

    return { url: response.data[0].url || "" };
  } catch (error: any) {
    console.error("خطأ في توليد الصورة:", error.message);
    throw new Error(`فشل في توليد الصورة: ${error.message}`);
  }
}

/**
 * تحليل بيانات التفاعلات لاستنتاج الأنماط والاتجاهات
 * @param interactions مصفوفة من التفاعلات السابقة
 */
export async function analyzeInteractions(
  interactions: Array<{ prompt: string; response: string; feedback?: number }>
): Promise<{ insights: string; improvements: string[] }> {
  try {
    const systemPrompt = `
    أنت محلل بيانات خبير متخصص في فهم تفاعلات المستخدمين مع بوتات Discord.
    قم بتحليل مجموعة من التفاعلات (الأسئلة والإجابات والتقييمات) وحدد:
    1. أنماط واتجاهات عامة في الأسئلة
    2. المجالات التي يمكن تحسين إجابات البوت فيها
    3. اقتراحات محددة لتحسين أداء البوت
    قدم استنتاجاتك بتنسيق JSON.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        {
          role: "user",
          content: JSON.stringify(interactions),
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    return {
      insights: result.insights || "لم يتم العثور على أنماط واضحة",
      improvements: result.improvements || [],
    };
  } catch (error: any) {
    console.error("خطأ في تحليل التفاعلات:", error.message);
    return {
      insights: "حدث خطأ أثناء تحليل البيانات",
      improvements: ["تحسين استقرار الاتصال بـ API"],
    };
  }
}

/**
 * تحليل محتوى نص لاستخراج الكلمات المفتاحية والنية والمواضيع
 * @param text النص المراد تحليله
 */
export async function analyzeTextContent(text: string): Promise<TextAnalysisResult | null> {
  try {
    const systemPrompt = `
    أنت محلل لغوي متخصص. قم بتحليل النص المقدم واستخراج:
    1. الكلمات المفتاحية (بين 3 و 5 كلمات)
    2. النية الرئيسية للنص (سؤال، أمر، طلب مساعدة، إلخ)
    3. المشاعر العامة (إيجابي، سلبي، محايد، متحمس، غاضب، إلخ)
    4. المواضيع الرئيسية المتعلقة بالنص (1-3 مواضيع)
    
    قدم النتائج بتنسيق JSON.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: text },
      ],
      response_format: { type: "json_object" },
      temperature: 0.3, // درجة حرارة منخفضة للحصول على نتائج أكثر تحديدًا
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      keywords: result.keywords || [],
      intent: result.intent || "غير محدد",
      sentiment: result.sentiment || "محايد",
      topics: result.topics || [],
    };
  } catch (error: any) {
    console.error("خطأ في تحليل النص:", error.message);
    return null;
  }
}

export async function suggestCodeImprovements(
  code: string,
  context: string
): Promise<{ suggestions: string[]; improvedCode: string }> {
  try {
    const systemPrompt = `
    أنت مطور برمجيات خبير متخصص في تحسين وتنظيف الشيفرة البرمجية.
    قم بتحليل الكود المقدم وضع في اعتبارك:
    1. كفاءة الأداء
    2. قابلية الصيانة
    3. أفضل الممارسات
    4. الأمان
    
    قدم اقتراحات محددة للتحسين وكود محسّن في تنسيق JSON.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        {
          role: "user",
          content: `الكود: ${code}\n\nالسياق: ${context}`,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    return {
      suggestions: result.suggestions || [],
      improvedCode: result.improvedCode || code,
    };
  } catch (error: any) {
    console.error("خطأ في اقتراح تحسينات الكود:", error.message);
    return {
      suggestions: ["حدث خطأ أثناء تحليل الكود"],
      improvedCode: code,
    };
  }
}
import { db } from './db';
import { commands, commandRecommendations } from '../shared/schema';
import { sql } from 'drizzle-orm';

async function seedCommandRecommendations() {
  try {
    console.log('بدء إضافة بيانات توصيات الأوامر...');

    // الحصول على الأوامر الموجودة
    const existingCommands = await db.select().from(commands);
    if (existingCommands.length === 0) {
      console.log('لا توجد أوامر مسجلة في النظام، يرجى إضافة أوامر أولاً');
      
      // إضافة بعض الأوامر للاختبار
      await db.insert(commands).values([
        {
          name: '!profile',
          description: 'عرض ملفك الشخصي',
          usage: '!profile [@user]',
          category: 'مستويات',
          enabled: true
        },
        {
          name: '!shop',
          description: 'متجر العناصر والألوان',
          usage: '!shop',
          category: 'اقتصاد',
          enabled: true
        },
        {
          name: '!color',
          description: 'تغيير لون الملف الشخصي',
          usage: '!color <hex code>',
          category: 'تخصيص',
          enabled: true
        },
        {
          name: '!buy',
          description: 'شراء عنصر من المتجر',
          usage: '!buy <item_id>',
          category: 'اقتصاد',
          enabled: true
        },
        {
          name: '!leaderboard',
          description: 'عرض لوحة المتصدرين',
          usage: '!leaderboard',
          category: 'مستويات',
          enabled: true
        }
      ]);
      
      console.log('تم إضافة أوامر للاختبار');
      
      // الحصول على الأوامر بعد الإضافة
      const newCommands = await db.select().from(commands);
      if (newCommands.length === 0) {
        throw new Error('فشل في إضافة الأوامر');
      }
      
      // استخدام الأوامر الجديدة
      const commandsList = newCommands;
      
      // حذف التوصيات الموجودة أولاً
      await db.delete(commandRecommendations);
      
      // إضافة توصيات عامة
      const recommendations = [
        // توصيات متعلقة بالألوان
        {
          userId: 'global',
          contextPattern: 'لون',
          commandId: commandsList.find(c => c.name === '!color')?.id || 0,
          weight: 50,
          isPersonalized: false,
          usageCount: 10,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'تغيير لون',
          commandId: commandsList.find(c => c.name === '!color')?.id || 0,
          weight: 60,
          isPersonalized: false,
          usageCount: 15,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'شراء لون',
          commandId: commandsList.find(c => c.name === '!shop')?.id || 0,
          weight: 55,
          isPersonalized: false,
          usageCount: 12,
          lastUsed: new Date()
        },
        
        // توصيات متعلقة بالشراء
        {
          userId: 'global',
          contextPattern: 'شراء',
          commandId: commandsList.find(c => c.name === '!buy')?.id || 0,
          weight: 45,
          isPersonalized: false,
          usageCount: 8,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'متجر',
          commandId: commandsList.find(c => c.name === '!shop')?.id || 0,
          weight: 50,
          isPersonalized: false,
          usageCount: 10,
          lastUsed: new Date()
        },
        
        // توصيات متعلقة بالملف الشخصي
        {
          userId: 'global',
          contextPattern: 'ملف',
          commandId: commandsList.find(c => c.name === '!profile')?.id || 0,
          weight: 40,
          isPersonalized: false,
          usageCount: 7,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'مستوى',
          commandId: commandsList.find(c => c.name === '!profile')?.id || 0,
          weight: 35,
          isPersonalized: false,
          usageCount: 5,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'متصدر',
          commandId: commandsList.find(c => c.name === '!leaderboard')?.id || 0,
          weight: 40,
          isPersonalized: false,
          usageCount: 6,
          lastUsed: new Date()
        }
      ];
      
      for (const rec of recommendations) {
        if (rec.commandId === 0) {
          console.warn(`تخطي إضافة توصية لأن الأمر غير موجود: ${rec.contextPattern}`);
          continue;
        }
        
        await db.insert(commandRecommendations).values(rec);
      }
      
      console.log('تم إضافة توصيات الأوامر بنجاح');
    } else {
      // استخدام الأوامر الموجودة
      const commandsList = existingCommands;
      
      // حذف التوصيات الموجودة أولاً
      await db.delete(commandRecommendations);
      
      // إضافة توصيات عامة
      const recommendations = [
        // توصيات متعلقة بالألوان
        {
          userId: 'global',
          contextPattern: 'لون',
          commandId: commandsList.find(c => c.name === '!color')?.id || commandsList[0].id,
          weight: 50,
          isPersonalized: false,
          usageCount: 10,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'تغيير لون',
          commandId: commandsList.find(c => c.name === '!color')?.id || commandsList[0].id,
          weight: 60,
          isPersonalized: false,
          usageCount: 15,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'شراء لون',
          commandId: commandsList.find(c => c.name === '!shop')?.id || commandsList[0].id,
          weight: 55,
          isPersonalized: false,
          usageCount: 12,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'الوان',
          commandId: commandsList.find(c => c.name === '!color')?.id || commandsList[0].id,
          weight: 45,
          isPersonalized: false,
          usageCount: 8,
          lastUsed: new Date()
        },
        
        // توصيات متعلقة بالشراء
        {
          userId: 'global',
          contextPattern: 'شراء',
          commandId: commandsList.find(c => c.name === '!buy')?.id || commandsList[0].id,
          weight: 45,
          isPersonalized: false,
          usageCount: 8,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'متجر',
          commandId: commandsList.find(c => c.name === '!shop')?.id || commandsList[0].id,
          weight: 50,
          isPersonalized: false,
          usageCount: 10,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'عناصر',
          commandId: commandsList.find(c => c.name === '!shop')?.id || commandsList[0].id,
          weight: 40,
          isPersonalized: false,
          usageCount: 7,
          lastUsed: new Date()
        },
        
        // توصيات متعلقة بالملف الشخصي
        {
          userId: 'global',
          contextPattern: 'ملف',
          commandId: commandsList.find(c => c.name === '!profile')?.id || commandsList[0].id,
          weight: 40,
          isPersonalized: false,
          usageCount: 7,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'مستوى',
          commandId: commandsList.find(c => c.name === '!profile')?.id || commandsList[0].id,
          weight: 35,
          isPersonalized: false,
          usageCount: 5,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'شخصي',
          commandId: commandsList.find(c => c.name === '!profile')?.id || commandsList[0].id,
          weight: 38,
          isPersonalized: false,
          usageCount: 6,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'نقاط',
          commandId: commandsList.find(c => c.name === '!profile')?.id || commandsList[0].id,
          weight: 30,
          isPersonalized: false,
          usageCount: 4,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'خبرة',
          commandId: commandsList.find(c => c.name === '!profile')?.id || commandsList[0].id,
          weight: 32,
          isPersonalized: false,
          usageCount: 4,
          lastUsed: new Date()
        },
        
        // توصيات متعلقة بلوحة المتصدرين
        {
          userId: 'global',
          contextPattern: 'متصدر',
          commandId: commandsList.find(c => c.name === '!leaderboard')?.id || commandsList[0].id,
          weight: 50,
          isPersonalized: false,
          usageCount: 10,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'افضل',
          commandId: commandsList.find(c => c.name === '!leaderboard')?.id || commandsList[0].id,
          weight: 45,
          isPersonalized: false,
          usageCount: 8,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'ترتيب',
          commandId: commandsList.find(c => c.name === '!leaderboard')?.id || commandsList[0].id,
          weight: 48,
          isPersonalized: false,
          usageCount: 9,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'قائمة',
          commandId: commandsList.find(c => c.name === '!leaderboard')?.id || commandsList[0].id,
          weight: 42,
          isPersonalized: false,
          usageCount: 7,
          lastUsed: new Date()
        },
        {
          userId: 'global',
          contextPattern: 'اعلى',
          commandId: commandsList.find(c => c.name === '!leaderboard')?.id || commandsList[0].id,
          weight: 40,
          isPersonalized: false,
          usageCount: 6,
          lastUsed: new Date()
        }
      ];
      
      for (const rec of recommendations) {
        await db.insert(commandRecommendations).values(rec);
      }
      
      console.log('تم إضافة توصيات الأوامر بنجاح');
    }
    
  } catch (error) {
    console.error('حدث خطأ أثناء إضافة بيانات توصيات الأوامر:', error);
  }
}

// تنفيذ العملية فوراً
seedCommandRecommendations().catch(console.error);
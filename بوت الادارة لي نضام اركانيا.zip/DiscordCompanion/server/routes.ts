import { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertCommandSchema, 
  insertLogSchema, 
  tasks, 
  productivityStats, 
  achievements, 
  userAchievements, 
  clans,
  clanMembers,
  clanDonations,
  promotionRequests,
  clanChallenges
} from "@shared/schema";
import { 
  initializeBot, 
  startBot, 
  stopBot, 
  restartBot,
  incrementAiInteractions,
  getConversationHistory,
  addToConversationHistory,
  clearConversationHistory
} from "./bot/index";
import {
  testCleanupChannel,
  setCommandChannel,
  cleanupCommandChannel
} from "./bot/channel-management";
import { z } from "zod";
import { spawn } from "child_process";
import { join } from "path";
import * as fs from "fs";
import { askChatGPT, generateImage, analyzeSentiment, analyzeTextContent } from './ai/chatgpt';
import { addInteraction, getSuggestions, suggestImprovements } from './bot/self-learning';
import { getRecommendedCommands } from './bot/command-recommendations';
import { 
  createTask, 
  completeTask, 
  checkUserInactivity, 
  generateSuggestedTask, 
  getUsersLeaderboard, 
  adjustTaskDifficulty
} from './task-system';
import { db } from './db';
import { and, desc, eq, gt, inArray, asc } from 'drizzle-orm';

let discordClient: any = null;

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  // Initialize the bot
  try {
    discordClient = await initializeBot();
    
    // Start the bot if token is available
    const token = process.env.DISCORD_TOKEN;
    if (token) {
      await startBot(token);
      console.log('Discord bot started successfully');
    } else {
      console.warn('Discord bot not started: DISCORD_TOKEN not provided');
    }
  } catch (error) {
    console.error('Failed to initialize bot:', error);
  }

  // Validate bot token schema
  const tokenSchema = z.object({
    token: z.string().min(1, "Token is required")
  });

  // Get bot status
  app.get('/api/bot/status', async (req: Request, res: Response) => {
    try {
      const stats = await storage.getStats();
      res.json({
        status: discordClient?.isReady() ? 'online' : 'offline',
        stats
      });
    } catch (error) {
      console.error('Error getting bot status:', error);
      res.status(500).json({ message: 'Failed to get bot status' });
    }
  });

  // Restart bot
  app.post('/api/bot/restart', async (req: Request, res: Response) => {
    try {
      const token = process.env.DISCORD_TOKEN;
      if (!token) {
        return res.status(400).json({ message: 'DISCORD_TOKEN not provided' });
      }

      discordClient = await restartBot(token);
      res.json({ message: 'Bot restarted successfully' });
    } catch (error) {
      console.error('Error restarting bot:', error);
      res.status(500).json({ message: 'Failed to restart bot' });
    }
  });

  // Set bot token
  app.post('/api/bot/token', async (req: Request, res: Response) => {
    try {
      const result = tokenSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: result.error.errors[0].message });
      }

      // In a real app, we'd securely store this token
      // For demo, we'll just start the bot with the provided token
      process.env.DISCORD_TOKEN = result.data.token;
      
      if (discordClient) {
        await stopBot();
      }
      
      discordClient = await initializeBot();
      await startBot(result.data.token);
      
      res.json({ message: 'Bot token set and bot started successfully' });
    } catch (error) {
      console.error('Error setting bot token:', error);
      res.status(500).json({ message: 'Failed to set bot token' });
    }
  });

  // Get all commands
  app.get('/api/commands', async (req: Request, res: Response) => {
    try {
      const commands = await storage.getAllCommands();
      res.json(commands);
    } catch (error) {
      console.error('Error getting commands:', error);
      res.status(500).json({ message: 'Failed to get commands' });
    }
  });

  // Create a new command
  app.post('/api/commands', async (req: Request, res: Response) => {
    try {
      const result = insertCommandSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: result.error.errors[0].message });
      }

      const command = await storage.createCommand(result.data);
      res.status(201).json(command);
    } catch (error) {
      console.error('Error creating command:', error);
      res.status(500).json({ message: 'Failed to create command' });
    }
  });

  // Update a command
  app.patch('/api/commands/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid command ID' });
      }

      const result = insertCommandSchema.partial().safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: result.error.errors[0].message });
      }

      const updatedCommand = await storage.updateCommand(id, result.data);
      if (!updatedCommand) {
        return res.status(404).json({ message: 'Command not found' });
      }

      res.json(updatedCommand);
    } catch (error) {
      console.error('Error updating command:', error);
      res.status(500).json({ message: 'Failed to update command' });
    }
  });

  // Delete a command
  app.delete('/api/commands/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid command ID' });
      }

      const success = await storage.deleteCommand(id);
      if (!success) {
        return res.status(404).json({ message: 'Command not found' });
      }

      res.status(204).send();
    } catch (error) {
      console.error('Error deleting command:', error);
      res.status(500).json({ message: 'Failed to delete command' });
    }
  });

  // Get logs
  app.get('/api/logs', async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : undefined;
      const logs = await storage.getLogs(limit);
      res.json(logs);
    } catch (error) {
      console.error('Error getting logs:', error);
      res.status(500).json({ message: 'Failed to get logs' });
    }
  });

  // Create a log entry
  app.post('/api/logs', async (req: Request, res: Response) => {
    try {
      const result = insertLogSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: result.error.errors[0].message });
      }

      const log = await storage.createLog(result.data);
      res.status(201).json(log);
    } catch (error) {
      console.error('Error creating log:', error);
      res.status(500).json({ message: 'Failed to create log' });
    }
  });

  // Clear all logs
  app.delete('/api/logs', async (req: Request, res: Response) => {
    try {
      await storage.clearLogs();
      res.status(204).send();
    } catch (error) {
      console.error('Error clearing logs:', error);
      res.status(500).json({ message: 'Failed to clear logs' });
    }
  });

  // نظام المستويات (Leveling System) API Routes
  let pythonBotProcess: any = null;

  // تشغيل بوت النظام المستويات 
  const startPythonBot = () => {
    try {
      if (pythonBotProcess) {
        console.log('Python bot is already running, stopping first...');
        pythonBotProcess.kill();
      }

      // تحديث ملف .env للبوت
      const envPath = join(process.cwd(), '.env');
      const envContent = `DISCORD_TOKEN=${process.env.DISCORD_TOKEN || ''}`;
      fs.writeFileSync(envPath, envContent);

      console.log('Starting Python leveling bot...');
      pythonBotProcess = spawn('python', [join(process.cwd(), 'bot_py/run_bot.py')], {
        stdio: ['ignore', 'pipe', 'pipe'],
        detached: false
      });

      pythonBotProcess.stdout.on('data', (data: Buffer) => {
        console.log(`Python bot: ${data.toString().trim()}`);
      });
      
      pythonBotProcess.stderr.on('data', (data: Buffer) => {
        console.error(`Python bot error: ${data.toString().trim()}`);
      });

      pythonBotProcess.on('close', (code: number) => {
        console.log(`Python bot process exited with code ${code}`);
        pythonBotProcess = null;
      });

      return { success: true, message: 'تم تشغيل بوت نظام المستويات بنجاح' };
    } catch (error) {
      console.error('Failed to start Python bot:', error);
      return { success: false, message: `Failed to start: ${error}` };
    }
  };

  // إيقاف بوت النظام المستويات
  const stopPythonBot = () => {
    try {
      if (pythonBotProcess) {
        pythonBotProcess.kill();
        pythonBotProcess = null;
        return { success: true, message: 'Python leveling bot stopped' };
      }
      return { success: true, message: 'Python leveling bot was not running' };
    } catch (error) {
      console.error('Failed to stop Python bot:', error);
      return { success: false, message: `Failed to stop: ${error}` };
    }
  };

  // تشغيل بوت نظام المستويات
  app.post('/api/leveling/start', async (req: Request, res: Response) => {
    const result = startPythonBot();
    if (result.success) {
      res.json({ message: result.message });
    } else {
      res.status(500).json({ message: result.message });
    }
  });

  // إيقاف بوت نظام المستويات
  app.post('/api/leveling/stop', async (req: Request, res: Response) => {
    const result = stopPythonBot();
    if (result.success) {
      res.json({ message: result.message });
    } else {
      res.status(500).json({ message: result.message });
    }
  });

  // الحصول على بيانات نظام المستويات
  app.get('/api/leveling/users', async (req: Request, res: Response) => {
    try {
      const dataPath = join(process.cwd(), 'user_data.json');
      if (!fs.existsSync(dataPath)) {
        return res.json([]); // إذا لم يكن الملف موجودًا، نعيد قائمة فارغة
      }
      
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      const users = Object.entries(data).map(([userId, userData]: [string, any]) => ({
        userId,
        ...userData,
      }));
      
      res.json(users);
    } catch (error) {
      console.error('Error getting leveling data:', error);
      res.status(500).json({ message: 'Failed to get leveling data' });
    }
  });

  // تحديث نظام المستويات
  app.post('/api/leveling/users/:userId', async (req: Request, res: Response) => {
    try {
      const { userId } = req.params;
      const { xp, level, coins, is_vip, rank, color } = req.body;
      
      const dataPath = join(process.cwd(), 'user_data.json');
      if (!fs.existsSync(dataPath)) {
        return res.status(404).json({ message: 'Leveling data file not found' });
      }
      
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      
      if (!data[userId]) {
        data[userId] = { 
          xp: 0, 
          total_xp: 0,
          level: 1, 
          rank: "مبتدئ",
          coins: 0,
          is_vip: false,
          vip_expiry: null,
          color: "#3498db",
          inventory: [],
          quotes: [] 
        };
      }
      
      // تحديث البيانات حسب ما تم إرساله
      if (xp !== undefined) {
        data[userId].xp = xp;
        data[userId].total_xp = Math.max(data[userId].total_xp || 0, xp);
      }
      if (level !== undefined) data[userId].level = level;
      if (coins !== undefined) data[userId].coins = coins;
      if (is_vip !== undefined) data[userId].is_vip = is_vip;
      if (rank !== undefined) data[userId].rank = rank;
      if (color !== undefined) data[userId].color = color;
      
      fs.writeFileSync(dataPath, JSON.stringify(data, null, 4));
      
      res.json({ message: 'User data updated', user: { userId, ...data[userId] } });
    } catch (error) {
      console.error('Error updating leveling data:', error);
      res.status(500).json({ message: 'Failed to update leveling data' });
    }
  });
  
  // الحصول على المخزون (الحقيبة) الخاصة بالمستخدم
  app.get('/api/leveling/users/:userId/inventory', async (req: Request, res: Response) => {
    try {
      const { userId } = req.params;
      const dataPath = join(process.cwd(), 'user_data.json');
      
      if (!fs.existsSync(dataPath)) {
        return res.json([]);
      }
      
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      
      if (!data[userId] || !data[userId].inventory) {
        return res.json([]);
      }
      
      res.json(data[userId].inventory);
    } catch (error) {
      console.error('Error getting user inventory:', error);
      res.status(500).json({ message: 'Failed to get user inventory' });
    }
  });
  
  // الحصول على عناصر المتجر
  app.get('/api/leveling/shop', async (req: Request, res: Response) => {
    try {
      // جلب عناصر المتجر من ملف بوت المستويات
      // هذه معلومات ثابتة، يمكن أيضًا تخزينها في قاعدة البيانات
      const shopItems = [
        {
          id: 1,
          name: "عضوية VIP",
          description: "احصل على +20% XP وعلامة مميزة لمدة 30 يوم",
          price: 1500,
          type: "VIP",
          duration: 30
        },
        {
          id: 2,
          name: "تغيير لون",
          description: "اختر لونًا مخصصًا لملفك الشخصي",
          price: 500,
          type: "COLOR",
          duration: 0
        },
        {
          id: 3,
          name: "إضافة اقتباس",
          description: "أضف اقتباسًا إلى مكتبة اقتباساتك",
          price: 10,
          type: "QUOTE",
          duration: 0
        }
      ];
      
      res.json(shopItems);
    } catch (error) {
      console.error('Error getting shop items:', error);
      res.status(500).json({ message: 'Failed to get shop items' });
    }
  });
  
  // شراء عنصر من المتجر
  app.post('/api/leveling/shop/purchase', async (req: Request, res: Response) => {
    try {
      const { userId, itemId } = req.body;
      
      if (!userId || !itemId) {
        return res.status(400).json({ message: 'User ID and item ID are required' });
      }
      
      const dataPath = join(process.cwd(), 'user_data.json');
      if (!fs.existsSync(dataPath)) {
        return res.status(404).json({ message: 'User data file not found' });
      }
      
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      
      if (!data[userId]) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // الحصول على عناصر المتجر
      const shopItems = [
        {
          id: 1,
          name: "عضوية VIP",
          description: "احصل على +20% XP وعلامة مميزة لمدة 30 يوم",
          price: 1500,
          type: "VIP",
          duration: 30
        },
        {
          id: 2,
          name: "تغيير لون",
          description: "اختر لونًا مخصصًا لملفك الشخصي",
          price: 500,
          type: "COLOR",
          duration: 0
        },
        {
          id: 3,
          name: "إضافة اقتباس",
          description: "أضف اقتباسًا إلى مكتبة اقتباساتك",
          price: 10,
          type: "QUOTE",
          duration: 0
        }
      ];
      
      const item = shopItems.find(item => item.id === itemId);
      if (!item) {
        return res.status(404).json({ message: 'Item not found' });
      }
      
      // التحقق من رصيد المستخدم
      if (data[userId].coins < item.price) {
        return res.status(400).json({ message: 'Insufficient funds' });
      }
      
      // خصم العملات
      data[userId].coins -= item.price;
      
      // إضافة العنصر للمخزون
      if (!data[userId].inventory) {
        data[userId].inventory = [];
      }
      
      if (item.type === "VIP") {
        // تفعيل عضوية VIP
        data[userId].is_vip = true;
        const now = new Date();
        const expiryDate = new Date(now.getTime() + item.duration * 24 * 60 * 60 * 1000);
        data[userId].vip_expiry = expiryDate.toISOString();
        
        // إضافة إلى المخزون
        data[userId].inventory.push({
          id: item.id,
          name: item.name,
          type: item.type,
          purchase_date: new Date().toISOString(),
          expiry_date: expiryDate.toISOString()
        });
      } else {
        // إضافة العنصر للمخزون
        data[userId].inventory.push({
          id: item.id,
          name: item.name,
          type: item.type,
          purchase_date: new Date().toISOString()
        });
      }
      
      fs.writeFileSync(dataPath, JSON.stringify(data, null, 4));
      
      res.json({ 
        message: 'Item purchased successfully', 
        item,
        user: { userId, ...data[userId] }
      });
    } catch (error) {
      console.error('Error purchasing item:', error);
      res.status(500).json({ message: 'Failed to purchase item' });
    }
  });
  
  // تحويل العملات بين المستخدمين
  app.post('/api/leveling/transfer', async (req: Request, res: Response) => {
    try {
      const { fromUserId, toUserId, amount } = req.body;
      
      if (!fromUserId || !toUserId || !amount) {
        return res.status(400).json({ message: 'Sender ID, recipient ID, and amount are required' });
      }
      
      if (fromUserId === toUserId) {
        return res.status(400).json({ message: 'Cannot transfer coins to self' });
      }
      
      if (amount <= 0) {
        return res.status(400).json({ message: 'Amount must be positive' });
      }
      
      const dataPath = join(process.cwd(), 'user_data.json');
      if (!fs.existsSync(dataPath)) {
        return res.status(404).json({ message: 'User data file not found' });
      }
      
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      
      if (!data[fromUserId]) {
        return res.status(404).json({ message: 'Sender not found' });
      }
      
      if (!data[toUserId]) {
        // إنشاء المستخدم المستلم إذا لم يكن موجودًا
        data[toUserId] = { 
          xp: 0, 
          total_xp: 0,
          level: 1, 
          rank: "مبتدئ", 
          coins: 0,
          is_vip: false,
          vip_expiry: null,
          inventory: [],
          quotes: []
        };
      }
      
      // التحقق من رصيد المرسل
      if (data[fromUserId].coins < amount) {
        return res.status(400).json({ message: 'Insufficient funds' });
      }
      
      // تحويل العملات
      data[fromUserId].coins -= amount;
      data[toUserId].coins = (data[toUserId].coins || 0) + amount;
      
      // تسجيل المعاملة
      if (!data.transactions) {
        data.transactions = [];
      }
      
      data.transactions.push({
        sender: fromUserId,
        receiver: toUserId,
        amount,
        type: 'TRANSFER',
        timestamp: new Date().toISOString()
      });
      
      fs.writeFileSync(dataPath, JSON.stringify(data, null, 4));
      
      res.json({ 
        message: 'Coins transferred successfully',
        sender: { userId: fromUserId, coins: data[fromUserId].coins },
        receiver: { userId: toUserId, coins: data[toUserId].coins }
      });
    } catch (error) {
      console.error('Error transferring coins:', error);
      res.status(500).json({ message: 'Failed to transfer coins' });
    }
  });
  
  // الحصول على الاقتباسات الخاصة بمستخدم
  app.get('/api/leveling/users/:userId/quotes', async (req: Request, res: Response) => {
    try {
      const { userId } = req.params;
      const dataPath = join(process.cwd(), 'user_data.json');
      
      if (!fs.existsSync(dataPath)) {
        return res.json([]);
      }
      
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      
      if (!data[userId] || !data[userId].quotes) {
        return res.json([]);
      }
      
      res.json(data[userId].quotes);
    } catch (error) {
      console.error('Error getting user quotes:', error);
      res.status(500).json({ message: 'Failed to get user quotes' });
    }
  });
  
  // الحصول على جميع الاقتباسات
  app.get('/api/leveling/quotes', async (req: Request, res: Response) => {
    try {
      const dataPath = join(process.cwd(), 'user_data.json');
      
      if (!fs.existsSync(dataPath)) {
        return res.json([]);
      }
      
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      const allQuotes = [];
      
      // جمع جميع الاقتباسات من كل المستخدمين
      for (const userId in data) {
        if (data[userId].quotes && Array.isArray(data[userId].quotes)) {
          // إضافة معرف المستخدم للاقتباس لتسهيل التعرف على صاحبه
          const userQuotes = data[userId].quotes.map(quote => ({
            ...quote,
            userId
          }));
          allQuotes.push(...userQuotes);
        }
      }
      
      // ترتيب الاقتباسات حسب التاريخ (الأحدث أولاً)
      allQuotes.sort((a, b) => {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      });
      
      res.json(allQuotes);
    } catch (error) {
      console.error('Error getting all quotes:', error);
      res.status(500).json({ message: 'Failed to get quotes' });
    }
  });
  
  // إضافة اقتباس جديد
  app.post('/api/leveling/quotes', async (req: Request, res: Response) => {
    try {
      const { userId, content } = req.body;
      
      if (!userId || !content) {
        return res.status(400).json({ message: 'User ID and quote content are required' });
      }
      
      const dataPath = join(process.cwd(), 'user_data.json');
      if (!fs.existsSync(dataPath)) {
        return res.status(404).json({ message: 'User data file not found' });
      }
      
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      
      if (!data[userId]) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // التحقق من امتلاك المستخدم لعنصر "اقتباس فارغ" في المخزون
      let hasQuoteItem = false;
      if (data[userId].inventory && Array.isArray(data[userId].inventory)) {
        const quoteItem = data[userId].inventory.find(item => 
          item.type === "QUOTE" && item.name === "اقتباس فارغ"
        );
        
        if (quoteItem) {
          hasQuoteItem = true;
          // إزالة العنصر من المخزون
          data[userId].inventory = data[userId].inventory.filter(item => 
            !(item.type === "QUOTE" && item.name === "اقتباس فارغ")
          );
        }
      }
      
      if (!hasQuoteItem) {
        return res.status(400).json({ message: 'User does not have a quote slot. Purchase one from the shop.' });
      }
      
      // إضافة الاقتباس
      if (!data[userId].quotes) {
        data[userId].quotes = [];
      }
      
      const newQuote = {
        content,
        author: userId, // يمكن تغييره لاحقًا إلى اسم المستخدم
        date: new Date().toISOString()
      };
      
      data[userId].quotes.push(newQuote);
      
      // إضافة عنصر "اقتباس مستخدم" للمخزون
      data[userId].inventory.push({
        id: 3,
        name: `اقتباس: ${content.slice(0, 20)}...`,
        type: "QUOTE_USED",
        purchase_date: new Date().toISOString()
      });
      
      fs.writeFileSync(dataPath, JSON.stringify(data, null, 4));
      
      res.json({ 
        message: 'Quote added successfully',
        quote: newQuote
      });
    } catch (error) {
      console.error('Error adding quote:', error);
      res.status(500).json({ message: 'Failed to add quote' });
    }
  });

  // إضافة API للذكاء الاصطناعي والتعلم الذاتي
  
  // استخدام ChatGPT للحصول على إجابة
  app.post('/api/ai/ask', async (req: Request, res: Response) => {
    try {
      const { prompt, systemPrompt, userId } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ message: 'Prompt is required' });
      }
      
      // استخدام محفوظات المحادثة إذا كان متاحًا
      let conversation = [];
      if (userId) {
        conversation = getConversationHistory(userId);
      }
      
      // استدعاء ChatGPT
      const response = await askChatGPT(prompt, systemPrompt);
      
      // تحديث محفوظات المحادثة إذا كان هناك معرف مستخدم
      if (userId) {
        addToConversationHistory(userId, 'user', prompt);
        addToConversationHistory(userId, 'assistant', response);
        
        // تسجيل التفاعل للتعلم الذاتي
        addInteraction(userId, prompt, response);
        incrementAiInteractions();
      }
      
      res.json({ response });
    } catch (error) {
      console.error('Error in AI ask:', error);
      res.status(500).json({ message: 'Failed to get AI response' });
    }
  });
  
  // توليد صورة باستخدام DALL·E
  app.post('/api/ai/generate-image', async (req: Request, res: Response) => {
    try {
      const { prompt, userId } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ message: 'Prompt is required' });
      }
      
      // توليد الصورة
      const result = await generateImage(prompt);
      
      // تسجيل التفاعل للتعلم الذاتي
      if (userId) {
        addInteraction(userId, `Generate image: ${prompt}`, result.url);
        incrementAiInteractions();
      }
      
      res.json({ imageUrl: result.url });
    } catch (error) {
      console.error('Error generating image:', error);
      res.status(500).json({ message: 'Failed to generate image' });
    }
  });
  
  // تحليل المشاعر
  app.post('/api/ai/sentiment', async (req: Request, res: Response) => {
    try {
      const { text } = req.body;
      
      if (!text) {
        return res.status(400).json({ message: 'Text is required' });
      }
      
      const sentiment = await analyzeSentiment(text);
      res.json(sentiment);
    } catch (error) {
      console.error('Error analyzing sentiment:', error);
      res.status(500).json({ message: 'Failed to analyze sentiment' });
    }
  });
  
  // الحصول على اقتراحات التحسين من نظام التعلم الذاتي
  app.get('/api/ai/suggestions', async (req: Request, res: Response) => {
    try {
      const suggestions = getSuggestions();
      res.json({ suggestions });
    } catch (error) {
      console.error('Error getting suggestions:', error);
      res.status(500).json({ message: 'Failed to get suggestions' });
    }
  });
  
  // الحصول على توصيات أوامر حسب محتوى النص
  app.post('/api/commands/recommendations', async (req: Request, res: Response) => {
    try {
      const { text, userId } = req.body;
      
      if (!text) {
        return res.status(400).json({ message: 'نص الرسالة مطلوب' });
      }
      
      // استخدام معرف مستخدم افتراضي إذا لم يتم تقديمه
      const userIdToUse = userId || 'default';
      
      // الحصول على التوصيات بناءً على النص
      const recommendations = await getRecommendedCommands(text, userIdToUse);
      
      res.json({ recommendations });
    } catch (error) {
      console.error('Error getting command recommendations:', error);
      res.status(500).json({ message: 'حدث خطأ أثناء الحصول على التوصيات' });
    }
  });
  
  // تحليل محتوى النص
  app.post('/api/ai/analyze-text', async (req: Request, res: Response) => {
    try {
      const { text } = req.body;
      
      if (!text) {
        return res.status(400).json({ message: 'Text is required' });
      }
      
      try {
        // محاولة استخدام OpenAI
        const analysis = await analyzeTextContent(text);
        if (analysis) {
          return res.json(analysis);
        }
      } catch (error) {
        console.error("خطأ في تحليل النص:", error);
        // إذا فشل استخدام OpenAI، يتم استخدام التحليل البسيط
      }
      
      // منطق بديل لتحليل النص لا يعتمد على OpenAI
      // استخراج الكلمات المفتاحية بطريقة بسيطة
      const keywords = text
        .replace(/[^\p{L}\p{N}\s]/gu, '') // إزالة الرموز الخاصة
        .split(/\s+/)
        .filter(word => word.length > 3) // استبعاد الكلمات القصيرة
        .slice(0, 5); // الاحتفاظ بأهم 5 كلمات
      
      // تحليل النية بطريقة بسيطة
      let intent = "استفسار";
      if (text.includes("?") || text.includes("؟") || text.includes("كيف") || text.includes("ما هو")) {
        intent = "استفسار";
      } else if (text.includes("ساعد") || text.includes("مساعدة")) {
        intent = "طلب مساعدة";
      } else if (text.includes("مشكلة") || text.includes("خطأ")) {
        intent = "إبلاغ عن مشكلة";
      }
      
      // تحليل بسيط للمشاعر
      let sentiment = "محايد";
      const positiveWords = ["شكرا", "ممتاز", "رائع", "جيد", "أحب", "سعيد"];
      const negativeWords = ["سيء", "مشكلة", "خطأ", "لا يعمل", "فشل"];
      
      let positiveCount = 0;
      let negativeCount = 0;
      
      positiveWords.forEach(word => {
        if (text.includes(word)) positiveCount++;
      });
      
      negativeWords.forEach(word => {
        if (text.includes(word)) negativeCount++;
      });
      
      if (positiveCount > negativeCount) sentiment = "إيجابي";
      else if (negativeCount > positiveCount) sentiment = "سلبي";
      
      // أهم المواضيع
      const topics = [];
      if (text.includes("لون") || text.includes("الوان") || text.includes("خاص")) {
        topics.push("الألوان المخصصة");
      }
      if (text.includes("ميزات") || text.includes("جديد") || text.includes("تحديث")) {
        topics.push("الميزات الجديدة");
      }
      if (text.includes("مستوى") || text.includes("نقاط")) {
        topics.push("نظام المستويات");
      }
      
      const fallbackAnalysis = {
        keywords,
        intent,
        sentiment,
        topics: topics.length > 0 ? topics : ["عام"]
      };
      
      res.json(fallbackAnalysis);
    } catch (error) {
      console.error('Error analyzing text:', error);
      res.status(500).json({ message: 'Failed to analyze text' });
    }
  });

  // اقتراح تحسين للكود
  app.post('/api/ai/improve-code', async (req: Request, res: Response) => {
    try {
      const { filePath, context } = req.body;
      
      if (!filePath) {
        return res.status(400).json({ message: 'File path is required' });
      }
      
      const result = await suggestImprovements(filePath, context || 'Improve code efficiency and readability');
      
      if (!result) {
        return res.status(404).json({ message: 'File not found or could not be analyzed' });
      }
      
      res.json(result);
    } catch (error) {
      console.error('Error improving code:', error);
      res.status(500).json({ message: 'Failed to improve code' });
    }
  });

  // ================= نظام المهام والإنتاجية =================

  // الحصول على المهام الحالية
  app.get('/api/tasks', async (req: Request, res: Response) => {
    try {
      // للتبسيط، نفترض أن هناك معرف مستخدم في الطلب
      // في النظام الحقيقي، يجب استخدام معرف المستخدم من الجلسة
      const userId = req.query.userId ? parseInt(req.query.userId as string, 10) : 1;
      const serverId = req.query.serverId as string || '123456789';
      
      const tasks = await db.query.tasks.findMany({
        where: (tasks, { eq, and, isNull }) => 
          and(
            eq(tasks.userId, userId),
            eq(tasks.serverId, serverId),
            isNull(tasks.completedAt)
          )
      });
      
      res.json(tasks);
    } catch (error) {
      console.error('Error getting tasks:', error);
      res.status(500).json({ message: 'Failed to get tasks' });
    }
  });

  // الحصول على المهام المكتملة
  app.get('/api/tasks/completed', async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string, 10) : 1;
      const serverId = req.query.serverId as string || '123456789';
      
      const tasks = await db.query.tasks.findMany({
        where: (tasks, { eq, and, not, isNull }) => 
          and(
            eq(tasks.userId, userId),
            eq(tasks.serverId, serverId),
            not(isNull(tasks.completedAt))
          ),
        orderBy: (tasks, { desc }) => [desc(tasks.completedAt)]
      });
      
      res.json(tasks);
    } catch (error) {
      console.error('Error getting completed tasks:', error);
      res.status(500).json({ message: 'Failed to get completed tasks' });
    }
  });

  // إنشاء مهمة جديدة
  app.post('/api/tasks', async (req: Request, res: Response) => {
    try {
      const taskSchema = z.object({
        description: z.string().min(3).max(200),
        type: z.enum(["daily", "group", "skill"]),
        expectedTime: z.number().min(5).max(480),
        deadline: z.date().optional(),
      });
      
      const result = taskSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: result.error.errors[0].message });
      }
      
      // للتبسيط، نفترض أن هناك معرف مستخدم ثابت
      const userId = 1;
      const serverId = '123456789';
      
      const newTask = await createTask(
        userId,
        serverId,
        result.data.description,
        result.data.type,
        result.data.expectedTime,
        result.data.deadline
      );
      
      res.status(201).json(newTask);
    } catch (error) {
      console.error('Error creating task:', error);
      res.status(500).json({ message: error instanceof Error ? error.message : 'Failed to create task' });
    }
  });

  // إكمال مهمة
  app.post('/api/tasks/:taskId/complete', async (req: Request, res: Response) => {
    try {
      const taskId = parseInt(req.params.taskId, 10);
      if (isNaN(taskId)) {
        return res.status(400).json({ message: 'Invalid task ID' });
      }
      
      const { timeSpent } = req.body;
      if (typeof timeSpent !== 'number' || timeSpent < 1) {
        return res.status(400).json({ message: 'Time spent must be a positive number' });
      }
      
      const updatedTask = await completeTask(taskId, timeSpent);
      res.json(updatedTask);
    } catch (error) {
      console.error('Error completing task:', error);
      res.status(500).json({ message: error instanceof Error ? error.message : 'Failed to complete task' });
    }
  });

  // الحصول على إحصائيات الإنتاجية
  app.get('/api/productivity/stats', async (req: Request, res: Response) => {
    try {
      // للتبسيط، نفترض أن هناك معرف مستخدم ثابت
      const userId = req.query.userId ? parseInt(req.query.userId as string, 10) : 1;
      
      const stats = await db.query.productivityStats.findFirst({
        where: (stats, { eq }) => eq(stats.userId, userId)
      });
      
      if (!stats) {
        // إذا لم تكن هناك إحصائيات، نعيد إحصائيات فارغة
        return res.json({
          userId,
          dailyTasksCompleted: 0,
          groupTasksCompleted: 0,
          skillTasksCompleted: 0,
          totalPointsEarned: 0,
          averageCompletionTime: 0,
          streak: 0,
          lastActiveDate: new Date(),
          updatedAt: new Date()
        });
      }
      
      res.json(stats);
    } catch (error) {
      console.error('Error getting productivity stats:', error);
      res.status(500).json({ message: 'Failed to get productivity stats' });
    }
  });

  // الحصول على الإنجازات
  app.get('/api/achievements', async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string, 10) : 1;
      
      // الحصول على جميع الإنجازات
      const allAchievements = await db.query.achievements.findMany();
      
      // الحصول على إنجازات المستخدم
      const userAchievements = await db.query.userAchievements.findMany({
        where: (userAchievements, { eq }) => eq(userAchievements.userId, userId)
      });
      
      // دمج المعلومات
      const achievementsWithStatus = allAchievements.map(achievement => {
        const userAchievement = userAchievements.find(ua => ua.achievementId === achievement.id);
        return {
          ...achievement,
          earned: !!userAchievement,
          earnedAt: userAchievement?.earnedAt
        };
      });
      
      res.json(achievementsWithStatus);
    } catch (error) {
      console.error('Error getting achievements:', error);
      res.status(500).json({ message: 'Failed to get achievements' });
    }
  });

  // الحصول على تحديات العشيرة
  app.get('/api/clan-challenges', async (req: Request, res: Response) => {
    try {
      // للتبسيط، نفترض عشيرة ثابتة للمستخدم
      const clanId = req.query.clanId ? parseInt(req.query.clanId as string, 10) : 1;
      
      const challenges = await db.query.clanChallenges.findMany({
        where: (challenges, { eq }) => eq(challenges.clanId, clanId)
      });
      
      res.json(challenges);
    } catch (error) {
      console.error('Error getting clan challenges:', error);
      res.status(500).json({ message: 'Failed to get clan challenges' });
    }
  });

  // الحصول على ترتيب المستخدمين
  app.get('/api/productivity/leaderboard', async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 10;
      
      const leaderboard = await getUsersLeaderboard(limit);
      
      // إضافة أسماء المستخدمين (عادة ستأتي من قاعدة البيانات)
      const leaderboardWithUsernames = leaderboard.map((entry, index) => ({
        ...entry,
        username: `مستخدم ${index + 1}` // في النظام الحقيقي، سيتم استبدالها بأسماء حقيقية
      }));
      
      res.json(leaderboardWithUsernames);
    } catch (error) {
      console.error('Error getting leaderboard:', error);
      res.status(500).json({ message: 'Failed to get leaderboard' });
    }
  });

  // الحصول على مهمة مقترحة
  app.get('/api/tasks/suggested', async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string, 10) : 1;
      
      const suggestedTask = await generateSuggestedTask(userId);
      res.json(suggestedTask);
    } catch (error) {
      console.error('Error generating suggested task:', error);
      res.status(500).json({ message: 'Failed to generate suggested task' });
    }
  });

  // التحقق من عدم نشاط المستخدم وتوصية بالإجازة
  app.get('/api/users/:userId/inactivity', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId, 10);
      if (isNaN(userId)) {
        return res.status(400).json({ message: 'Invalid user ID' });
      }
      
      const inactivityStatus = await checkUserInactivity(userId);
      res.json(inactivityStatus);
    } catch (error) {
      console.error('Error checking user inactivity:', error);
      res.status(500).json({ message: 'Failed to check user inactivity' });
    }
  });

  // تعديل صعوبة المهام
  app.get('/api/users/:userId/adjust-difficulty', async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId, 10);
      if (isNaN(userId)) {
        return res.status(400).json({ message: 'Invalid user ID' });
      }
      
      const adjustmentResult = await adjustTaskDifficulty(userId);
      res.json(adjustmentResult);
    } catch (error) {
      console.error('Error adjusting task difficulty:', error);
      res.status(500).json({ message: 'Failed to adjust task difficulty' });
    }
  });
  
  // API للعشائر (Clans)
  // إنشاء عشيرة جديدة
  app.post('/api/clans', async (req: Request, res: Response) => {
    try {
      const clanData = req.body;
      
      if (!clanData.name || !clanData.leaderId) {
        return res.status(400).json({ message: 'اسم العشيرة ومعرف القائد مطلوبان' });
      }
      
      // التحقق من عدم وجود عشيرة بنفس الاسم
      const [existingClan] = await db.select().from(clans).where(eq(clans.name, clanData.name));
      if (existingClan) {
        return res.status(400).json({ message: 'يوجد عشيرة بهذا الاسم بالفعل' });
      }
      
      // التحقق من أن القائد غير منضم لعشيرة أخرى
      const [existingMember] = await db.select().from(clanMembers).where(eq(clanMembers.userId, clanData.leaderId));
      if (existingMember) {
        return res.status(400).json({ message: 'المستخدم منضم بالفعل لعشيرة أخرى' });
      }
      
      // إنشاء العشيرة
      const [newClan] = await db.insert(clans).values({
        name: clanData.name,
        leaderId: clanData.leaderId,
        description: clanData.description || 'عشيرة جديدة',
        logoUrl: clanData.logoUrl,
      }).returning();
      
      // إضافة القائد كعضو أول في العشيرة
      await db.insert(clanMembers).values({
        clanId: newClan.id,
        userId: clanData.leaderId,
        role: 'leader',
      });
      
      res.status(201).json({
        message: 'تم إنشاء العشيرة بنجاح',
        clan: newClan
      });
    } catch (error) {
      console.error('Error creating clan:', error);
      res.status(500).json({ message: 'حدث خطأ أثناء إنشاء العشيرة' });
    }
  });
  
  // الحصول على قائمة جميع العشائر
  app.get('/api/clans', async (req: Request, res: Response) => {
    try {
      // جلب قائمة العشائر وعدد الأعضاء لكل عشيرة
      const clansList = await db.select().from(clans).orderBy(desc(clans.level));
      
      res.json(clansList);
    } catch (error) {
      console.error('Error fetching clans:', error);
      res.status(500).json({ message: 'حدث خطأ أثناء جلب قائمة العشائر' });
    }
  });
  
  // الحصول على معلومات عشيرة محددة
  app.get('/api/clans/:clanId', async (req: Request, res: Response) => {
    try {
      const clanId = parseInt(req.params.clanId);
      if (isNaN(clanId)) {
        return res.status(400).json({ message: 'معرف العشيرة غير صالح' });
      }
      
      // جلب معلومات العشيرة
      const [clan] = await db.select().from(clans).where(eq(clans.id, clanId));
      if (!clan) {
        return res.status(404).json({ message: 'العشيرة غير موجودة' });
      }
      
      // جلب أعضاء العشيرة
      const members = await db.select().from(clanMembers).where(eq(clanMembers.clanId, clanId));
      
      // جلب قائمة التبرعات
      const donations = await db.select().from(clanDonations).where(eq(clanDonations.clanId, clanId));
      
      // جلب قائمة التحديات
      const challenges = await db.select().from(clanChallenges).where(eq(clanChallenges.clanId, clanId));
      
      res.json({
        ...clan,
        members,
        donations,
        challenges
      });
    } catch (error) {
      console.error('Error fetching clan details:', error);
      res.status(500).json({ message: 'حدث خطأ أثناء جلب معلومات العشيرة' });
    }
  });
  
  // الانضمام إلى عشيرة
  app.post('/api/clans/:clanId/join', async (req: Request, res: Response) => {
    try {
      const clanId = parseInt(req.params.clanId);
      const { userId } = req.body;
      
      if (isNaN(clanId) || !userId) {
        return res.status(400).json({ message: 'معرف العشيرة ومعرف المستخدم مطلوبان' });
      }
      
      // التحقق من وجود العشيرة
      const [clan] = await db.select().from(clans).where(eq(clans.id, clanId));
      if (!clan) {
        return res.status(404).json({ message: 'العشيرة غير موجودة' });
      }
      
      // التحقق من أن المستخدم غير منضم لعشيرة أخرى
      const [existingMember] = await db.select().from(clanMembers).where(eq(clanMembers.userId, userId));
      if (existingMember) {
        return res.status(400).json({ message: 'المستخدم منضم بالفعل لعشيرة أخرى' });
      }
      
      // إضافة المستخدم كعضو في العشيرة
      const [newMember] = await db.insert(clanMembers).values({
        clanId,
        userId,
        role: 'member', // عضو عادي
      }).returning();
      
      // تحديث عدد الأعضاء في العشيرة
      await db.update(clans)
        .set({ memberCount: clan.memberCount + 1 })
        .where(eq(clans.id, clanId));
      
      res.status(200).json({
        message: 'تم الانضمام إلى العشيرة بنجاح',
        member: newMember
      });
    } catch (error) {
      console.error('Error joining clan:', error);
      res.status(500).json({ message: 'حدث خطأ أثناء الانضمام إلى العشيرة' });
    }
  });
  
  // مغادرة عشيرة
  app.post('/api/clans/:clanId/leave', async (req: Request, res: Response) => {
    try {
      const clanId = parseInt(req.params.clanId);
      const { userId } = req.body;
      
      if (isNaN(clanId) || !userId) {
        return res.status(400).json({ message: 'معرف العشيرة ومعرف المستخدم مطلوبان' });
      }
      
      // التحقق من وجود العشيرة
      const [clan] = await db.select().from(clans).where(eq(clans.id, clanId));
      if (!clan) {
        return res.status(404).json({ message: 'العشيرة غير موجودة' });
      }
      
      // التحقق من عضوية المستخدم في العشيرة
      const [member] = await db.select()
        .from(clanMembers)
        .where(and(eq(clanMembers.clanId, clanId), eq(clanMembers.userId, userId)));
      
      if (!member) {
        return res.status(404).json({ message: 'المستخدم ليس عضوًا في هذه العشيرة' });
      }
      
      // القادة لا يمكنهم المغادرة، يجب عليهم تعيين قائد جديد أولًا
      if (member.role === 'leader') {
        return res.status(400).json({ message: 'القائد لا يمكنه مغادرة العشيرة. قم بتعيين قائد جديد أولًا' });
      }
      
      // حذف العضو من العشيرة
      await db.delete(clanMembers)
        .where(and(eq(clanMembers.clanId, clanId), eq(clanMembers.userId, userId)));
      
      // تحديث عدد الأعضاء في العشيرة
      await db.update(clans)
        .set({ memberCount: Math.max(1, clan.memberCount - 1) })
        .where(eq(clans.id, clanId));
      
      res.status(200).json({
        message: 'تم مغادرة العشيرة بنجاح'
      });
    } catch (error) {
      console.error('Error leaving clan:', error);
      res.status(500).json({ message: 'حدث خطأ أثناء مغادرة العشيرة' });
    }
  });
  
  // التبرع لخزينة العشيرة
  app.post('/api/clans/:clanId/donate', async (req: Request, res: Response) => {
    try {
      const clanId = parseInt(req.params.clanId);
      const { userId, amount } = req.body;
      
      if (isNaN(clanId) || !userId || !amount || amount <= 0) {
        return res.status(400).json({ message: 'معرف العشيرة ومعرف المستخدم والمبلغ مطلوبون' });
      }
      
      // التحقق من وجود العشيرة
      const [clan] = await db.select().from(clans).where(eq(clans.id, clanId));
      if (!clan) {
        return res.status(404).json({ message: 'العشيرة غير موجودة' });
      }
      
      // التحقق من عضوية المستخدم في العشيرة
      const [member] = await db.select()
        .from(clanMembers)
        .where(and(eq(clanMembers.clanId, clanId), eq(clanMembers.userId, userId)));
      
      if (!member) {
        return res.status(404).json({ message: 'المستخدم ليس عضوًا في هذه العشيرة' });
      }
      
      // التحقق من أن المستخدم لديه رصيد كافي
      // تحميل بيانات المستخدم من ملف JSON (نظام المستويات)
      const dataPath = join(process.cwd(), 'user_data.json');
      if (!fs.existsSync(dataPath)) {
        return res.status(404).json({ message: 'ملف بيانات المستخدمين غير موجود' });
      }
      
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      const userData = data[userId];
      
      if (!userData) {
        return res.status(404).json({ message: 'بيانات المستخدم غير موجودة' });
      }
      
      if (userData.coins < amount) {
        return res.status(400).json({ message: 'رصيد غير كافي للتبرع' });
      }
      
      // خصم المبلغ من المستخدم
      userData.coins -= amount;
      
      // تسجيل التبرع
      const [donation] = await db.insert(clanDonations).values({
        clanId,
        userId,
        amount
      }).returning();
      
      // تحديث خزينة العشيرة
      await db.update(clans)
        .set({ treasury: clan.treasury + amount })
        .where(eq(clans.id, clanId));
      
      // تحديث إحصائيات تبرعات العضو
      await db.update(clanMembers)
        .set({ 
          donationAmount: member.donationAmount + amount,
          contributions: member.contributions + Math.ceil(amount / 10)  // زيادة نقاط المساهمة بناءً على التبرع
        })
        .where(and(eq(clanMembers.clanId, clanId), eq(clanMembers.userId, userId)));
      
      // حفظ التغييرات في ملف بيانات المستخدمين
      fs.writeFileSync(dataPath, JSON.stringify(data, null, 4));
      
      res.status(200).json({
        message: 'تم التبرع بنجاح',
        donation,
        newBalance: userData.coins
      });
    } catch (error) {
      console.error('Error donating to clan:', error);
      res.status(500).json({ message: 'حدث خطأ أثناء التبرع للعشيرة' });
    }
  });
  
  // تقديم طلب ترقية
  app.post('/api/clans/:clanId/promotion-requests', async (req: Request, res: Response) => {
    try {
      const clanId = parseInt(req.params.clanId);
      const { userId, requestedRole, reason } = req.body;
      
      if (isNaN(clanId) || !userId || !requestedRole) {
        return res.status(400).json({ message: 'معرف العشيرة ومعرف المستخدم والدور المطلوب مطلوبون' });
      }
      
      // التحقق من أن الدور المطلوب صالح
      if (!['officer'].includes(requestedRole)) {
        return res.status(400).json({ message: 'الدور المطلوب غير صالح' });
      }
      
      // التحقق من وجود العشيرة
      const [clan] = await db.select().from(clans).where(eq(clans.id, clanId));
      if (!clan) {
        return res.status(404).json({ message: 'العشيرة غير موجودة' });
      }
      
      // التحقق من عضوية المستخدم في العشيرة
      const [member] = await db.select()
        .from(clanMembers)
        .where(and(eq(clanMembers.clanId, clanId), eq(clanMembers.userId, userId)));
      
      if (!member) {
        return res.status(404).json({ message: 'المستخدم ليس عضوًا في هذه العشيرة' });
      }
      
      // التحقق من أن المستخدم ليس في الدور المطلوب بالفعل
      if (member.role === requestedRole) {
        return res.status(400).json({ message: 'المستخدم في هذا الدور بالفعل' });
      }
      
      // التحقق من عدم وجود طلب ترقية معلق للمستخدم
      const [existingRequest] = await db.select()
        .from(promotionRequests)
        .where(
          and(
            eq(promotionRequests.clanId, clanId),
            eq(promotionRequests.userId, userId),
            eq(promotionRequests.status, 'pending')
          )
        );
      
      if (existingRequest) {
        return res.status(400).json({ message: 'لديك طلب ترقية معلق بالفعل' });
      }
      
      // إنشاء طلب الترقية
      const [promotionRequest] = await db.insert(promotionRequests).values({
        clanId,
        userId,
        currentRole: member.role,
        requestedRole,
        reason: reason || 'طلب ترقية',
        status: 'pending'
      }).returning();
      
      res.status(201).json({
        message: 'تم تقديم طلب الترقية بنجاح',
        request: promotionRequest
      });
    } catch (error) {
      console.error('Error creating promotion request:', error);
      res.status(500).json({ message: 'حدث خطأ أثناء تقديم طلب الترقية' });
    }
  });
  
  // الحصول على طلبات الترقية
  app.get('/api/clans/:clanId/promotion-requests', async (req: Request, res: Response) => {
    try {
      const clanId = parseInt(req.params.clanId);
      const status = req.query.status as string || 'pending';
      
      if (isNaN(clanId)) {
        return res.status(400).json({ message: 'معرف العشيرة غير صالح' });
      }
      
      // التحقق من وجود العشيرة
      const [clan] = await db.select().from(clans).where(eq(clans.id, clanId));
      if (!clan) {
        return res.status(404).json({ message: 'العشيرة غير موجودة' });
      }
      
      // جلب طلبات الترقية بحسب الحالة
      let requests;
      if (status === 'all') {
        requests = await db.select()
          .from(promotionRequests)
          .where(eq(promotionRequests.clanId, clanId))
          .orderBy(desc(promotionRequests.createdAt));
      } else {
        requests = await db.select()
          .from(promotionRequests)
          .where(and(
            eq(promotionRequests.clanId, clanId),
            eq(promotionRequests.status, status)
          ))
          .orderBy(desc(promotionRequests.createdAt));
      }
      
      res.json(requests);
    } catch (error) {
      console.error('Error fetching promotion requests:', error);
      res.status(500).json({ message: 'حدث خطأ أثناء جلب طلبات الترقية' });
    }
  });
  
  // معالجة طلب ترقية (قبول/رفض)
  app.post('/api/clans/promotion-requests/:requestId/process', async (req: Request, res: Response) => {
    try {
      const requestId = parseInt(req.params.requestId);
      const { reviewerId, status, reason } = req.body;
      
      if (isNaN(requestId) || !reviewerId || !status) {
        return res.status(400).json({ message: 'معرف الطلب ومعرف المراجع والحالة مطلوبون' });
      }
      
      // التحقق من أن الحالة صالحة
      if (!['approved', 'rejected'].includes(status)) {
        return res.status(400).json({ message: 'الحالة غير صالحة' });
      }
      
      // جلب طلب الترقية
      const [request] = await db.select().from(promotionRequests).where(eq(promotionRequests.id, requestId));
      if (!request) {
        return res.status(404).json({ message: 'طلب الترقية غير موجود' });
      }
      
      // التحقق من أن الطلب معلق
      if (request.status !== 'pending') {
        return res.status(400).json({ message: 'تمت معالجة هذا الطلب بالفعل' });
      }
      
      // التحقق من أن المراجع له صلاحيات (قائد أو ضابط)
      const [reviewer] = await db.select()
        .from(clanMembers)
        .where(and(
          eq(clanMembers.clanId, request.clanId),
          eq(clanMembers.userId, reviewerId)
        ));
      
      if (!reviewer || !['leader', 'officer'].includes(reviewer.role)) {
        return res.status(403).json({ message: 'ليس لديك صلاحية لمعالجة طلبات الترقية' });
      }
      
      // تحديث حالة الطلب
      await db.update(promotionRequests)
        .set({
          status,
          reviewerId,
          reviewTimestamp: new Date()
        })
        .where(eq(promotionRequests.id, requestId));
      
      // إذا تمت الموافقة، قم بترقية العضو
      if (status === 'approved') {
        await db.update(clanMembers)
          .set({ role: request.requestedRole })
          .where(and(
            eq(clanMembers.clanId, request.clanId),
            eq(clanMembers.userId, request.userId)
          ));
      }
      
      res.status(200).json({
        message: status === 'approved' ? 'تمت الموافقة على طلب الترقية' : 'تم رفض طلب الترقية',
        status
      });
    } catch (error) {
      console.error('Error processing promotion request:', error);
      res.status(500).json({ message: 'حدث خطأ أثناء معالجة طلب الترقية' });
    }
  });
  
  // إنشاء تحدي خاص للعشيرة
  app.post('/api/clans/:clanId/special-challenges', async (req: Request, res: Response) => {
    try {
      const clanId = parseInt(req.params.clanId);
      const { title, description, points, requiredMembers, leaderId, specialType } = req.body;
      
      if (isNaN(clanId) || !title || !description || !points || !requiredMembers || !specialType) {
        return res.status(400).json({ message: 'جميع الحقول مطلوبة' });
      }
      
      // التحقق من وجود العشيرة
      const [clan] = await db.select().from(clans).where(eq(clans.id, clanId));
      if (!clan) {
        return res.status(404).json({ message: 'العشيرة غير موجودة' });
      }
      
      // التحقق من أن المستخدم هو قائد العشيرة
      if (clan.leaderId !== leaderId) {
        return res.status(403).json({ message: 'يمكن للقائد فقط إنشاء تحديات خاصة' });
      }
      
      // التحقق من أن العشيرة لديها تحديات خاصة متبقية
      if (clan.specialChallengesRemaining <= 0) {
        return res.status(400).json({ message: 'لا توجد تحديات خاصة متبقية لهذا الشهر' });
      }
      
      // التحقق من صلاحية نوع التحدي الخاص
      const validSpecialTypes = ['revenge', 'protect_points', 'double_points', 'alliance'];
      if (!validSpecialTypes.includes(specialType)) {
        return res.status(400).json({ message: 'نوع التحدي الخاص غير صالح' });
      }
      
      // إنشاء موعد نهائي بعد يومين
      const deadline = new Date();
      deadline.setDate(deadline.getDate() + 2);
      
      // إنشاء التحدي الخاص
      const [challenge] = await db.insert(clanChallenges).values({
        clanId,
        title,
        description,
        points,
        requiredMembers,
        currentMembers: 0,
        deadline,
        isSpecial: true,
        specialType
      }).returning();
      
      // تحديث العشيرة
      await db.update(clans)
        .set({
          specialChallengesRemaining: clan.specialChallengesRemaining - 1,
          lastSpecialChallengeDate: new Date()
        })
        .where(eq(clans.id, clanId));
      
      res.status(201).json({
        message: 'تم إنشاء التحدي الخاص بنجاح',
        challenge
      });
    } catch (error) {
      console.error('Error creating special challenge:', error);
      res.status(500).json({ message: 'حدث خطأ أثناء إنشاء التحدي الخاص' });
    }
  });

  // الحصول على تحديات حروب العشائر
  app.get('/api/clan-wars', async (req: Request, res: Response) => {
    try {
      // جلب التحديات النشطة (التي لم تنتهي بعد)
      const activeChallenges = await db.select()
        .from(clanChallenges)
        .where(and(
          eq(clanChallenges.completed, false),
          gt(clanChallenges.deadline, new Date())
        ))
        .orderBy(asc(clanChallenges.deadline));
      
      // جلب التحديات المكتملة
      const completedChallenges = await db.select()
        .from(clanChallenges)
        .where(eq(clanChallenges.completed, true))
        .orderBy(desc(clanChallenges.completedAt))
        .limit(10);
      
      // جلب أسماء العشائر
      const clanIds = new Set([
        ...activeChallenges.map(c => c.clanId),
        ...completedChallenges.map(c => c.clanId)
      ]);
      
      const clansList = await db.select()
        .from(clans)
        .where(inArray(clans.id, Array.from(clanIds)));
      
      const clansMap = new Map(clansList.map(clan => [clan.id, clan]));
      
      // إضافة معلومات العشيرة إلى التحديات
      const enhancedActiveChallenges = activeChallenges.map(challenge => ({
        ...challenge,
        clan: clansMap.get(challenge.clanId)
      }));
      
      const enhancedCompletedChallenges = completedChallenges.map(challenge => ({
        ...challenge,
        clan: clansMap.get(challenge.clanId)
      }));
      
      res.json({
        active: enhancedActiveChallenges,
        completed: enhancedCompletedChallenges
      });
    } catch (error) {
      console.error('Error fetching clan war challenges:', error);
      res.status(500).json({ message: 'حدث خطأ أثناء جلب تحديات حرب العشائر' });
    }
  });

  // واجهة API لإدارة قناة الأوامر
  app.post('/api/channel/cleanup', async (req: Request, res: Response) => {
    try {
      if (!discordClient) {
        return res.status(400).json({ success: false, message: 'بوت الديسكورد غير متصل' });
      }
      
      const { channelId } = req.body;
      
      const { cleanupCommandChannel } = require('./bot/channel-management');
      await cleanupCommandChannel(discordClient);
      
      res.json({
        success: true,
        message: 'تم تنظيف القناة بنجاح وحذف جميع الرسائل باستثناء الرسالة المثبتة',
        details: 'تم إنشاء رسالة مساعدة تفاعلية جديدة وتثبيتها في القناة مع أزرار للتنقل بين الأقسام المختلفة. يتم تنظيف القناة تلقائياً كل 10 دقائق وتغيير اسمها إلى "اوامر النظام".'
      });
    } catch (error) {
      res.status(500).json({ 
        success: false, 
        message: 'فشل في تنظيف قناة الأوامر', 
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  app.post('/api/channel/set-command-channel', async (req: Request, res: Response) => {
    try {
      const { channelId } = req.body;
      
      if (!channelId) {
        return res.status(400).json({ success: false, message: 'يرجى توفير معرف القناة' });
      }
      
      const { setCommandChannel } = require('./bot/channel-management');
      setCommandChannel(channelId);
      
      res.json({ 
        success: true, 
        message: `تم تعيين قناة الأوامر بنجاح: ${channelId}`
      });
    } catch (error) {
      res.status(500).json({ 
        success: false, 
        message: 'فشل في تعيين قناة الأوامر', 
        error: String(error)
      });
    }
  });

  // عند بدء التشغيل، نحاول تشغيل البوت
  if (process.env.DISCORD_TOKEN) {
    startPythonBot();
  }

  const httpServer = createServer(app);

  return httpServer;
}
